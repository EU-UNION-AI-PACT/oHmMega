#!/usr/bin/env node
/**
 * Universal Allrounder Analysis & Transformation Orchestrator
 * - Frontend: Puppeteer HTML/CSS/Assets, Lighthouse, A11y (pa11y/axe)
 * - Static Analysis: Semgrep, SonarQube, ESLint, Prettier, Bandit, FindSecBugs (optional)
 * - Reverse Engineering: Ghidra (headless), Radare2 (optional)
 * - Dependencies & SBOM: Snyk, Black Duck (Detect), Syft, CycloneDX
 * - API: OpenAPI parse, Schemathesis, Postman, gRPC (grpcurl)
 * - Security/Secrets: Gitleaks, TruffleHog, Trivy/Grype, KICS, tfsec
 * - Docs/Diagrams: JSDoc/TypeDoc, Mermaid/PlantUML (optional), Doxygen
 * - Orchestration: Profiles, CLI, Config
 * - Source Hints: README updates + code header hints
 */
import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { execSync, spawnSync } from 'child_process';
import yaml from 'js-yaml';
import yargs from 'yargs';
import puppeteer from 'puppeteer';
import { hideBin } from 'yargs/helpers';
import { default as chromeLauncher } from 'chrome-launcher';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// -------------------- Configuration --------------------
const argv = yargs(hideBin(process.argv))
  .option('profile', { type: 'string', default: 'full', choices: ['full', 'frontend', 'backend', 'api', 'security', 'docs'], describe: 'Which profile to run' })
  .option('config', { type: 'string', default: 'config.example.json', describe: 'Path to config JSON' })
  .option('target-url', { type: 'string', describe: 'URL to analyze with Puppeteer/Lighthouse' })
  .option('src', { type: 'string', describe: 'Source code directory for static analysis' })
  .option('bin', { type: 'string', describe: 'Binary file path for reverse engineering' })
  .option('openapi', { type: 'string', describe: 'OpenAPI spec file path (json/yaml)' })
  .option('postman', { type: 'string', describe: 'Postman collection JSON path' })
  .option('image', { type: 'string', describe: 'Container image reference for scanning/SBOM' })
  .option('out', { type: 'string', default: 'output', describe: 'Output directory' })
  .help().argv;

const OUTPUT_DIR = path.resolve(argv.out);
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

// Load config
let config = {
  meta: {
    inspiration: 'Vapi.ai',
    source_reference: '',
    owner: 'EU-UNION-AI-PACT'
  },
  paths: {
    sourceCode: argv.src || './',
    binaryFile: argv.bin || '',
    openApiSpec: argv.openapi || '',
    postmanCollection: argv.postman || ''
  },
  web: {
    targetUrl: argv['target-url'] || 'https://example.com'
  },
  container: {
    image: argv.image || ''
  },
  features: [
    'Responsive Grid',
    'Dark Mode',
    'Live API Integration',
    'Static Security Checks',
    'API Endpoint Analysis',
    'Reverse Engineering Support',
    'SBOM generation',
    'Secrets & IaC scanning'
  ]
};

try {
  if (fs.existsSync(argv.config)) {
    const cfg = JSON.parse(fs.readFileSync(argv.config, 'utf8'));
    config = { ...config, ...cfg };
  }
} catch (e) {
  console.warn('Config parse error:', e.message);
}

// -------------------- Utils --------------------
function exists(p) { try { fs.accessSync(p); return true; } catch { return false; } }
function ensureDir(p) { fs.mkdirSync(p, { recursive: true }); }
function cmdExists(cmd) {
  const res = spawnSync('sh', ['-lc', `command -v ${cmd}`], { encoding: 'utf8' });
  return res.status === 0 && res.stdout.trim().length > 0;
}
function run(cmd, opts = {}) {
  const { cwd = process.cwd(), env = process.env, stdio = 'pipe', timeout = 0 } = opts;
  try {
    const out = execSync(cmd, { cwd, env, stdio, timeout });
    return { ok: true, out: (out || '').toString() };
  } catch (e) {
    return { ok: false, error: e, out: (e.stdout || '').toString(), err: (e.stderr || '').toString() };
  }
}
function writeJSON(file, data) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(data, null, 2)); }
function writeText(file, text) { ensureDir(path.dirname(file)); fs.writeFileSync(file, text); }
function appendText(file, text) { ensureDir(path.dirname(file)); fs.appendFileSync(file, text); }
function stamp(name) { return `[${new Date().toISOString()}] ${name}`; }

// -------------------- Source Hint --------------------
function writeSourceHint(tool, source, extension) {
  const block = `
Analyse mit: ${tool}
Quelle/Projekt: ${source}
Erweiterungen: ${extension}
Hinweis: Wissenschaftliche Analyse & Weiterentwicklung, keine 1:1-Kopie!
`;
  appendText(path.join(OUTPUT_DIR, 'README.md'), block + '\n');
}

// -------------------- Frontend/Web --------------------
async function extractWithPuppeteer(url) {
  const outDir = path.join(OUTPUT_DIR, 'frontend');
  ensureDir(outDir);
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: 'networkidle2' });

  const html = await page.content();
  writeText(path.join(outDir, 'raw.html'), html);

  const cssLinks = await page.evaluate(() => Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(l => l.href));
  for (const cssUrl of cssLinks) {
    try {
      const res = await page.goto(cssUrl);
      const name = path.basename((new URL(cssUrl)).pathname);
      fs.writeFileSync(path.join(outDir, name || 'style.css'), await res.buffer());
    } catch {}
  }
  const assets = await page.evaluate(() => Array.from(document.images).map(img => img.src));
  for (const a of assets) {
    try {
      const res = await page.goto(a);
      const name = path.basename((new URL(a)).pathname.split('?')[0]);
      fs.writeFileSync(path.join(outDir, name || 'asset.bin'), await res.buffer());
    } catch {}
  }
  await browser.close();
  writeSourceHint('Puppeteer', url, 'Extraktion HTML/CSS/Assets');
}

async function runLighthouse(url) {
  if (!cmdExists('node')) { console.warn('Node required for Lighthouse.'); }
  const outDir = path.join(OUTPUT_DIR, 'frontend', 'lighthouse');
  ensureDir(outDir);
  try {
    const chrome = await chromeLauncher.launch({ chromeFlags: ['--headless'] });
    const { default: lighthouse } = await import('lighthouse');
    const opts = { logLevel: 'info', output: 'html', onlyCategories: ['performance','accessibility','best-practices','seo'], port: chrome.port };
    const runnerResult = await lighthouse(url, opts);
    writeText(path.join(outDir, 'report.html'), runnerResult.report);
    await chrome.kill();
    writeSourceHint('Lighthouse', url, 'Meta-Analyse Performance/SEO/A11y');
  } catch (e) {
    console.error('Lighthouse error:', e.message);
  }
}

// -------------------- Static Analysis & Security --------------------
function runSemgrep(targetPath) {
  if (!cmdExists('semgrep')) return console.warn('Semgrep not found.');
  const outFile = path.join(OUTPUT_DIR, 'static', 'semgrep.json');
  ensureDir(path.dirname(outFile));
  const res = run(`semgrep --config=auto ${targetPath} --json`, { stdio: 'pipe' });
  if (res.ok) writeText(outFile, res.out);
  writeSourceHint('Semgrep', targetPath, 'Static Code & Security Analysis');
}

function runSonarScanner(targetPath) {
  if (!cmdExists('sonar-scanner')) return console.warn('sonar-scanner not found.');
  const res = run(`sonar-scanner -Dsonar.projectBaseDir=${targetPath}`, { stdio: 'inherit' });
  if (!res.ok) console.warn('SonarScanner failed');
  writeSourceHint('SonarQube', targetPath, 'Quality Gate & Code Smells');
}

function runESLint(targetPath) {
  if (!cmdExists('eslint')) return console.warn('eslint not found.');
  const outFile = path.join(OUTPUT_DIR, 'static', 'eslint.json');
  ensureDir(path.dirname(outFile));
  const res = run(`eslint "${targetPath}" -f json`, { stdio: 'pipe' });
  if (res.ok) writeText(outFile, res.out);
  writeSourceHint('ESLint', targetPath, 'Linter Ergebnisse');
}

function runPrettierWrite(targetPath) {
  if (!cmdExists('prettier')) return console.warn('prettier not found.');
  run(`prettier "${targetPath}/**/*.{js,ts,jsx,tsx,css,md,json,yml,yaml}" --write`, { stdio: 'inherit' });
  writeSourceHint('Prettier', targetPath, 'Auto-Formatierung');
}

function runBandit(targetPath) {
  if (!cmdExists('bandit')) return console.warn('bandit not found (pip install bandit).');
  const outFile = path.join(OUTPUT_DIR, 'static', 'bandit.json');
  ensureDir(path.dirname(outFile));
  const res = run(`bandit -r "${targetPath}" -f json`, { stdio: 'pipe' });
  if (res.ok) writeText(outFile, res.out);
  writeSourceHint('Bandit', targetPath, 'Python Security');
}

function runFindSecBugs(targetPath) {
  if (!cmdExists('findsecbugs.sh')) return console.warn('findsecbugs.sh not found.');
  const outFile = path.join(OUTPUT_DIR, 'static', 'findsecbugs.xml');
  ensureDir(path.dirname(outFile));
  run(`findsecbugs.sh -progress -high -xml -output "${outFile}" "${targetPath}"`, { stdio: 'inherit' });
  writeSourceHint('FindSecBugs', targetPath, 'Java Security Analysis');
}

function runGitleaks(targetPath) {
  if (!cmdExists('gitleaks')) return console.warn('gitleaks not found.');
  const outFile = path.join(OUTPUT_DIR, 'security', 'gitleaks.json');
  ensureDir(path.dirname(outFile));
  const res = run(`gitleaks detect -s "${targetPath}" -f json`, { stdio: 'pipe' });
  if (res.ok) writeText(outFile, res.out);
  writeSourceHint('Gitleaks', targetPath, 'Secrets Detection');
}

function runTruffleHog(targetPath) {
  if (!cmdExists('trufflehog')) return console.warn('trufflehog not found.');
  const outFile = path.join(OUTPUT_DIR, 'security', 'trufflehog.json');
  ensureDir(path.dirname(outFile));
  const res = run(`trufflehog filesystem --json "${targetPath}"`, { stdio: 'pipe' });
  if (res.ok) writeText(outFile, res.out);
  writeSourceHint('TruffleHog', targetPath, 'Secrets Detection');
}

function runKICS(targetPath) {
  if (!cmdExists('kics')) return console.warn('kics not found.');
  const outDir = path.join(OUTPUT_DIR, 'iac', 'kics');
  ensureDir(outDir);
  run(`kics scan -p "${targetPath}" -o "${outDir}" --report-formats json,html`, { stdio: 'inherit' });
  writeSourceHint('KICS', targetPath, 'IaC Static Analysis');
}

function runTfsec(targetPath) {
  if (!cmdExists('tfsec')) return console.warn('tfsec not found.');
  const outFile = path.join(OUTPUT_DIR, 'iac', 'tfsec.json');
  ensureDir(path.dirname(outFile));
  const res = run(`tfsec --format json --out "${outFile}" "${targetPath}"`);
  if (!res.ok) console.warn('tfsec failed');
  writeSourceHint('tfsec', targetPath, 'Terraform Security');
}

// -------------------- Reverse Engineering --------------------
function runGhidra(binaryFile) {
  if (!binaryFile) return;
  if (!cmdExists('analyzeHeadless')) return console.warn('Ghidra analyzeHeadless not found.');
  const outDir = path.join(OUTPUT_DIR, 'reverse', 'ghidra');
  ensureDir(outDir);
  const cmd = `analyzeHeadless "${outDir}" universal-ghidra -import "${binaryFile}" -scriptPath . -postScript ExtractFunctions.java`;
  const res = run(cmd, { stdio: 'inherit' });
  if (!res.ok) console.warn('Ghidra failed');
  writeSourceHint('Ghidra', binaryFile, 'Function extraction & decompilation');
}

function runRadare(binaryFile) {
  if (!cmdExists('r2')) return console.warn('radare2 (r2) not found.');
  const outFile = path.join(OUTPUT_DIR, 'reverse', 'r2_analysis.txt');
  ensureDir(path.dirname(outFile));
  const res = run(`r2 -Aqc "aaa;afl;afll;afvb" "${binaryFile}"`, { stdio: 'pipe' });
  if (res.ok) writeText(outFile, res.out);
  writeSourceHint('radare2', binaryFile, 'Function lists & basic analysis');
}

// -------------------- Dependencies / SBOM --------------------
function runSnyk(targetPath) {
  if (!cmdExists('snyk')) return console.warn('snyk not found.');
  const outFile = path.join(OUTPUT_DIR, 'deps', 'snyk.json');
  ensureDir(path.dirname(outFile));
  const res = run(`snyk test --json`, { stdio: 'pipe', cwd: targetPath });
  if (res.ok) writeText(outFile, res.out);
  writeSourceHint('Snyk', targetPath, 'Dependencies & vulns');
}

function runBlackDuckDetect(targetPath) {
  // Requires Synopsys Detect (black duck) installed or use curl bootstrap
  const outFile = path.join(OUTPUT_DIR, 'deps', 'blackduck.txt');
  ensureDir(path.dirname(outFile));
  appendText(outFile, `Run Synopsys Detect in ${targetPath}. Example:
  bash <(curl -s -L https://detect.synopsys.com/detect.sh) \
    --blackduck.url=$BLACKDUCK_URL \
    --blackduck.api.token=$BLACKDUCK_TOKEN \
    --detect.source.path=${targetPath}\n`);
  writeSourceHint('Black Duck (Detect)', targetPath, 'Dependency & Policy scan');
}

function runSyftSBOM(targetRef) {
  if (!cmdExists('syft')) return console.warn('syft not found.');
  const outDir = path.join(OUTPUT_DIR, 'sbom', 'syft');
  ensureDir(outDir);
  const res = run(`syft "${targetRef || '.'}" -o json > "${path.join(outDir, 'sbom.json')}"`, { stdio: 'inherit' });
  if (!res.ok) console.warn('Syft failed');
  writeSourceHint('Syft', targetRef || '.', 'SBOM generation (JSON)');
}

function runCycloneDX(targetPath) {
  const outDir = path.join(OUTPUT_DIR, 'sbom', 'cyclonedx');
  ensureDir(outDir);
  if (cmdExists('cyclonedx-bom')) {
    run(`cyclonedx-bom -o "${path.join(outDir, 'bom.xml')}"`, { stdio: 'inherit', cwd: targetPath || process.cwd() });
  } else {
    appendText(path.join(outDir, 'README.txt'), 'Install cyclonedx-bom to generate SBOM.\n');
  }
  writeSourceHint('CycloneDX', targetPath || '.', 'SBOM (XML)');
}

// -------------------- Container & Cloud --------------------
function runTrivy(targetPathOrImage) {
  if (!cmdExists('trivy')) return console.warn('trivy not found.');
  const outDir = path.join(OUTPUT_DIR, 'container', 'trivy');
  ensureDir(outDir);
  const target = targetPathOrImage || '.';
  // auto detect: if contains ":" assume image, else fs scan
  const cmd = target.includes(':') ? `trivy image --format json -o "${path.join(outDir, 'image.json')}" "${target}"` :
    `trivy fs --format json -o "${path.join(outDir, 'fs.json')}" "${target}"`;
  run(cmd, { stdio: 'inherit' });
  writeSourceHint('Trivy', target, 'Container/FS vulnerability scan');
}

function runGrype(targetImage) {
  if (!cmdExists('grype')) return console.warn('grype not found.');
  const outFile = path.join(OUTPUT_DIR, 'container', 'grype.json');
  ensureDir(path.dirname(outFile));
  const res = run(`grype "${targetImage}" -o json`, { stdio: 'pipe' });
  if (res.ok) writeText(outFile, res.out);
  writeSourceHint('Grype', targetImage, 'Container vuln scan');
}

// -------------------- API --------------------
async function analyzeOpenAPI(specPath) {
  if (!specPath) return;
  const outDir = path.join(OUTPUT_DIR, 'api', 'openapi');
  ensureDir(outDir);
  try {
    const text = fs.readFileSync(specPath, 'utf8');
    const api = specPath.endsWith('.yaml') || specPath.endsWith('.yml') ? yaml.load(text) : JSON.parse(text);
    writeJSON(path.join(outDir, 'spec.normalized.json'), api);
    const endpoints = [];
    if (api.paths) {
      for (const [p, ops] of Object.entries(api.paths)) {
        for (const [method, meta] of Object.entries(ops)) {
          if (['get','post','put','delete','patch','options','head'].includes(method)) {
            endpoints.push({
              method: method.toUpperCase(),
              path: p,
              summary: (meta && meta.summary) || '',
              operationId: (meta && meta.operationId) || '',
              tags: (meta && meta.tags) || [],
            });
          }
        }
      }
    }
    writeJSON(path.join(outDir, 'endpoints.json'), endpoints);
    const md = ['# OpenAPI Endpoints', '', ...endpoints.map(e => `- [${e.method}] ${e.path} — ${e.summary}`)].join('\n');
    writeText(path.join(outDir, 'endpoints.md'), md);
    writeSourceHint('OpenAPI Parser', specPath, 'Endpoints & schema introspection');
  } catch (e) {
    console.error('OpenAPI parse error:', e.message);
  }
}

function runSchemathesis(specPath, baseUrl = '') {
  if (!cmdExists('schemathesis')) return console.warn('schemathesis not found (pip install schemathesis).');
  const outFile = path.join(OUTPUT_DIR, 'api', 'schemathesis.json');
  ensureDir(path.dirname(outFile));
  const cmd = `schemathesis run "${specPath}" ${baseUrl ? `--base-url ${baseUrl}` : ''} --checks all --stateful=links --report-json "${outFile}"`;
  run(cmd, { stdio: 'inherit' });
  writeSourceHint('Schemathesis', specPath, 'API fuzzing & property testing');
}

function parsePostman(collectionPath) {
  if (!collectionPath) return;
  const outDir = path.join(OUTPUT_DIR, 'api', 'postman');
  ensureDir(outDir);
  try {
    const col = JSON.parse(fs.readFileSync(collectionPath, 'utf8'));
    const endpoints = [];
    function walk(items, prefix = '') {
      for (const it of items || []) {
        if (it.item) walk(it.item, `${prefix}/${it.name}`);
        if (it.request) {
          endpoints.push({
            name: `${prefix}/${it.name}`,
            method: it.request.method,
            url: (it.request.url && (it.request.url.raw || it.request.url)) || ''
          });
        }
      }
    }
    walk(col.item || []);
    writeJSON(path.join(outDir, 'endpoints.json'), endpoints);
    writeSourceHint('Postman Parser', collectionPath, 'Endpoints inventory');
  } catch (e) {
    console.error('Postman parse error:', e.message);
  }
}

// -------------------- Accessibility --------------------
function runPa11y(url) {
  if (!cmdExists('pa11y')) return console.warn('pa11y not found.');
  const outFile = path.join(OUTPUT_DIR, 'frontend', 'a11y', 'pa11y.json');
  ensureDir(path.dirname(outFile));
  const res = run(`pa11y "${url}" --reporter json`, { stdio: 'pipe' });
  if (res.ok) writeText(outFile, res.out);
  writeSourceHint('Pa11y', url, 'Accessibility checks');
}

// -------------------- Docs & Diagrams --------------------
function runJSDoc(targetPath) {
  if (!cmdExists('jsdoc')) return console.warn('jsdoc not found.');
  const outDir = path.join(OUTPUT_DIR, 'docs', 'jsdoc');
  ensureDir(outDir);
  run(`jsdoc -c jsdoc.json -r "${targetPath}" -d "${outDir}"`, { stdio: 'inherit' });
  writeSourceHint('JSDoc', targetPath, 'JS documentation');
}

function runDoxygen(configPath = 'Doxyfile') {
  if (!cmdExists('doxygen')) return console.warn('doxygen not found.');
  run(`doxygen ${configPath}`, { stdio: 'inherit' });
  writeSourceHint('Doxygen', configPath, 'C/C++/Java documentation');
}

// -------------------- Transformation: HTML -> React --------------------
async function transformHtmlToReactComponent(htmlPath, features, inspiration, sourceUrl) {
  const outDir = path.join(OUTPUT_DIR, 'frontend', 'react');
  ensureDir(outDir);
  const html = fs.readFileSync(htmlPath, 'utf8');
  let transformedHtml = html
    .replace(/class=/g, 'className=')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  transformedHtml = transformedHtml.replace(/<div([^>]*)>/g,
    '<div$1 style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>');

  const darkModeToggle = `
    <button onClick={() => document.body.classList.toggle('dark-mode')}>
      Dark Mode wechseln
    </button>
  `;
  const featuresList = features.map(f => `- ${f}`).join('\n');
  const sourceComment = `
/*
  Universal Allrounder Analyse-Skript
  Inspiriert von: ${inspiration}
  Quelle: ${sourceUrl}
  Erweiterungen:
${featuresList}
  Hinweis: Analysiert, transformiert & erweitert für Forschungszwecke.
  Keine 1:1-Kopie, sondern eigenständige Weiterentwicklung!
*/
`;
  const component = `
${sourceComment}
import React from "react";
export default function ExtendedComponent() {
  return (
    <div>
      {/* Erweiterung: Dark Mode Toggle */}
      ${darkModeToggle}
      {/* Hauptinhalt aus Analyse, mit Responsive Grid */}
      ${transformedHtml}
    </div>
  );
}
`;
  writeText(path.join(outDir, 'ExtendedComponent.jsx'), component);
  writeSourceHint('Transform (HTML -> React)', htmlPath, 'Refactor + Features (Responsive, Dark Mode, Live API)');
}

// -------------------- Orchestration --------------------
async function runProfile(profile) {
  console.log(stamp(`Running profile: ${profile}`));
  const src = path.resolve(config.paths.sourceCode);
  const url = config.web.targetUrl;
  const bin = config.paths.binaryFile ? path.resolve(config.paths.binaryFile) : '';
  const spec = config.paths.openApiSpec ? path.resolve(config.paths.openApiSpec) : '';
  const postman = config.paths.postmanCollection ? path.resolve(config.paths.postmanCollection) : '';
  const image = config.container.image;

  switch (profile) {
    case 'frontend':
      await extractWithPuppeteer(url);
      await runLighthouse(url);
      runPa11y(url);
      {
        const rawHtml = path.join(OUTPUT_DIR, 'frontend', 'raw.html');
        if (exists(rawHtml)) await transformHtmlToReactComponent(rawHtml, config.features, config.meta.inspiration, url);
      }
      break;
    case 'backend':
      runSemgrep(src);
      runESLint(src);
      runPrettierWrite(src);
      runBandit(src);
      runFindSecBugs(src);
      runSonarScanner(src);
      runSnyk(src);
      runBlackDuckDetect(src);
      runSyftSBOM(image || src);
      runCycloneDX(src);
      runKICS(src);
      runTfsec(src);
      if (bin) {
        runGhidra(bin);
        runRadare(bin);
      }
      break;
    case 'api':
      await analyzeOpenAPI(spec);
      parsePostman(postman);
      runSchemathesis(spec, process.env.API_BASE_URL || '');
      break;
    case 'security':
      runGitleaks(src);
      runTruffleHog(src);
      runTrivy(image || src);
      if (image && cmdExists('grype')) runGrype(image);
      break;
    case 'docs':
      runJSDoc(src);
      runDoxygen('Doxyfile');
      break;
    case 'full':
    default:
      // Run core tasks, some in parallel where sensible
      await extractWithPuppeteer(url);
      await runLighthouse(url);
      runPa11y(url);

      runSemgrep(src);
      runESLint(src);
      runPrettierWrite(src);
      runBandit(src);
      runFindSecBugs(src);
      runSonarScanner(src);

      runSnyk(src);
      runBlackDuckDetect(src);
      runSyftSBOM(image || src);
      runCycloneDX(src);

      runKICS(src);
      runTfsec(src);

      if (bin) {
        runGhidra(bin);
        runRadare(bin);
      }

      await analyzeOpenAPI(spec);
      parsePostman(postman);
      runSchemathesis(spec, process.env.API_BASE_URL || '');

      runTrivy(image || src);
      if (image && cmdExists('grype')) runGrype(image);

      runJSDoc(src);
      runDoxygen('Doxyfile');

      {
        const rawHtml = path.join(OUTPUT_DIR, 'frontend', 'raw.html');
        if (exists(rawHtml)) await transformHtmlToReactComponent(rawHtml, config.features, config.meta.inspiration, url);
      }
  }
}

(async function main() {
  await runProfile(argv.profile);
  console.log(stamp('Done. See output directory for results.'));
})();