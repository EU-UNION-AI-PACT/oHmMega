# Clean Coding Leitfaden (Monorepo, pnpm)

Ziele
- Einheitlicher Stil (Prettier), strikte Typisierung (TS), klare Abhängigkeiten, kleine, testbare Module.
- Qualität “früh abfangen” (pre-commit), CI prüft Build/Lint/Test.

Grundprinzipien
- Single Responsibility: Jedes Modul eine Aufgabe.
- Explizite Schnittstellen: Types exportieren, keine impliziten “Magie”-Hoists.
- Pure Functions bevorzugen, Seiteneffekte isolieren (Adapter/Ports).
- Fehlertypen: Result<T>/Error-Objekte statt “throw-anywhere”.
- Naming: Verben für Funktionen, Substantive für Typen/Klassen. Keine Abkürzungs-Rätsel.

Ordnerstruktur
- apps/<name>: ausführbare Apps/CLI/GUI
- packages/<scope>/<name> oder packages/<name>: Bibliotheken/Agents/Connectoren
- infra/: Docker/K8s/CI/Release
- tools/: Hilfsskripte (Qualitäts-Scanner, Migrations)

Konventionen
- Exporte: Bevorzuge named exports (keine default exports).
- Imports: Relativ innerhalb des Pakets, workspace-übergreifend via Workspace-Alias.
- Public API: index.ts pro Package, intern in /src/* kapseln.
- Fehlerbehandlung: Result<T> oder gezielte Fehlerklassen, niemals leere catch-Blöcke.

Qualitätsregeln
- Formatting: Prettier als “single source of truth”.
- Lint: ESLint (flat config) + @typescript-eslint, keine unbenutzten Variablen/Imports.
- TypeScript: strict, noImplicitOverride, noUncheckedIndexedAccess.
- Tests: Mindestens 1 Test-Datei pro Package (kann initial als TODO markiert werden).
- Commits: Conventional Commits (feat/fix/chore/docs/refactor/test/build/ci).

Abläufe
- Lokal: `pnpm format`, `pnpm lint`, `pnpm typecheck`, `pnpm test`
- Pre-commit: läuft automatisch (lint-staged) auf geänderten Dateien.
- CI: baut, lintet, testet. Artefakte/Reports optional.

Qualitäts-Scanner
- `pnpm quality:scan` findet TODO/FIXME, fehlende README/Tests und große Dateien im Repo.
