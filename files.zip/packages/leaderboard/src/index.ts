import fs from 'node:fs';
import path from 'node:path';

export type ProviderDef = {
  name: string;
  type: 'openai' | 'azure' | 'openai-compatible';
  model?: string;
  deployment?: string;
  baseURL?: string;
  apiVersion?: string;
  pricing?: { input_per_1k?: number; output_per_1k?: number };
};

export type TaskDef = {
  id: string;
  prompt: string;
  expected?: { method: 'exact' | 'regex' | 'contains' | 'token-f1'; value?: string; keywords?: string[] };
  weight?: number;
};

export type Config = {
  providers: ProviderDef[];
  tasks: TaskDef[];
  request?: { temperature?: number; maxOutputTokens?: number };
};

function norm(s: string) {
  return s.toLowerCase().trim().replace(/\s+/g, ' ');
}
function score(task: TaskDef, answer: string): number {
  const exp = task.expected;
  if (!exp) return NaN;
  if (exp.method === 'exact') return norm(exp.value || '') === norm(answer) ? 1 : 0;
  if (exp.method === 'regex') {
    try { return new RegExp(exp.value || '', 'is').test(answer) ? 1 : 0; } catch { return 0; }
  }
  if (exp.method === 'contains') {
    const p = norm(answer); const keys = (exp.keywords || []).map(norm);
    return keys.every((k) => p.includes(k)) ? 1 : 0;
  }
  // token-f1
  const gs = new Set(norm(exp.value || '').split(' ').filter(Boolean));
  const ps = new Set(norm(answer).split(' ').filter(Boolean));
  const inter = new Set([...gs].filter((x) => ps.has(x)));
  const precision = ps.size ? inter.size / ps.size : 0;
  const recall = gs.size ? inter.size / gs.size : 0;
  return precision + recall ? (2 * precision * recall) / (precision + recall) : 0;
}

function estTokens(txt: string) { return Math.max(1, Math.ceil((txt || '').length / 4)); }
function costUSD(pr: ProviderDef['pricing'], inTok: number, outTok: number) {
  const a = pr?.input_per_1k || 0, b = pr?.output_per_1k || 0;
  return (inTok / 1000) * a + (outTok / 1000) * b;
}

// Minimal chat for three provider shapes (no deps)
async function chat(provider: ProviderDef, prompt: string, opts: { temperature?: number; maxTokens?: number }) {
  if (provider.type === 'openai' || provider.type === 'openai-compatible') {
    const apiKey = provider.type === 'openai' ? process.env.OPENAI_API_KEY : process.env.OPENAI_COMPAT_API_KEY || '';
    const baseURL = provider.type === 'openai' ? 'https://api.openai.com/v1' : (provider.baseURL || 'http://localhost:8000/v1');
    const model = provider.model!;
    const resp = await fetch(`${baseURL.replace(/\/+$/,'')}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(apiKey ? { 'Authorization': `Bearer ${apiKey}` } : {}) },
      body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], temperature: opts.temperature ?? 0.2, max_tokens: opts.maxTokens ?? 512 })
    });
    if (!resp.ok) throw new Error(`${provider.type} ${resp.status}`);
    const j: any = await resp.json();
    return j.choices?.[0]?.message?.content || j.choices?.[0]?.text || '';
  }
  // azure
  const apiKey = process.env.AZURE_OPENAI_API_KEY || '';
  const endpoint = process.env.AZURE_OPENAI_ENDPOINT || '';
  const deployment = provider.deployment!;
  const apiVersion = provider.apiVersion || '2024-06-01';
  const url = `${endpoint.replace(/\/+$/,'')}/openai/deployments/${encodeURIComponent(deployment)}/chat/completions?api-version=${apiVersion}`;
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
    body: JSON.stringify({ messages: [{ role: 'user', content: prompt }], temperature: opts.temperature ?? 0.2, max_tokens: opts.maxTokens ?? 512 })
  });
  if (!resp.ok) throw new Error(`azure ${resp.status}`);
  const j: any = await resp.json();
  return j.choices?.[0]?.message?.content || '';
}

export async function runLeaderboard(cfg: Config) {
  const req = cfg.request || {};
  const results: any[] = [];
  const agg: Record<string, { runs: number; latency: number; qualitySum: number | null; cost: number }> = {};
  for (const p of cfg.providers) {
    for (const t of cfg.tasks) {
      const inTok = estTokens(t.prompt);
      const start = Date.now();
      let answer = '';
      try {
        answer = await chat(p, t.prompt, { temperature: req.temperature, maxTokens: req.maxOutputTokens });
      } catch (e: any) {
        results.push({ provider: p.name, model: p.model || p.deployment, task: t.id, error: e?.message || String(e) });
        continue;
      }
      const latency = Date.now() - start;
      const outTok = estTokens(answer);
      const cost = costUSD(p.pricing, inTok, outTok);
      const q = score(t, answer);
      const key = `${p.name}::${p.model || p.deployment}`;
      if (!agg[key]) agg[key] = { runs: 0, latency: 0, qualitySum: 0, cost: 0 };
      agg[key].runs++; agg[key].latency += latency; agg[key].cost += cost;
      if (!Number.isNaN(q)) agg[key].qualitySum = (agg[key].qualitySum || 0) + q;
      results.push({ provider: p.name, model: p.model || p.deployment, task: t.id, latency, inTok, outTok, cost, quality: Number.isNaN(q) ? null : q, answer });
    }
  }
  const aggregates = Object.entries(agg).map(([k, v]) => {
    const [label, model] = k.split('::');
    return {
      label, model, runs: v.runs,
      avgLatency: Number((v.latency / v.runs).toFixed(1)),
      avgQuality: v.qualitySum === null ? null : Number(((v.qualitySum || 0) / v.runs).toFixed(3)),
      totalCost: Number(v.cost.toFixed(4))
    };
  });
  return { results, aggregates };
}

export function saveReports(outDir: string, data: Awaited<ReturnType<typeof runLeaderboard>>) {
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, 'leaderboard.json'), JSON.stringify(data, null, 2), 'utf-8');

  const speed = [...data.aggregates].sort((a, b) => (a.avgLatency ?? Infinity) - (b.avgLatency ?? Infinity));
  const quality = [...data.aggregates].sort((a, b) => (b.avgQuality ?? -1) - (a.avgQuality ?? -1));
  const cost = [...data.aggregates].sort((a, b) => a.totalCost - b.totalCost);

  const md = [
    '# Leaderboard',
    '',
    '## Speed',
    '',
    '| Rank | Label | Model | Avg Latency (ms) | Runs |',
    '|------|-------|-------|------------------:|-----:|',
    ...speed.map((r, i) => `| ${i + 1} | ${r.label} | ${r.model} | ${r.avgLatency} | ${r.runs} |`),
    '',
    '## Quality',
    '',
    '| Rank | Label | Model | Avg Quality | Runs |',
    '|------|-------|-------|------------:|-----:|',
    ...quality.map((r, i) => `| ${i + 1} | ${r.label} | ${r.model} | ${r.avgQuality ?? '-'} | ${r.runs} |`),
    '',
    '## Cost',
    '',
    '| Rank | Label | Model | Total Cost (USD) | Runs |',
    '|------|-------|-------|-----------------:|-----:|',
    ...cost.map((r, i) => `| ${i + 1} | ${r.label} | ${r.model} | ${r.totalCost.toFixed(4)} | ${r.runs} |`)
  ].join('\n');

  fs.writeFileSync(path.join(outDir, 'leaderboard.md'), md, 'utf-8');

  const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Leaderboard</title>
<style>body{font-family:system-ui,Arial;margin:24px} table{border-collapse:collapse;margin:12px 0} td,th{border:1px solid #ddd;padding:6px}</style>
</head><body>
<h1>Leaderboard</h1>
<pre>Generated: ${new Date().toISOString()}</pre>
${md.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
</body></html>`;
  fs.writeFileSync(path.join(outDir, 'leaderboard.html'), html, 'utf-8');
}