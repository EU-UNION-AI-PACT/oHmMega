import fs from 'fs';
import path from 'path';

export type DocChunk = { id: string; text: string; meta?: Record<string, any>; vec: number[] };
export type StoreIndex = { chunks: DocChunk[] };

function hashStr(s: string) { // simple n-gram hash -> pseudo embedding
  const v = new Array(64).fill(0);
  const lower = s.toLowerCase();
  for (let i = 0; i < lower.length - 2; i++) {
    const trig = lower.slice(i, i+3);
    const h = [...trig].reduce((a,c)=>a + c.charCodeAt(0), 0) % v.length;
    v[h] += 1;
  }
  const norm = Math.sqrt(v.reduce((a,c)=>a + c*c, 0)) || 1;
  return v.map(x => x / norm);
}

function cosine(a: number[], b: number[]) {
  let s = 0; for (let i = 0; i < Math.min(a.length, b.length); i++) s += a[i]*b[i];
  return s;
}

export class FileRagStore {
  constructor(private dir = '.rag-store') {}
  private idxPath() { return path.resolve(this.dir, 'index.json'); }

  async indexPaths(paths: string[]) {
    fs.mkdirSync(this.dir, { recursive: true });
    const chunks: DocChunk[] = [];
    for (const p of paths) {
      const stat = fs.statSync(p);
      if (stat.isDirectory()) {
        for (const f of fs.readdirSync(p)) {
          const full = path.join(p, f);
          if (fs.statSync(full).isFile()) await this.indexPaths([full]);
        }
      } else {
        const text = fs.readFileSync(p, 'utf-8');
        const parts = text.split(/\n{2,}/g).map(s => s.trim()).filter(Boolean);
        for (let i = 0; i < parts.length; i++) {
          const id = `${p}#${i}`;
          chunks.push({ id, text: parts[i], meta: { source: p, chunk: i }, vec: hashStr(parts[i]) });
        }
      }
    }
    const existing = this.loadIndex();
    const merged = [...(existing?.chunks || []), ...chunks];
    fs.writeFileSync(this.idxPath(), JSON.stringify({ chunks: merged }, null, 2));
    return merged.length;
  }

  loadIndex(): StoreIndex | null {
    if (!fs.existsSync(this.idxPath())) return null;
    return JSON.parse(fs.readFileSync(this.idxPath(), 'utf-8'));
  }

  search(query: string, k = 5) {
    const idx = this.loadIndex();
    if (!idx) return [];
    const qv = hashStr(query);
    const scored = idx.chunks.map(ch => ({ ch, score: cosine(qv, ch.vec) }));
    scored.sort((a,b)=>b.score - a.score);
    return scored.slice(0, k).map(s => s.ch);
  }
}