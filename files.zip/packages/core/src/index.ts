export type Result<T> = { ok: true; value: T } | { ok: false; error: string };
export const ok = <T>(value: T): Result<T> => ({ ok: true, value });
export const err = (error: string): Result<never> => ({ ok: false, error });

export async function sh(cmd: string, args: string[] = [], opts: { cwd?: string } = {}) {
  const { spawn } = await import('node:child_process');
  return new Promise<{ code: number; stdout: string; stderr: string }>((resolve, reject) => {
    const p = spawn(cmd, args, { cwd: opts.cwd, shell: false });
    let out = '', err = '';
    p.stdout.on('data', d => out += d.toString());
    p.stderr.on('data', d => err += d.toString());
    p.on('error', reject);
    p.on('close', code => resolve({ code: code ?? 0, stdout: out.trim(), stderr: err.trim() }));
  });
}

export async function withRetries<T>(fn: () => Promise<T>, retries = 2, delayMs = 400) {
  let attempt = 0;
  while (true) {
    try { return await fn(); }
    catch (e) {
      if (attempt++ >= retries) throw e;
      await new Promise(r => setTimeout(r, delayMs * attempt));
    }
  }
}

export class AsyncRunner {
  private queue: (() => Promise<void>)[] = [];
  private running = 0;
  constructor(private concurrency = 3) {}
  add(job: () => Promise<void>) { this.queue.push(job); }
  async runAll() {
    return new Promise<void>(resolve => {
      const next = () => {
        if (!this.queue.length && this.running === 0) return resolve();
        while (this.running < this.concurrency && this.queue.length) {
          const job = this.queue.shift()!;
          this.running++;
          job().finally(() => { this.running--; next(); });
        }
      };
      next();
    });
  }
}