import { sh } from "@euaic/core";

export async function getPods(ns?: string) {
  const args = ['get', 'pods', '-o', 'json'];
  if (ns) args.splice(1, 0, '-n', ns);
  const { code, stdout, stderr } = await sh('kubectl', args);
  if (code !== 0) throw new Error(stderr || 'kubectl get pods failed');
  const data = JSON.parse(stdout);
  return (data.items || []).map((p: any) => ({
    name: p.metadata?.name,
    namespace: p.metadata?.namespace,
    phase: p.status?.phase,
    node: p.spec?.nodeName
  }));
}

export async function applyYaml(filePath: string) {
  const { code, stdout, stderr } = await sh('kubectl', ['apply', '-f', filePath]);
  if (code !== 0) throw new Error(stderr || 'kubectl apply failed');
  return stdout;
}