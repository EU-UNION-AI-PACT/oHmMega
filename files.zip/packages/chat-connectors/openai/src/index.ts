export type ChatClient = { chat(model: string, prompt: string, opts?: { temperature?: number; maxTokens?: number }): Promise<string> };

export function makeOpenAI(apiKey = process.env.OPENAI_API_KEY, baseURL = 'https://api.openai.com/v1'): ChatClient {
  return {
    async chat(model, prompt, opts = {}) {
      const res = await fetch(`${baseURL.replace(/\/+$/,'')}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
        body: JSON.stringify({
          model, messages: [{ role: 'user', content: prompt }],
          temperature: opts.temperature ?? 0.2,
          max_tokens: opts.maxTokens ?? 512
        })
      });
      if (!res.ok) throw new Error(`OpenAI ${res.status}`);
      const json: any = await res.json();
      return json.choices?.[0]?.message?.content || '';
    }
  };
}

export function makeAzureOpenAI(apiKey = process.env.AZURE_OPENAI_API_KEY, endpoint = process.env.AZURE_OPENAI_ENDPOINT, apiVersion = '2024-06-01'): ChatClient {
  return {
    async chat(deployment, prompt, opts = {}) {
      const url = `${endpoint?.replace(/\/+$/,'')}/openai/deployments/${encodeURIComponent(deployment)}/chat/completions?api-version=${apiVersion}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'api-key': apiKey || '' },
        body: JSON.stringify({
          messages: [{ role: 'user', content: prompt }],
          temperature: opts.temperature ?? 0.2,
          max_tokens: opts.maxTokens ?? 512
        })
      });
      if (!res.ok) throw new Error(`Azure OpenAI ${res.status}`);
      const json: any = await res.json();
      return json.choices?.[0]?.message?.content || '';
    }
  };
}

export function makeOpenAICompatible(baseURL = process.env.OPENAI_COMPAT_BASEURL || 'http://localhost:8000/v1', apiKey = process.env.OPENAI_COMPAT_API_KEY || ''): ChatClient {
  return {
    async chat(model, prompt, opts = {}) {
      const res = await fetch(`${baseURL.replace(/\/+$/,'')}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(apiKey ? { 'Authorization': `Bearer ${apiKey}` } : {}) },
        body: JSON.stringify({
          model, messages: [{ role: 'user', content: prompt }],
          temperature: opts.temperature ?? 0.2,
          max_tokens: opts.maxTokens ?? 512
        })
      });
      if (!res.ok) throw new Error(`OpenAI-Compat ${res.status}`);
      const json: any = await res.json();
      return json.choices?.[0]?.message?.content || json.choices?.[0]?.text || '';
    }
  };
}