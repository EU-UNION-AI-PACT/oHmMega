import { sh } from "@euaic/core";

export type DockerPsItem = { id: string; image: string; command: string; status: string; names: string; };
export async function dockerPs(all = false): Promise<DockerPsItem[]> {
  const format = '{{.ID}}\t{{.Image}}\t{{.Command}}\t{{.Status}}\t{{.Names}}';
  const args = ['ps', '--format', format];
  if (all) args.splice(1, 0, '-a');
  const { code, stdout, stderr } = await sh('docker', args);
  if (code !== 0) throw new Error(stderr || 'docker ps failed');
  return stdout.split('\n').filter(Boolean).map(line => {
    const [id, image, command, status, names] = line.split('\t');
    return { id, image, command, status, names };
  });
}

export async function dockerImages(): Promise<{ repository: string; tag: string; id: string; size: string }[]> {
  const format = '{{.Repository}}\t{{.Tag}}\t{{.ID}}\t{{.Size}}';
  const { code, stdout, stderr } = await sh('docker', ['images', '--format', format]);
  if (code !== 0) throw new Error(stderr || 'docker images failed');
  return stdout.split('\n').filter(Boolean).map(line => {
    const [repository, tag, id, size] = line.split('\t');
    return { repository, tag, id, size };
  });
}