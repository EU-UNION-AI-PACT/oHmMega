import { makeOpenAI, makeAzureOpenAI, makeOpenAICompatible } from "@euaic/chat-openai";

export type CodingMode = 'lazy' | 'vibing' | 'rag-coding' | 'async';
export type Provider = { kind: 'openai'|'azure'|'compat'; model: string };

function promptFor(mode: CodingMode, task: string) {
  if (mode === 'lazy') return `Erstelle eine minimal lauffähige Lösung, nur Kernlogik. Aufgabe:\n${task}\nLösung:`;
  if (mode === 'vibing') return `Schreibe eine elegante, gut dokumentierte Lösung mit Best Practices, aber pragmatisch. Aufgabe:\n${task}\nLösung:`;
  if (mode === 'rag-coding') return `Nutze bekannte Patterns und kommentiere, welche du anwendest. Aufgabe:\n${task}\nLösung:`;
  return `Skizziere asynchrone Teilschritte (Jobs), dann implementiere die erste Iteration. Aufgabe:\n${task}\nAntwort:`;
}

export async function codeAssist(task: string, mode: CodingMode, provider: Provider) {
  const client =
    provider.kind === 'openai' ? makeOpenAI() :
    provider.kind === 'azure' ? makeAzureOpenAI() :
    makeOpenAICompatible();
  const prompt = promptFor(mode, task);
  return client.chat(provider.model, prompt, { temperature: mode === 'vibing' ? 0.5 : 0.2, maxTokens: 800 });
}