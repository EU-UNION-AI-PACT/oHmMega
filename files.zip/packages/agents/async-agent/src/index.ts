import { AsyncRunner } from "@euaic/core";

export class AsyncAgent {
  constructor(private concurrency = 3) {}
  async run<T>(items: T[], worker: (item: T) => Promise<void>) {
    const runner = new AsyncRunner(this.concurrency);
    for (const it of items) runner.add(() => worker(it));
    await runner.runAll();
  }
}