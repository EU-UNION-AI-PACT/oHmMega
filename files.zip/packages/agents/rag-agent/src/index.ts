import { FileRagStore } from "@euaic/rag-store-file";
import { makeOpenAI, makeAzureOpenAI, makeOpenAICompatible } from "@euaic/chat-openai";

export type RAGOptions = { provider: 'openai'|'azure'|'compat'; modelOrDeployment: string; };
export async function ragAnswer(query: string, opts: RAGOptions, k = 5): Promise<string> {
  const store = new FileRagStore('.rag-store');
  const ctx = store.search(query, k);
  const context = ctx.map(c => `- ${c.text}`).join('\n');
  const prompt = `Nutze den folgenden Kontext, um präzise zu antworten.\nKontext:\n${context}\n\nFrage: ${query}\nAntwort:`;
  const client =
    opts.provider === 'openai' ? makeOpenAI() :
    opts.provider === 'azure' ? makeAzureOpenAI() :
    makeOpenAICompatible();
  return client.chat(opts.modelOrDeployment, prompt, { temperature: 0.2, maxTokens: 400 });
}