export type SearchHit = { title: string; url: string; snippet?: string; source: string; };
export type SearchProvider = { name: string; search(q: string, n?: number): Promise<SearchHit[]> };

export function makeBing(): SearchProvider {
  const key = process.env.BING_API_KEY || '';
  return {
    name: 'bing',
    async search(q, n = 5) {
      const url = `https://api.bing.microsoft.com/v7.0/search?q=${encodeURIComponent(q)}&count=${n}`;
      const res = await fetch(url, { headers: { 'Ocp-Apim-Subscription-Key': key } });
      if (!res.ok) return [];
      const j: any = await res.json();
      const web = j.webPages?.value || [];
      return web.map((w: any) => ({ title: w.name, url: w.url, snippet: w.snippet, source: 'bing' }));
    }
  };
}

export function makeTavily(): SearchProvider {
  const key = process.env.TAVILY_API_KEY || '';
  return {
    name: 'tavily',
    async search(q, n = 5) {
      const res = await fetch('https://api.tavily.com/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
        body: JSON.stringify({ query: q, max_results: n })
      });
      if (!res.ok) return [];
      const j: any = await res.json();
      return (j.results || []).map((r: any) => ({ title: r.title, url: r.url, snippet: r.content, source: 'tavily' }));
    }
  };
}

export function makeSerpApi(): SearchProvider {
  const key = process.env.SERPAPI_KEY || '';
  return {
    name: 'serpapi',
    async search(q, n = 5) {
      const url = `https://serpapi.com/search.json?q=${encodeURIComponent(q)}&num=${n}&engine=google&api_key=${key}`;
      const res = await fetch(url);
      if (!res.ok) return [];
      const j: any = await res.json();
      const org = j.organic_results || [];
      return org.map((r: any) => ({ title: r.title, url: r.link, snippet: r.snippet, source: 'serpapi' }));
    }
  };
}

export async function deepSearch(query: string, providers: SearchProvider[], n = 5): Promise<SearchHit[]> {
  const batches = await Promise.allSettled(providers.map(p => p.search(query, n)));
  const hits = batches.flatMap(b => b.status === 'fulfilled' ? b.value : []);
  // naive dedupe by url
  const seen = new Set<string>(), out: SearchHit[] = [];
  for (const h of hits) { if (!seen.has(h.url)) { seen.add(h.url); out.push(h); } }
  return out;
}