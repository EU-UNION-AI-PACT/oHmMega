import fs from 'node:fs';
import path from 'node:path';

export type ToolSpec = {
  name: string;
  title?: string;
  description?: string;
  inputSchema?: unknown;
  outputSchema?: unknown;
  tags?: string[];
  // endpoint, exec, or agent reference can be added here later
};

export type ToolsRegistry = {
  version: string;
  tools: ToolSpec[];
};

const DEFAULT_PATH = path.resolve('config', 'tools.registry.json');

export function loadRegistry(filePath = DEFAULT_PATH): ToolsRegistry {
  const p = path.resolve(filePath);
  if (!fs.existsSync(p)) {
    throw new Error(`Tools registry not found at ${p}`);
  }
  const raw = fs.readFileSync(p, 'utf-8');
  const data = JSON.parse(raw);
  return data as ToolsRegistry;
}

// Extension point: swap to “universal_allrounder.ts” later.
// Example:
// export async function loadRegistryFromModule(modPath: string): Promise<ToolsRegistry> {
//   const mod = await import(path.resolve(modPath));
//   return mod.buildRegistry(); // ensure the module exports a builder returning ToolsRegistry
// }