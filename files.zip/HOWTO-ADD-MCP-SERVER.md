# MCP Server hinzufügen

1) NPM
```json
{
  "name": "mcp-http-toolkit",
  "install": { "type": "npm", "ref": "@your-scope/mcp-http-toolkit" },
  "run": { "command": "mcp-http-toolkit", "args": ["--stdio"], "env": {} },
  "layer": 5
}
```

2) pipx
```json
{
  "name": "mcp_server_ml",
  "install": { "type": "pipx", "ref": "mcp_server_ml" },
  "run": { "command": "mcp_server_ml", "args": ["--stdio"], "env": { "HF_TOKEN": "${HF_TOKEN}" } },
  "layer": 7
}
```

3) Go
```json
{
  "name": "mcp-go-elastic",
  "install": { "type": "go", "ref": "github.com/your-org/mcp-go-elastic/cmd/mcp-go-elastic" },
  "run": { "command": "mcp-go-elastic", "args": ["--stdio","--url","http://localhost:9200"] },
  "layer": 4
}
```

4) Binary
```json
{
  "name": "mcp-elastic-bin",
  "install": { "type": "binary", "ref": "https://downloads.example.com/mcp-elastic_1.2.3_linux_amd64.tar.gz" },
  "run": { "command": "mcp-elastic", "args": ["--stdio","--url","http://localhost:9200"] },
  "layer": 6
}
```

5) Git + Post
```json
{
  "name": "mcp-openapi-proxy",
  "install": { "type": "git", "ref": "https://github.com/your-org/mcp-openapi-proxy.git", "post": "npm i -g ." },
  "run": { "command": "mcp-openapi-proxy", "args": ["--stdio","--spec","./api/openapi.yaml"] },
  "layer": 8
}
```

Connectoren (Graph)
- Datei: `config/mcp/connectors.graph.json` wird vom Generator erstellt.
- Kante: `{ "from": "nodeA", "to": "nodeB", "type": "depends_on" }` bedeutet: B hängt von A ab.
- Plane/Installiere immer nach topologischer Ordnung (Planer kümmert sich darum).

Tipps
- Nutze `layer` um grobe Reihenfolge vorzugeben; Connectoren erzwingen die feingranulare Reihenfolge.
- Achte auf eindeutige `name` und `run.command` (der Generator erzwingt Einzigartigkeit).