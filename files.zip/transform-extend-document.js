const fs = require('fs');
const path = require('path');

/**
 * Konfiguration
 */
const INPUT_HTML_PATH = './output/raw.html'; // HTML, aus der Analyse extrahiert
const OUTPUT_DIR = './output';               // Zielordner für Ergebnis
const SOURCE_URL = 'https://example.com';    // Ursprungsquelle
const INSPIRATION = 'Vapi.ai';               // Inspirationsquelle
const OWN_FEATURES = [
  'Responsive Grid hinzugefügt',
  'Dark Mode Unterstützung',
  'Neue API-Integration für Live-Daten'
]; // Deine Erweiterungen

/**
 * Transformation & Erweiterung: HTML zu React-Komponente + eigene Features
 */
function transformHtmlToReactComponent(html, features, sourceUrl, inspiration) {
  // Beispielhafte Transformation
  let transformedHtml = html
    .replace(/class=/g, 'className=')             // React-kompatibel
    .replace(/<script[\s\S]*?<\/script>/gi, '')   // Skripte entfernen
    .replace(/<!--[\s\S]*?-->/g, '')              // Kommentare entfernen

  // Beispiel-Erweiterung: Responsive Grid (nur als Demo)
  transformedHtml = transformedHtml.replace(
    /<div([^>]*)>/g,
    '<div$1 style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>'
  );

  // Beispiel-Erweiterung: Dark Mode Toggle (nur als Platzhalter)
  const darkModeToggle = `
    <button onClick={() => document.body.classList.toggle('dark-mode')}>
      Dark Mode wechseln
    </button>
  `;

  // Quellhinweis generieren
  const featuresList = features.map(f => `- ${f}`).join('\n');
  const sourceComment = `
/*
  Inspiriert von: ${inspiration}
  Quelle: ${sourceUrl}
  Erweiterungen:
${featuresList}
  Hinweis: Analysiert, transformiert & erweitert für Forschungszwecke.
  Keine 1:1-Kopie, sondern eigenständige Weiterentwicklung!
*/
`;

  // React-Komponente als String
  return `
${sourceComment}
import React from "react";
export default function ExtendedComponent() {
  return (
    <div>
      {/* Erweiterung: Dark Mode Toggle */}
      ${darkModeToggle}
      {/* Hauptinhalt aus Analyse, mit Responsive Grid */}
      ${transformedHtml}
    </div>
  );
}
  `;
}

/**
 * Hauptfunktion
 */
function main() {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  const html = fs.readFileSync(INPUT_HTML_PATH, 'utf8');

  const reactComponentCode = transformHtmlToReactComponent(
    html,
    OWN_FEATURES,
    SOURCE_URL,
    INSPIRATION
  );

  fs.writeFileSync(path.join(OUTPUT_DIR, 'ExtendedComponent.jsx'), reactComponentCode);

  // Quellhinweis auch in README ablegen
  const readmeBlock = `
Dieses Modul basiert auf einer Analyse und Inspiration durch ${INSPIRATION} (${SOURCE_URL}).
Erweiterungen:
${OWN_FEATURES.map(f => `- ${f}`).join('\n')}

Alle Komponenten wurden refaktoriert und erweitert, keine 1:1-Kopie!
Dieses Projekt dient Forschungs- und Entwicklungszwecken.
  `;
  fs.writeFileSync(path.join(OUTPUT_DIR, 'README.md'), readmeBlock);

  console.log('Transformation, Erweiterung & Quellhinweis erfolgreich!');
}

main();