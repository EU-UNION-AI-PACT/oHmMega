const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

/**
 * Konfiguration
 */
const TARGET_URL = 'https://example.com';          // Zielwebseite
const OUTPUT_DIR = './output';                     // Speicherort
const INSPIRATION = 'Vapi.ai';                     // Inspirationsquelle
const OWN_EXTENSIONS = [
  'Responsive Grid hinzugefügt',
  'Dark Mode Unterstützung',
  'Eigene API-Integration für Live-Daten'
]; // Beispiel-Erweiterungen

/**
 * Schritt 1: Analyse – HTML, CSS, Assets extrahieren
 */
async function analyzeWebpage() {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto(TARGET_URL, { waitUntil: 'networkidle2' });

  // HTML extrahieren
  const html = await page.content();
  fs.writeFileSync(path.join(OUTPUT_DIR, 'raw.html'), html);

  // CSS extrahieren
  const cssLinks = await page.evaluate(() =>
    Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(link => link.href)
  );
  for (const cssUrl of cssLinks) {
    try {
      const res = await page.goto(cssUrl);
      fs.writeFileSync(path.join(OUTPUT_DIR, path.basename(cssUrl)), await res.buffer());
    } catch (e) {}
  }

  // Assets extrahieren (Bilder)
  const assets = await page.evaluate(() => Array.from(document.images).map(img => img.src));
  for (const assetUrl of assets) {
    try {
      const assetName = path.basename(assetUrl.split('?')[0]);
      const view = await page.goto(assetUrl);
      fs.writeFileSync(path.join(OUTPUT_DIR, assetName), await view.buffer());
    } catch (e) {}
  }

  await browser.close();
}

/**
 * Schritt 2: Transformation – HTML zu React-Komponente (+ Erweiterungen)
 */
function transformHtmlToReactComponent(html, extensions, inspiration, sourceUrl) {
  let transformedHtml = html
    .replace(/class=/g, 'className=')             // React-kompatibel
    .replace(/<script[\s\S]*?<\/script>/gi, '')   // Skripte entfernen
    .replace(/<!--[\s\S]*?-->/g, '');             // Kommentare entfernen

  // Beispiel-Erweiterung: Responsive Grid
  transformedHtml = transformedHtml.replace(
    /<div([^>]*)>/g,
    '<div$1 style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>'
  );

  // Beispiel-Erweiterung: Dark Mode Toggle
  const darkModeToggle = `
    <button onClick={() => document.body.classList.toggle('dark-mode')}>
      Dark Mode wechseln
    </button>
  `;

  // Quellhinweis generieren
  const featuresList = extensions.map(f => `- ${f}`).join('\n');
  const sourceComment = `
/*
  Inspiriert von: ${inspiration}
  Quelle: ${sourceUrl}
  Erweiterungen:
${featuresList}
  Hinweis: Analysiert, transformiert & erweitert für Forschungszwecke.
  Keine 1:1-Kopie, sondern eigenständige Weiterentwicklung!
*/
`;

  // React-Komponente als String
  return `
${sourceComment}
import React from "react";
export default function ExtendedComponent() {
  return (
    <div>
      {/* Erweiterung: Dark Mode Toggle */}
      ${darkModeToggle}
      {/* Hauptinhalt aus Analyse, mit Responsive Grid */}
      ${transformedHtml}
    </div>
  );
}
`;
}

/**
 * Schritt 3: Quellhinweis Dokumentation im README
 */
function writeReadme(extensions, inspiration, sourceUrl) {
  const readmeBlock = `
Dieses Modul basiert auf einer Analyse und Inspiration durch ${inspiration} (${sourceUrl}).
Erweiterungen:
${extensions.map(f => `- ${f}`).join('\n')}

Alle Komponenten wurden refaktoriert und erweitert, keine 1:1-Kopie!
Dieses Projekt dient Forschungs- und Entwicklungszwecken.
`;
  fs.writeFileSync(path.join(OUTPUT_DIR, 'README.md'), readmeBlock);
}

/**
 * Orchestrierung: Alle Schritte ausführen
 */
async function main() {
  await analyzeWebpage();
  const html = fs.readFileSync(path.join(OUTPUT_DIR, 'raw.html'), 'utf8');
  const reactComponentCode = transformHtmlToReactComponent(html, OWN_EXTENSIONS, INSPIRATION, TARGET_URL);
  fs.writeFileSync(path.join(OUTPUT_DIR, 'ExtendedComponent.jsx'), reactComponentCode);
  writeReadme(OWN_EXTENSIONS, INSPIRATION, TARGET_URL);
  console.log('Analyse, Transformation & Dokumentation erfolgreich abgeschlossen!');
}

main();