;;; mycli.el --- Simple connector for mycli -*- lexical-binding: t; -*-
(require 'compile)

(defun mycli-run (action)
  "Run mycli ACTION and show output."
  (interactive "smycli action: ")
  (compile (format "mycli run %s" action)))

;; Eglot LSP:
;; (add-to-list 'eglot-server-programs '((mylang-mode) . ("mycli" "lsp")))

(defun mycli-format-buffer ()
  (interactive)
  (let* ((buf (current-buffer))
         (txt (buffer-substring-no-properties (point-min) (point-max)))
         (tmp (make-temp-file "mycli-fmt" nil ".tmp")))
    (with-temp-file tmp (insert txt))
    (shell-command (format "mycli fmt %s" (shell-quote-argument tmp)))
    (revert-buffer :ignore-auto :noconfirm)))

(provide 'mycli)
;;; mycli.el ends here