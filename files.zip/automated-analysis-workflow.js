const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// === Konfiguration ===
const OUTPUT_DIR = './analysis_output';
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

// Beispiel: Passe die Pfade für dein Projekt an!
const paths = {
  sourceCode: './project-src',          // Pfad zum Source-Code (für Semgrep/Snyk)
  binaryFile: './bin/project.exe',      // Pfad zur Binärdatei (für Ghidra)
  openApiSpec: './api/openapi.yml'      // Pfad zur OpenAPI-Datei (für openapi-parser)
};

const extensions = {
  semgrep: 'Automatisierte Mustererkennung & Security-Analyse',
  ghidra: 'Reverse Engineering, Funktionsextraktion',
  snyk: 'Dependency & Vulnerability Analyse',
  openapi: 'API-Endpunkt-Dokumentation'
};

/**
 * 1. Static Analysis mit Semgrep
 */
function runSemgrep(targetPath) {
  try {
    const outFile = path.join(OUTPUT_DIR, 'semgrep.json');
    execSync(`semgrep --config=auto ${targetPath} --json > ${outFile}`);
    return outFile;
  } catch (e) {
    console.error('Semgrep Fehler:', e.message);
    return null;
  }
}

/**
 * 2. Reverse Engineering mit Ghidra (Headless/CLI)
 * Voraussetzung: Ghidra installiert, PATH gesetzt
 */
function runGhidra(binFile) {
  const outDir = path.join(OUTPUT_DIR, 'ghidra');
  fs.mkdirSync(outDir, { recursive: true });
  try {
    execSync(`analyzeHeadless ${outDir} project1 -import ${binFile} -postScript ExtractFunctions.java`);
    return outDir;
  } catch (e) {
    console.error('Ghidra Fehler:', e.message);
    return null;
  }
}

/**
 * 3. Dependency Analyse mit Snyk
 */
function runSnyk(targetPath) {
  try {
    const outFile = path.join(OUTPUT_DIR, 'snyk.json');
    execSync(`snyk test --json > ${outFile}`, { cwd: targetPath });
    return outFile;
  } catch (e) {
    console.error('Snyk Fehler:', e.message);
    return null;
  }
}

/**
 * 4. API Analyse mit openapi-parser
 */
function runOpenApiParser(openApiPath) {
  try {
    const openapi = require('openapi-parser');
    openapi.validate(openApiPath)
      .then(api => {
        fs.writeFileSync(path.join(OUTPUT_DIR, 'openapi-analysis.json'), JSON.stringify(api, null, 2));
      })
      .catch(err => console.error('OpenAPI Fehler:', err));
  } catch (e) {
    console.error('OpenAPI-Parser Fehler:', e.message);
  }
}

/**
 * Quellhinweis automatisch generieren
 */
function writeSourceHint(tool, source, extension) {
  const block = `
Analyse durchgeführt mit: ${tool}
Quelle/Projekt: ${source}
Erweiterungen: ${extension}
Hinweis: Wissenschaftliche Analyse & Weiterentwicklung, keine 1:1-Kopie!
  `;
  fs.appendFileSync(path.join(OUTPUT_DIR, 'README.md'), block + '\n');
}

/**
 * Haupt-Workflow
 */
function main() {
  // 1. Semgrep
  const semgrepResult = runSemgrep(paths.sourceCode);
  writeSourceHint('Semgrep', paths.sourceCode, extensions.semgrep);

  // 2. Ghidra/Decompiler
  const ghidraResult = runGhidra(paths.binaryFile);
  writeSourceHint('Ghidra', paths.binaryFile, extensions.ghidra);

  // 3. Snyk
  const snykResult = runSnyk(paths.sourceCode);
  writeSourceHint('Snyk', paths.sourceCode, extensions.snyk);

  // 4. OpenAPI
  runOpenApiParser(paths.openApiSpec);
  writeSourceHint('OpenAPI-Parser', paths.openApiSpec, extensions.openapi);

  console.log('Automatisierte Analyse abgeschlossen. Siehe analysis_output Ordner.');
}

main();