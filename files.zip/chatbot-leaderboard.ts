#!/usr/bin/env -S node --enable-source-maps
/**
 * Chatbot Leaderboard (TypeScript, runtime dependency-free)
 * Run without build using the precompiled JS in dist/, or compile to JS if desired.
 *
 * CLI:
 *   node dist/chatbot-leaderboard.mjs --config leaderboard.config.json --outdir reports --concurrency 3 --timeout 30s
 *
 * Config schema (see leaderboard.config.example.json):
 *  {
 *    promptsDir: string,
 *    request: { temperature?: number, maxOutputTokens?: number },
 *    run: { retries?: number, timeoutMs?: number, concurrency?: number },
 *    providers: Array<{
 *      name: string, label: string, type: 'openai'|'azure'|'openai-compatible',
 *      model?: string, deployment?: string,
 *      apiVersion?: string, baseURL?: string,
 *      apiKeyEnv: string, endpointEnv?: string,
 *      pricing?: { input_per_1k?: number, output_per_1k?: number }
 *    }>
 *  }
 */
type ProviderType = 'openai' | 'azure' | 'openai-compatible';
type Pricing = { input_per_1k?: number; output_per_1k?: number };
type ProviderCfg = {
  name: string; label: string; type: ProviderType;
  model?: string; deployment?: string; apiVersion?: string; baseURL?: string;
  apiKeyEnv: string; endpointEnv?: string; pricing?: Pricing;
};
type Config = {
  promptsDir: string;
  request?: { temperature?: number; maxOutputTokens?: number };
  run?: { retries?: number; timeoutMs?: number; concurrency?: number };
  providers: ProviderCfg[];
};

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ----------------- CLI args -----------------
function parseArgs(argv: string[]) {
  const args: Record<string, string|boolean> = {};
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const v = argv[i+1] && !argv[i+1].startsWith('--') ? argv[++i] : 'true';
      args[k] = v;
    }
  }
  return args;
}
const args = parseArgs(process.argv);
const CONFIG_PATH = String(args.config || 'leaderboard.config.json');
const OUTDIR = path.resolve(String(args.outdir || 'reports'));
const CONCURRENCY = Number(args.concurrency || 3);
const TIMEOUT_SPEC = String(args.timeout || '30s');

// ----------------- Utils -----------------
function parseDurationMs(s: string): number {
  const m = s.match(/^(\d+)(ms|s|m)$/i);
  if (!m) return Number(s) || 30000;
  const n = Number(m[1]);
  const u = m[2].toLowerCase();
  if (u === 'ms') return n;
  if (u === 's') return n * 1000;
  if (u === 'm') return n * 60000;
  return 30000;
}
function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }
function nowMs() { return Date.now(); }
function estTokens(text: string): number {
  const chars = (text || '').length;
  return Math.max(1, Math.ceil(chars / 4)); // rough heuristic
}
function costUSD(pricing: Pricing|undefined, inTok: number, outTok: number): number {
  const inRate = pricing?.input_per_1k ?? 0;
  const outRate = pricing?.output_per_1k ?? 0;
  return (inTok/1000) * inRate + (outTok/1000) * outRate;
}
function ensureDir(p: string) { fs.mkdirSync(p, { recursive: true }); }

// ----------------- Front matter parsing -----------------
type Expected = { kind: 'exact'|'regex'|'contains'; value: string | string[] } | null;
function parseFrontMatter(src: string): { expected: Expected, body: string } {
  const fm = src.startsWith('---\n') ? src.indexOf('\n---', 4) : -1;
  if (fm > 0) {
    const head = src.slice(4, fm).trim(); // between ---
    const body = src.slice(fm + 4).replace(/^\s*\n/, '');
    const expLine = head.split('\n').find(l => l.trim().startsWith('expected:'));
    if (expLine) {
      const raw = expLine.split(':').slice(1).join(':').trim();
      return { expected: parseExpected(raw), body };
    }
    return { expected: null, body };
  }
  return { expected: null, body: src };
}
function parseExpected(raw: string): Expected {
  if (raw.startsWith('exact:')) return { kind: 'exact', value: raw.slice(6).trim() };
  if (raw.startsWith('regex:')) return { kind: 'regex', value: raw.slice(6).trim() };
  if (raw.startsWith('contains:')) return { kind: 'contains', value: raw.slice(9).split('|').map(s => s.trim()).filter(Boolean) };
  // fallback: treat as exact
  return { kind: 'exact', value: raw.trim() };
}

function normalize(s: string) { return s.toLowerCase().replace(/\s+/g, ' ').trim(); }
function scoreExpected(exp: Expected, answer: string): number {
  if (!exp) return NaN; // not applicable
  const a = answer || '';
  if (exp.kind === 'exact') return normalize(String(exp.value)) === normalize(a) ? 1 : 0;
  if (exp.kind === 'regex') {
    try { return new RegExp(String(exp.value), 'is').test(a) ? 1 : 0; } catch { return 0; }
  }
  if (exp.kind === 'contains') {
    const p = normalize(a);
    const keys = (exp.value as string[]).map(normalize);
    return keys.every(k => p.includes(k)) ? 1 : 0;
  }
  return 0;
}

// ----------------- IO -----------------
function loadConfig(p: string): Config {
  const text = fs.readFileSync(p, 'utf-8');
  return JSON.parse(text) as Config;
}
function loadPrompts(dir: string) {
  const entries = fs.existsSync(dir) ? fs.readdirSync(dir) : [];
  return entries
    .filter(f => f.endsWith('.md') || f.endsWith('.txt'))
    .map(f => {
      const full = path.join(dir, f);
      const raw = fs.readFileSync(full, 'utf-8');
      const { expected, body } = parseFrontMatter(raw);
      return { id: path.basename(f), expected, prompt: body.trim() };
    });
}

// ----------------- Connectors -----------------
type ChatResult = { content: string; latencyMs: number; inTokens: number; outTokens: number; costUSD: number; raw?: any };
type ChatOpts = { temperature?: number; maxOutputTokens?: number; timeoutMs: number; retries: number };

async function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort('timeout'), ms);
  try {
    // @ts-ignore
    const res = await p(ctrl);
    clearTimeout(t);
    return res;
  } catch (e) {
    clearTimeout(t);
    throw e;
  }
}

// OpenAI API
async function chatOpenAI(cfg: ProviderCfg, prompt: string, opts: ChatOpts): Promise<ChatResult> {
  const apiKey = process.env[cfg.apiKeyEnv || ''] || '';
  const baseURL = cfg.baseURL || 'https://api.openai.com/v1';
  const model = cfg.model!;
  return await retry(async (signal) => {
    const start = nowMs();
    const inTok = estTokens(prompt);
    const resp = await fetch(`${baseURL.replace(/\/+$/,'')}/chat/completions`, {
      method: 'POST',
      signal,
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature ?? 0.2,
        max_tokens: opts.maxOutputTokens ?? 512
      })
    });
    if (!resp.ok) throw new Error(`openai ${resp.status}`);
    const json: any = await resp.json();
    const content = json.choices?.[0]?.message?.content || '';
    const end = nowMs();
    const outTok = estTokens(content);
    const cost = costUSD(cfg.pricing, inTok, outTok);
    return { content, latencyMs: end - start, inTokens: inTok, outTokens: outTok, costUSD: cost, raw: json };
  }, opts);
}

// Azure OpenAI
async function chatAzure(cfg: ProviderCfg, prompt: string, opts: ChatOpts): Promise<ChatResult> {
  const apiKey = process.env[cfg.apiKeyEnv || ''] || '';
  const endpoint = process.env[cfg.endpointEnv || ''] || '';
  const deployment = cfg.deployment!;
  const apiVersion = cfg.apiVersion || '2024-06-01';
  const url = `${endpoint.replace(/\/+$/,'')}/openai/deployments/${encodeURIComponent(deployment)}/chat/completions?api-version=${apiVersion}`;
  return await retry(async (signal) => {
    const start = nowMs();
    const inTok = estTokens(prompt);
    const resp = await fetch(url, {
      method: 'POST',
      signal,
      headers: { 'Content-Type': 'application/json', 'api-key': apiKey },
      body: JSON.stringify({
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature ?? 0.2,
        max_tokens: opts.maxOutputTokens ?? 512
      })
    });
    if (!resp.ok) throw new Error(`azure ${resp.status}`);
    const json: any = await resp.json();
    const content = json.choices?.[0]?.message?.content || '';
    const end = nowMs();
    const outTok = estTokens(content);
    const cost = costUSD(cfg.pricing, inTok, outTok);
    return { content, latencyMs: end - start, inTokens: inTok, outTokens: outTok, costUSD: cost, raw: json };
  }, opts);
}

// OpenAI-compatible endpoint
async function chatOpenAICompat(cfg: ProviderCfg, prompt: string, opts: ChatOpts): Promise<ChatResult> {
  const apiKey = process.env[cfg.apiKeyEnv || ''] || '';
  const baseURL = cfg.baseURL!;
  const model = cfg.model!;
  return await retry(async (signal) => {
    const start = nowMs();
    const inTok = estTokens(prompt);
    const resp = await fetch(`${baseURL.replace(/\/+$/,'')}/chat/completions`, {
      method: 'POST',
      signal,
      headers: {
        'Content-Type': 'application/json',
        ...(apiKey ? { 'Authorization': `Bearer ${apiKey}` } : {})
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature ?? 0.2,
        max_tokens: opts.maxOutputTokens ?? 512
      })
    });
    if (!resp.ok) throw new Error(`openai-compatible ${resp.status}`);
    const json: any = await resp.json();
    const content = json.choices?.[0]?.message?.content || json.choices?.[0]?.text || '';
    const end = nowMs();
    const outTok = estTokens(content);
    const cost = costUSD(cfg.pricing, inTok, outTok);
    return { content, latencyMs: end - start, inTokens: inTok, outTokens: outTok, costUSD: cost, raw: json };
  }, opts);
}

// Retry with exponential backoff and per-call abort controller
async function retry<T>(fn: (signal: AbortSignal) => Promise<T>, opts: ChatOpts): Promise<T> {
  const retries = Math.max(0, opts.retries ?? 0);
  const timeoutMs = opts.timeoutMs ?? 30000;
  let attempt = 0, delay = 500;
  while (true) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort('timeout'), timeoutMs);
    try {
      const res = await fn(ctrl.signal);
      clearTimeout(timer);
      return res;
    } catch (e: any) {
      clearTimeout(timer);
      if (attempt >= retries) throw e;
      await sleep(delay);
      delay = Math.min(delay * 2, 4000);
      attempt++;
    }
  }
}

// ----------------- Runner -----------------
type RunItem = {
  provider: ProviderCfg;
  promptId: string;
  prompt: string;
  expected: Expected;
};

async function runOne(item: RunItem, req: Config['request'], run: Required<NonNullable<Config['run']>>) {
  const chatOpts: ChatOpts = {
    temperature: req?.temperature ?? 0.2,
    maxOutputTokens: req?.maxOutputTokens ?? 512,
    timeoutMs: run.timeoutMs,
    retries: run.retries
  };
  const p = item.provider;
  let result: ChatResult;
  if (p.type === 'openai') result = await chatOpenAI(p, item.prompt, chatOpts);
  else if (p.type === 'azure') result = await chatAzure(p, item.prompt, chatOpts);
  else result = await chatOpenAICompat(p, item.prompt, chatOpts);

  const qScore = scoreExpected(item.expected, result.content);
  return {
    provider: p.name,
    label: p.label,
    type: p.type,
    model: p.model || p.deployment || '',
    promptId: item.promptId,
    latencyMs: result.latencyMs,
    inTokens: result.inTokens,
    outTokens: result.outTokens,
    costUSD: Number(result.costUSD.toFixed(6)),
    quality: Number.isNaN(qScore) ? null : qScore,
    answer: result.content
  };
}

async function main() {
  const timeoutMs = parseDurationMs(TIMEOUT_SPEC);
  const cfg = loadConfig(CONFIG_PATH);
  const prompts = loadPrompts(path.resolve(cfg.promptsDir || 'prompts'));
  if (!prompts.length) {
    console.error('Keine Prompts gefunden in', cfg.promptsDir);
    process.exit(1);
  }
  ensureDir(OUTDIR);
  const runCfg = {
    retries: cfg.run?.retries ?? 2,
    timeoutMs: cfg.run?.timeoutMs ?? timeoutMs,
    concurrency: Number(CONCURRENCY) || (cfg.run?.concurrency ?? 3)
  };

  const items: RunItem[] = [];
  for (const p of cfg.providers) {
    for (const pr of prompts) {
      items.push({ provider: p, promptId: pr.id, prompt: pr.prompt, expected: pr.expected });
    }
  }

  // Simple concurrency pool
  const queue = items.slice();
  const results: any[] = [];
  const workers: Promise<void>[] = [];
  for (let i = 0; i < runCfg.concurrency; i++) {
    workers.push((async () => {
      while (queue.length) {
        const job = queue.shift()!;
        try {
          const res = await runOne(job, cfg.request, runCfg);
          results.push(res);
          process.stdout.write('.');
        } catch (e: any) {
          results.push({
            provider: job.provider.name,
            label: job.provider.label,
            type: job.provider.type,
            model: job.provider.model || job.provider.deployment || '',
            promptId: job.promptId,
            error: e?.message || String(e),
            latencyMs: null, inTokens: null, outTokens: null, costUSD: null, quality: null, answer: ''
          });
          process.stdout.write('E');
        }
      }
    })());
  }
  await Promise.all(workers);
  process.stdout.write('\n');

  // Aggregation
  type Agg = { label: string; model: string; runs: number; avgLatency: number; avgQuality: number|null; totalCost: number; };
  const byLabel: Record<string, Agg> = {};
  for (const r of results) {
    const key = `${r.label}::${r.model}`;
    if (!byLabel[key]) byLabel[key] = { label: r.label, model: r.model, runs: 0, avgLatency: 0, avgQuality: null, totalCost: 0 };
    const a = byLabel[key];
    a.runs++;
    if (typeof r.latencyMs === 'number') a.avgLatency += r.latencyMs;
    if (typeof r.costUSD === 'number') a.totalCost += r.costUSD;
    if (typeof r.quality === 'number') {
      a.avgQuality = (a.avgQuality ?? 0) + r.quality;
    }
  }
  const aggregates = Object.values(byLabel).map(a => ({
    label: a.label, model: a.model, runs: a.runs,
    avgLatency: a.runs ? Number((a.avgLatency / a.runs).toFixed(1)) : null,
    avgQuality: a.avgQuality === null ? null : Number(((a.avgQuality || 0) / a.runs).toFixed(3)),
    totalCost: Number(a.totalCost.toFixed(4))
  }));

  const leaderboardSpeed = aggregates.slice().sort((x, y) => (x.avgLatency ?? Infinity) - (y.avgLatency ?? Infinity));
  const leaderboardQuality = aggregates.slice().sort((x, y) => (y.avgQuality ?? -1) - (x.avgQuality ?? -1));
  const leaderboardCost = aggregates.slice().sort((x, y) => x.totalCost - y.totalCost);

  // Save JSON
  const jsonOut = {
    generatedAt: new Date().toISOString(),
    config: { providers: cfg.providers.map(p => ({ name: p.name, label: p.label, type: p.type, model: p.model || p.deployment })) },
    results,
    aggregates,
    leaderboard: { speed: leaderboardSpeed, quality: leaderboardQuality, cost: leaderboardCost }
  };
  fs.writeFileSync(path.join(OUTDIR, 'leaderboard.json'), JSON.stringify(jsonOut, null, 2), 'utf-8');

  // Save MD
  const md = [
    '# Chatbot Leaderboard',
    '',
    '## Speed (avg latency ms)',
    '',
    '| Rank | Label | Model | Avg Latency (ms) | Runs |',
    '|------|-------|-------|------------------:|-----:|',
    ...leaderboardSpeed.map((r, i) => `| ${i+1} | ${r.label} | ${r.model} | ${r.avgLatency ?? '-'} | ${r.runs} |`),
    '',
    '## Quality (avg 0..1, only tasks with expected)',
    '',
    '| Rank | Label | Model | Avg Quality | Runs |',
    '|------|-------|-------|------------:|-----:|',
    ...leaderboardQuality.map((r, i) => `| ${i+1} | ${r.label} | ${r.model} | ${r.avgQuality ?? '-'} | ${r.runs} |`),
    '',
    '## Cost (total USD)',
    '',
    '| Rank | Label | Model | Total Cost (USD) | Runs |',
    '|------|-------|-------|-----------------:|-----:|',
    ...leaderboardCost.map((r, i) => `| ${i+1} | ${r.label} | ${r.model} | ${r.totalCost.toFixed(4)} | ${r.runs} |`)
  ].join('\n');
  fs.writeFileSync(path.join(OUTDIR, 'leaderboard.md'), md, 'utf-8');

  // Save HTML (sortable)
  const html = `<!doctype html>
<html lang="de"><head><meta charset="utf-8"/>
<title>Chatbot Leaderboard</title>
<style>
body{font-family:system-ui,Arial;margin:24px}
table{border-collapse:collapse;margin-bottom:24px}
td,th{border:1px solid #ddd;padding:8px}
th{cursor:pointer;background:#f7f7f7}
small{color:#666}
</style>
<script>
function sortTable(id, col, numeric) {
  const table = document.getElementById(id);
  const rows = Array.from(table.tBodies[0].rows);
  const asc = table.dataset.sortCol == col && table.dataset.sortDir == 'asc' ? false : true;
  rows.sort((a,b)=>{
    const x = a.cells[col].innerText;
    const y = b.cells[col].innerText;
    const xn = numeric ? parseFloat(x) : x.toLowerCase();
    const yn = numeric ? parseFloat(y) : y.toLowerCase();
    if (isNaN(xn) && isNaN(yn)) return 0;
    if (xn < yn) return asc ? -1 : 1;
    if (xn > yn) return asc ? 1 : -1;
    return 0;
  });
  rows.forEach(r=>table.tBodies[0].appendChild(r));
  table.dataset.sortCol = col; table.dataset.sortDir = asc ? 'asc':'desc';
}
</script>
</head><body>
<h1>Chatbot Leaderboard</h1>
<small>Generiert: ${new Date().toLocaleString()}</small>

<h2>Speed</h2>
<table id="tblSpeed" data-sort-col="-1" data-sort-dir="asc">
<thead><tr>
<th onclick="sortTable('tblSpeed',0,false)">Rank</th>
<th onclick="sortTable('tblSpeed',1,false)">Label</th>
<th onclick="sortTable('tblSpeed',2,false)">Model</th>
<th onclick="sortTable('tblSpeed',3,true)">Avg Latency (ms)</th>
<th onclick="sortTable('tblSpeed',4,true)">Runs</th>
</tr></thead>
<tbody>
${leaderboardSpeed.map((r,i)=>`<tr><td>${i+1}</td><td>${r.label}</td><td>${r.model}</td><td>${r.avgLatency ?? '-'}</td><td>${r.runs}</td></tr>`).join('\n')}
</tbody></table>

<h2>Quality</h2>
<table id="tblQuality" data-sort-col="-1" data-sort-dir="asc">
<thead><tr>
<th onclick="sortTable('tblQuality',0,false)">Rank</th>
<th onclick="sortTable('tblQuality',1,false)">Label</th>
<th onclick="sortTable('tblQuality',2,false)">Model</th>
<th onclick="sortTable('tblQuality',3,true)">Avg Quality</th>
<th onclick="sortTable('tblQuality',4,true)">Runs</th>
</tr></thead>
<tbody>
${leaderboardQuality.map((r,i)=>`<tr><td>${i+1}</td><td>${r.label}</td><td>${r.model}</td><td>${r.avgQuality ?? '-'}</td><td>${r.runs}</td></tr>`).join('\n')}
</tbody></table>

<h2>Cost</h2>
<table id="tblCost" data-sort-col="-1" data-sort-dir="asc">
<thead><tr>
<th onclick="sortTable('tblCost',0,false)">Rank</th>
<th onclick="sortTable('tblCost',1,false)">Label</th>
<th onclick="sortTable('tblCost',2,false)">Model</th>
<th onclick="sortTable('tblCost',3,true)">Total Cost (USD)</th>
<th onclick="sortTable('tblCost',4,true)">Runs</th>
</tr></thead>
<tbody>
${leaderboardCost.map((r,i)=>`<tr><td>${i+1}</td><td>${r.label}</td><td>${r.model}</td><td>${r.totalCost.toFixed(4)}</td><td>${r.runs}</td></tr>`).join('\n')}
</tbody></table>

</body></html>`;
  fs.writeFileSync(path.join(OUTDIR, 'leaderboard.html'), html, 'utf-8');

  console.log('Done. Reports at:', OUTDIR);
}

main().catch(err => { console.error(err); process.exit(1); });