exports.activate = function() {
  nova.commands.register("eu-union-ai-pact.mycli.run", (workspace) => {
    const proc = new Process("mycli", { args: ["run", "quick-scan"], cwd: workspace.path });
    proc.onStdout((line) => console.log(line));
    proc.onStderr((line) => console.error(line));
    proc.start();
  });
};
exports.deactivate = function() {};