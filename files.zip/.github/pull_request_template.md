# PR-Titel

Kurzfassung
- [Kurz beschreiben, was und warum]

Checkliste
- [ ] Secrets vorhanden (z. B. NPM_TOKEN; optional NPM_OFFLINE_REGISTRY)
- [ ] Actions erlaubt
- [ ] Monorepo: korrekte Publish-Working-Directory
- [ ] Enterprise/Offline: SSH-Key hinterlegt, Registry gesetzt
- [ ] Post-Merge: Tag + Pipelines + Smoke-Tests

Hinweise
- Bei Offline-Nutzung: `giants auth ... --offline` verwenden (Dokumentation beachten)
- Labels: `enhancement`, `area:cli`, `area:auth`, `scope:offline`, `ci`, `release`