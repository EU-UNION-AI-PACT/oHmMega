# Monorepo: Connectors & Agents (Docker, Kubernetes, LLM, RAG, Deep-Search, Async, Coding Assistant)

Inhalt
- apps/cli: Zentrales CLI (mycli) – verbindet Docker/K8s/Agents/Deep-Search/RAG
- packages/core: Basistypen, Utilities, Async Runner
- packages/connectors-docker: Docker Connector (CLI-basiert)
- packages/connectors-k8s: Kubernetes Connector (kubectl-basiert)
- packages/chat-connectors/openai: LLM Connector (OpenAI/Azure/OpenAI-kompatibel)
- packages/deep-search: Deep-Search Aggregator (Bing/Tavily/SerpAPI Skeletons)
- packages/rag-store-file: Datei-basierter Store (chunkenn, simple “Embeddings”-Heuristik)
- packages/agents/coding-assistant: Coding-Assistent (Modes: lazy, vibing, rag-coding)
- packages/agents/rag-agent: RAG-Agent (Retrieve-then-Generate)
- packages/agents/async-agent: Asynchroner Agent (lokaler Job-Runner)
- infra/docker & infra/k8s: Container/K8s Skeletons (Deployment, Dockerfile)

Schnellstart
```bash
corepack enable
pnpm i

# CLI Hilfe
pnpm -w mycli --help

# Beispiele
pnpm -w mycli docker ps
pnpm -w mycli k8s pods -n default
pnpm -w mycli search "how to secure k8s cluster"
pnpm -w mycli rag index ./docs
pnpm -w mycli rag query "Wie verbinde ich Deployment und Service in K8s?"
pnpm -w mycli agent code --mode lazy --task "Implementiere Healthcheck Endpoint in Express"
```

ENV (Beispiele)
- OPENAI_API_KEY (optional) – LLM & Embeddings
- AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT (optional)
- BING_API_KEY, TAVILY_API_KEY, SERPAPI_KEY (optional)

Roadmap
- Optional: echte K8s-API-Clients, Redis-Queue für Async, Vektor-DB (SQLite/pgvector), weitere Agents (Deep‑Search‑“Fet…ch”/Research).