import sys
import os
import shutil
import subprocess
from importlib import resources

def find_node() -> str:
    # 1) explizit via ENV
    node = os.environ.get("NODE_BINARY")
    if node and shutil.which(node):
        return node
    # 2) systemweites node
    node = shutil.which("node")
    if node:
        return node
    # 3) Windows Python-Launcher Pfad prüfen (optional)
    raise SystemExit(
        "Node.js nicht gefunden. Bitte Node 18+ installieren oder NODE_BINARY Umgebungsvariable setzen.\n"
        "Download: https://nodejs.org/en/download\n"
        "Beispiel: NODE_BINARY=/usr/local/bin/node"
    )

def giants_js_path() -> str:
    try:
        base = resources.files("reloadedsince1337").joinpath("vendor/cli")
        # Standard-Einstieg
        entry = base.joinpath("index.js")
        if entry.is_file():
            return str(entry)
        # Alternative: falls .mjs genutzt wird
        entry_mjs = base.joinpath("index.mjs")
        if entry_mjs.is_file():
            return str(entry_mjs)
        raise FileNotFoundError(f"Kein CLI-Einstieg in {base}")
    except Exception as e:
        raise SystemExit(f"Fehler beim Laden der CLI-Ressourcen: {e}")

def main() -> None:
    node = find_node()
    entry = giants_js_path()
    args = sys.argv[1:]
    # Optional: Warnungen reduzieren
    env = os.environ.copy()
    env.setdefault("NODE_NO_WARNINGS", "1")
    # Starte die Node-CLI und gebe Exit-Code durch
    proc = subprocess.run([node, entry, *args], env=env)
    raise SystemExit(proc.returncode)

if __name__ == "__main__":
    main()