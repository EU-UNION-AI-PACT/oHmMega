import OpenAI from 'openai';
import Anthropic from 'anthropic';
import { GoogleGenerativeAI } from '@google/generative-ai';

function env(name) {
  return process.env[name] || '';
}

export function normalizeModelId(provider, model) {
  // Optionale Normalisierung je Provider
  return model;
}

export function makeProviderClient(provider) {
  switch (provider.type) {
    case 'openai': {
      const apiKey = provider.apiKey || env('OPENAI_API_KEY');
      const baseURL = provider.baseURL || undefined; // e.g., OpenRouter or self-host
      const client = new OpenAI({ apiKey, baseURL });
      return {
        async chat(model, prompt, opts = {}) {
          const resp = await client.chat.completions.create({
            model,
            messages: [{ role: 'user', content: prompt }],
            temperature: opts.temperature ?? 0.2,
          });
          return resp.choices?.[0]?.message?.content || '';
        },
        type: 'openai'
      };
    }
    case 'openrouter': {
      const apiKey = provider.apiKey || env('OPENROUTER_API_KEY');
      const baseURL = provider.baseURL || 'https://openrouter.ai/api/v1';
      const client = new OpenAI({ apiKey, baseURL });
      return {
        async chat(model, prompt, opts = {}) {
          const resp = await client.chat.completions.create({
            model,
            messages: [{ role: 'user', content: prompt }],
            temperature: opts.temperature ?? 0.2
          });
          return resp.choices?.[0]?.message?.content || '';
        },
        type: 'openai'
      };
    }
    case 'anthropic': {
      const apiKey = provider.apiKey || env('ANTHROPIC_API_KEY');
      const client = new Anthropic({ apiKey });
      return {
        async chat(model, prompt, opts = {}) {
          const resp = await client.messages.create({
            model,
            max_tokens: opts.maxTokens ?? 1024,
            temperature: opts.temperature ?? 0.2,
            messages: [{ role: 'user', content: prompt }]
          });
          const content = resp.content?.[0]?.text ?? '';
          return content;
        },
        type: 'anthropic'
      };
    }
    case 'google': {
      const apiKey = provider.apiKey || env('GOOGLE_API_KEY');
      const genAI = new GoogleGenerativeAI(apiKey);
      return {
        async chat(model, prompt, opts = {}) {
          const m = genAI.getGenerativeModel({ model });
          const resp = await m.generateContent({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: opts.temperature ?? 0.2 } });
          return resp.response?.text() || '';
        },
        type: 'google'
      };
    }
    case 'ollama': {
      const baseURL = provider.baseURL || env('OLLAMA_BASE_URL') || 'http://localhost:11434';
      return {
        async chat(model, prompt, opts = {}) {
          // Minimal Ollama Chat via HTTP
          const res = await fetch(`${baseURL}/api/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }], stream: false, options: { temperature: opts.temperature ?? 0.2 } })
          });
          const data = await res.json();
          return data?.message?.content || data?.response || '';
        },
        type: 'ollama'
      };
    }
    default:
      throw new Error(`Unknown provider type: ${provider.type}`);
  }
}