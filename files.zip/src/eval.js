function normalize(s) {
  return (s || '').toString().trim().toLowerCase().replace(/\s+/g, ' ');
}

export function scoreExact(gold, pred) {
  return normalize(gold) === normalize(pred) ? 1 : 0;
}

export function scoreRegex(pattern, pred) {
  try {
    const re = new RegExp(pattern, 'is');
    return re.test(pred) ? 1 : 0;
  } catch {
    return 0;
  }
}

export function scoreContainsAll(keywords, pred) {
  const p = normalize(pred);
  return (keywords || []).every(k => p.includes(normalize(k))) ? 1 : 0;
}

export function scoreTokenF1(gold, pred) {
  const gs = new Set(normalize(gold).split(' ').filter(Boolean));
  const ps = new Set(normalize(pred).split(' ').filter(Boolean));
  const inter = new Set([...gs].filter(x => ps.has(x)));
  const precision = ps.size ? inter.size / ps.size : 0;
  const recall = gs.size ? inter.size / gs.size : 0;
  return (precision + recall) ? (2 * precision * recall) / (precision + recall) : 0;
}

export function evaluateAnswer(task, answer) {
  const method = task.expected?.method || 'token-f1';
  const weight = task.weight ?? 1;
  let score = 0;
  if (method === 'exact') score = scoreExact(task.expected.value || '', answer);
  else if (method === 'regex') score = scoreRegex(task.expected.value || '', answer);
  else if (method === 'contains') score = scoreContainsAll(task.expected.keywords || [], answer);
  else score = scoreTokenF1(task.expected.value || '', answer);
  return { score, weighted: score * weight, method };
}