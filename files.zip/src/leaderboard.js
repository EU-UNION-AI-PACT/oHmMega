#!/usr/bin/env node
import fs from 'fs';
import path from 'path';
import { hideBin } from 'yargs/helpers';
import yargs from 'yargs';
import pLimit from 'p-limit';
import { makeConnector } from './connectors/base.js';
import { evaluateAnswer } from './eval.js';

const argv = yargs(hideBin(process.argv))
  .option('config', { type: 'string', demandOption: true, describe: 'Connector/Provider-Konfig JSON' })
  .option('tasks', { type: 'string', demandOption: true, describe: 'Tasks JSON' })
  .option('out', { type: 'string', default: 'output', describe: 'Output-Verzeichnis' })
  .option('concurrency', { type: 'number', default: 4, describe: 'Parallele Requests' })
  .help().argv;

function loadJSON(p) { return JSON.parse(fs.readFileSync(p, 'utf8')); }
function saveJSON(p, obj) { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, JSON.stringify(obj, null, 2), 'utf8'); }
function saveText(p, text) { fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, text, 'utf8'); }

async function main() {
  const cfg = loadJSON(argv.config);
  const tasks = loadJSON(argv.tasks);
  const outDir = path.resolve(argv.out);
  fs.mkdirSync(outDir, { recursive: true });

  // Connectoren instanziieren
  const connectors = (cfg.providers || []).map(def => makeConnector(def));
  if (!connectors.length) throw new Error('Keine Provider in config.');

  const limit = pLimit(argv.concurrency);
  const results = [];
  const scores = {}; // label -> aggregation

  // Alle Läufe
  const jobs = [];
  for (const c of connectors) {
    for (const model of c.models) {
      const label = `${c.name}:${model}`;
      scores[label] = { total: 0, weighted: 0, count: 0, details: [] };
      for (const t of tasks) {
        jobs.push(limit(async () => {
          try {
            const answer = await c.chat(model, t.prompt, { temperature: 0.2 });
            const { score, weighted, method } = evaluateAnswer(t, answer);
            scores[label].total += score;
            scores[label].weighted += weighted;
            scores[label].count += 1;
            scores[label].details.push({ taskId: t.id, method, score, answer });
            results.push({ provider: c.name, model, label, taskId: t.id, score, method, answer });
          } catch (e) {
            scores[label].details.push({ taskId: t.id, method: 'error', score: 0, error: e.message });
            results.push({ provider: c.name, model, label, taskId: t.id, score: 0, method: 'error', error: e.message });
          }
        }));
      }
    }
  }

  await Promise.all(jobs);

  // Leaderboard
  const leaderboard = Object.entries(scores)
    .map(([label, v]) => ({
      label,
      avg: v.count ? v.total / v.count : 0,
      avg_weighted: v.count ? v.weighted / v.count : 0,
      count: v.count
    }))
    .sort((a, b) => b.avg_weighted - a.avg_weighted);

  // Artefakte speichern
  saveJSON(path.join(outDir, 'results.json'), { generatedAt: new Date().toISOString(), results, scores });

  const md = [
    '# LLM Leaderboard (Connectoren)',
    '',
    '| Rank | Model | Avg (Weighted) | Avg (Raw) | Samples |',
    '|------|-------|-----------------|-----------|---------|',
    ...leaderboard.map((r, i) => `| ${i + 1} | ${r.label} | ${r.avg_weighted.toFixed(3)} | ${r.avg.toFixed(3)} | ${r.count} |`)
  ].join('\n');
  saveText(path.join(outDir, 'leaderboard.md'), md);

  const html = `<!doctype html>
<html lang="de"><head><meta charset="utf-8"><title>LLM Leaderboard</title>
<style>body{font-family:system-ui,Arial;margin:24px} table{border-collapse:collapse} td,th{border:1px solid #ddd;padding:8px}</style>
</head><body>
<h1>LLM Leaderboard (Connectoren)</h1>
<table>
<thead><tr><th>Rank</th><th>Model</th><th>Avg (Weighted)</th><th>Avg (Raw)</th><th>Samples</th></tr></thead>
<tbody>
${leaderboard.map((r, i) => `<tr><td>${i + 1}</td><td>${r.label}</td><td>${r.avg_weighted.toFixed(3)}</td><td>${r.avg.toFixed(3)}</td><td>${r.count}</td></tr>`).join('\n')}
</tbody>
</table>
<p>Generiert: ${new Date().toLocaleString()}</p>
</body></html>`;
  saveText(path.join(outDir, 'leaderboard.html'), html);

  console.log('Fertig. Artefakte unter:', outDir);
}

main().catch(e => { console.error(e); process.exit(1); });