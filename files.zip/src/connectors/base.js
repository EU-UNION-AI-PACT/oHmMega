export function makeConnector(def) {
  // def: { name, type, models[], ... }
  switch (def.type) {
    case 'openai': return makeOpenAI(def);
    case 'openrouter': return makeOpenRouter(def);
    case 'anthropic': return makeAnthropic(def);
    case 'google': return makeGoogle(def);
    case 'ollama': return makeOllama(def);
    case 'http-openai': return makeHttpOpenAI(def);
    default: throw new Error(`Unknown connector type: ${def.type}`);
  }
}

// --- OpenAI ---
import OpenAI from 'openai';
function makeOpenAI(def) {
  const client = new OpenAI({
    apiKey: def.apiKey || process.env.OPENAI_API_KEY,
    baseURL: def.baseURL || undefined
  });
  return {
    name: def.name || 'openai',
    type: def.type,
    models: def.models || [],
    async chat(model, prompt, opts = {}) {
      const resp = await client.chat.completions.create({
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature ?? 0.2
      });
      return resp.choices?.[0]?.message?.content || '';
    }
  };
}

// --- OpenRouter (OpenAI-kompatibel) ---
function makeOpenRouter(def) {
  const client = new OpenAI({
    apiKey: def.apiKey || process.env.OPENROUTER_API_KEY,
    baseURL: def.baseURL || 'https://openrouter.ai/api/v1'
  });
  return {
    name: def.name || 'openrouter',
    type: def.type,
    models: def.models || [],
    async chat(model, prompt, opts = {}) {
      const resp = await client.chat.completions.create({
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature ?? 0.2
      });
      return resp.choices?.[0]?.message?.content || '';
    }
  };
}

// --- Anthropic ---
import Anthropic from 'anthropic';
function makeAnthropic(def) {
  const client = new Anthropic({
    apiKey: def.apiKey || process.env.ANTHROPIC_API_KEY
  });
  return {
    name: def.name || 'anthropic',
    type: def.type,
    models: def.models || [],
    async chat(model, prompt, opts = {}) {
      const resp = await client.messages.create({
        model,
        max_tokens: opts.maxTokens ?? 1024,
        temperature: opts.temperature ?? 0.2,
        messages: [{ role: 'user', content: prompt }]
      });
      return resp.content?.[0]?.text ?? '';
    }
  };
}

// --- Google Gemini ---
import { GoogleGenerativeAI } from '@google/generative-ai';
function makeGoogle(def) {
  const apiKey = def.apiKey || process.env.GOOGLE_API_KEY;
  const genAI = new GoogleGenerativeAI(apiKey);
  return {
    name: def.name || 'google',
    type: def.type,
    models: def.models || [],
    async chat(model, prompt, opts = {}) {
      const m = genAI.getGenerativeModel({ model });
      const resp = await m.generateContent({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { temperature: opts.temperature ?? 0.2 }
      });
      return resp.response?.text() || '';
    }
  };
}

// --- Ollama lokal ---
function makeOllama(def) {
  const baseURL = def.baseURL || process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
  return {
    name: def.name || 'ollama',
    type: def.type,
    models: def.models || [],
    async chat(model, prompt, opts = {}) {
      const res = await fetch(`${baseURL}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          messages: [{ role: 'user', content: prompt }],
          stream: false,
          options: { temperature: opts.temperature ?? 0.2 }
        })
      });
      const data = await res.json();
      return data?.message?.content || data?.response || '';
    }
  };
}

// --- Generischer OpenAI-kompatibler HTTP Connector ---
function makeHttpOpenAI(def) {
  const baseURL = def.baseURL; // z.B. self-hosted, VLLM, LM Studio, OpenAI-proxy
  const apiKey = def.apiKey || process.env.HTTP_OPENAI_API_KEY || '';
  return {
    name: def.name || 'http-openai',
    type: def.type,
    models: def.models || [],
    async chat(model, prompt, opts = {}) {
      const url = `${baseURL.replace(/\/+$/,'')}/chat/completions`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(apiKey ? { 'Authorization': `Bearer ${apiKey}` } : {})
        },
        body: JSON.stringify({
          model,
          messages: [{ role: 'user', content: prompt }],
          temperature: opts.temperature ?? 0.2
        })
      });
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        throw new Error(`http-openai ${res.status}: ${text}`);
      }
      const data = await res.json();
      return data.choices?.[0]?.message?.content || '';
    }
  };
}