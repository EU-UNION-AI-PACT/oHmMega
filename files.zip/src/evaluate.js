function normalize(s) {
  return (s || '').toString().trim().toLowerCase().replace(/\s+/g, ' ');
}

export function scoreExact(gold, pred) {
  return normalize(gold) === normalize(pred) ? 1 : 0;
}

export function scoreRegex(pattern, pred) {
  try {
    const re = new RegExp(pattern, 'is');
    return re.test(pred) ? 1 : 0;
  } catch {
    return 0;
  }
}

export function scoreContainsAll(keywords, pred) {
  const p = normalize(pred);
  const ok = keywords.every(k => p.includes(normalize(k)));
  return ok ? 1 : 0;
}

export function scoreTokenF1(gold, pred) {
  const gs = new Set(normalize(gold).split(' ').filter(Boolean));
  const ps = new Set(normalize(pred).split(' ').filter(Boolean));
  const inter = new Set([...gs].filter(x => ps.has(x)));
  const precision = ps.size ? inter.size / ps.size : 0;
  const recall = gs.size ? inter.size / gs.size : 0;
  const f1 = (precision + recall) ? (2 * precision * recall) / (precision + recall) : 0;
  return f1;
}

export function evaluateAnswer(task, answer) {
  const method = task.expected?.method || 'token-f1';
  const weight = task.weight ?? 1;
  let score = 0;
  if (method === 'exact') score = scoreExact(task.expected.value || '', answer);
  else if (method === 'regex') score = scoreRegex(task.expected.value || '', answer);
  else if (method === 'contains') score = scoreContainsAll(task.expected.keywords || [], answer);
  else score = scoreTokenF1(task.expected.value || '', answer);
  return { score, weighted: score * weight, method };
}

/**
Optional: LLM-as-Judge using OpenAI-like interface
judgeClient: { chat(model, prompt, opts) }
*/
export async function judgeAnswerLLM({ judgeClient, judgeModel, rubric, question, answer, refAnswer }) {
  const prompt =
`You are an impartial judge. Score the assistant's answer from 0.0 to 1.0 according to the rubric.

Rubric:
${rubric || 'Correctness, completeness, clarity'}

Question:
${question}

Reference answer (optional):
${refAnswer || '(none)'}

Assistant answer:
${answer}

Return ONLY a JSON object: {"score": <0..1>, "justification": "<short reason>"}`
  ;
  const resp = await judgeClient.chat(judgeModel, prompt, { temperature: 0 });
  try {
    const m = resp.match(/\{[\s\S]*\}/);
    const obj = JSON.parse(m ? m[0] : '{}');
    const score = Math.max(0, Math.min(1, Number(obj.score ?? 0)));
    return { score, justification: obj.justification || '' };
  } catch {
    return { score: 0, justification: 'parse_error' };
  }
}