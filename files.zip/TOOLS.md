# Gigantische & seltene CLI/GUI/TUI – Übersicht

Kategorien (Auszug):
- Static Analysis & Security: semgrep, snyk, checkov, kics, tfsec, terrascan, trivy, grype, syft, gitleaks, trufflehog, osv-scanner, codeql, bandit, safety, findsecbugs
- Reverse Engineering & Forensik: ghidra (GUI+Headless), radare2/rizin + Cutter (GUI), capa, floss, yara, volatility3, binwalk, sleuthkit, autopsy (GUI), osquery, zeek, suricata
- Network/Recon/Fuzzing: nmap, masscan, zmap, zgrab2, amass, subfinder, assetfinder, httpx, naabu, nuclei, ffuf, feroxbuster
- Container/K8s: trivy, grype, syft, kubescape, popeye, kube-hunter, kube-bench, k9s (TUI), lazydocker (TUI)
- API & Protocol: owasp zap (GUI), mitmproxy/mitmweb, grpcurl, schemathesis, insomnia (GUI), postman (GUI)
- Doku & Diagramme: jsdoc, doxygen, graphviz, plantuml, @mermaid-js/mermaid-cli, netron (GUI, ML-Modelle)
- TUI/DevX: btop, eza/exa, bat, fd/fdfind, ripgrep, delta, fzf, lazygit, lazydocker, k9s, ranger, nnn, glow, ncdu, gdu, micro, neovim, zoxide

Hinweise:
- Einige seltene Tools werden als AppImage/Binary in /opt/<tool> abgelegt und nach /usr/local/bin verlinkt.
- Für Go-basierte Tools sorgt das Skript für `go install ...@latest` und exportiert GOBIN ($HOME/.local/bin).
- Für Python-Tools wird pipx genutzt (isolierte Installation).