#!/usr/bin/env python3
import sys, json, os, subprocess, argparse

def run(cmd, cwd=None):
    print("[*]", cmd)
    p = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return p.returncode, p.stdout, p.stderr

def onnx_inspect(model_path, out_json):
    try:
        import onnx
        m = onnx.load(model_path)
        g = m.graph
        data = {
            "inputs": [i.name for i in g.input],
            "outputs": [o.name for o in g.output],
            "nodes": [{"op_type": n.op_type, "name": n.name} for n in g.node]
        }
        with open(out_json, "w") as f: json.dump(data, f, indent=2)
        print("[+] ONNX analysis written to", out_json)
    except Exception as e:
        print("[-] ONNX error:", e, file=sys.stderr)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--onnx", help="ONNX model path")
    ap.add_argument("--out", help="Output JSON", default="output/ml/onnx.json")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    if args.onnx:
        onnx_inspect(args.onnx, args.out)

if __name__ == "__main__":
    main()