#!/usr/bin/env node
/**
 * Einfacher Qualitäts-Scanner:
 * - listet TODO/FIXME
 * - findet Packages ohne README oder ohne Tests
 * - warnt bei sehr großen Dateien (> 500 KB) im Repo
 */
import fs from 'fs';
import path from 'path';
const root = process.cwd();

function walk(dir, list = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', 'dist', '.git', 'coverage', '.rag-store'].includes(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, list);
    else list.push(p);
  }
  return list;
}

function scanTodos(files) {
  const hits = [];
  for (const f of files) {
    if (!/\.(ts|tsx|js|md|json|yml|yaml|sh)$/i.test(f)) continue;
    const txt = fs.readFileSync(f, 'utf-8');
    const lines = txt.split('\n');
    lines.forEach((l, i) => {
      if (/\b(TODO|FIXME)\b/.test(l)) hits.push({ file: f, line: i + 1, text: l.trim() });
    });
  }
  return hits;
}

function findLarge(files, limit = 500 * 1024) {
  return files
    .filter((f) => fs.statSync(f).size > limit)
    .map((f) => ({ file: f, sizeKB: Math.round(fs.statSync(f).size / 1024) }));
}

function scanPackages() {
  const pkgsDir = path.join(root, 'packages');
  if (!fs.existsSync(pkgsDir)) return [];
  const pkgs = [];
  for (const scope of fs.readdirSync(pkgsDir)) {
    const scopePath = path.join(pkgsDir, scope);
    if (fs.statSync(scopePath).isDirectory()) {
      for (const name of fs.readdirSync(scopePath)) {
        const p = path.join(scopePath, name);
        if (!fs.statSync(p).isDirectory()) continue;
        const hasPkg = fs.existsSync(path.join(p, 'package.json'));
        const hasReadme = fs.existsSync(path.join(p, 'README.md'));
        const hasTests = fs.existsSync(path.join(p, 'src')) &&
                         fs.readdirSync(path.join(p, 'src')).some((f) => /\.test\./.test(f));
        if (hasPkg) pkgs.push({ pkg: `${scope}/${name}`, hasReadme, hasTests });
      }
    }
  }
  return pkgs;
}

function main() {
  const files = walk(root);
  const todos = scanTodos(files);
  const large = findLarge(files);
  const pkgs = scanPackages();

  const report = { todos, largeFiles: large, packages: pkgs.filter(p => !p.hasReadme || !p.hasTests) };
  const outDir = path.join(root, 'reports');
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, 'quality-scan.json'), JSON.stringify(report, null, 2));
  console.log('Quality scan report:', path.join(outDir, 'quality-scan.json'));

  if (todos.length) console.warn(`TODO/FIXME gefunden: ${todos.length}`);
  if (large.length) console.warn(`Große Dateien: ${large.length}`);
  const missing = pkgs.filter(p => !p.hasReadme || !p.hasTests);
  if (missing.length) console.warn(`Pakete ohne README/Tests: ${missing.length}`);
}
main();