# Gigantische & seltene Tools – Windows (winget). Als Admin ausführen empfohlen.
# PowerShell 7 empfohlen.
$ErrorActionPreference = "Continue"

function Install-Winget {
  param([string]$Id, [string]$Name)
  try {
    Write-Host "Installing $Name ($Id)..."
    winget install --id $Id --silent --accept-package-agreements --accept-source-agreements
  } catch {
    Write-Warning "Failed to install $Name ($Id): $_"
  }
}

# Core runtimes & package tools
Install-Winget -Id Git.Git -Name "Git"
Install-Winget -Id GitHub.cli -Name "GitHub CLI"
Install-Winget -Id OpenJS.NodeJS.LTS -Name "Node.js LTS"
Install-Winget -Id Python.Python.3.11 -Name "Python 3.11"
Install-Winget -Id GoLang.Go -Name "Go"
Install-Winget -Id EclipseAdoptium.Temurin.17.JRE -Name "Java 17 JRE"
Install-Winget -Id GrafanaLabs.grafana-agent -Name "Grafana Agent" # optional

# Security & Analysis
Install-Winget -Id ReturnToCorp.Semgrep -Name "Semgrep"
Install-Winget -Id Snyk.Snyk -Name "Snyk CLI"
Install-Winget -Id GitLeaks.GitLeaks -Name "Gitleaks"
Install-Winget -Id Aquasecurity.Trivy -Name "Trivy"
Install-Winget -Id Anchore.Syft -Name "Syft"
Install-Winget -Id Anchore.Grype -Name "Grype"
Install-Winget -Id OpenPolicyAgent.OPA -Name "OPA" 
Install-Winget -Id JFrog.Conftest -Name "Conftest"

# Reverse Engineering / Forensics
Install-Winget -Id NSA.Ghidra -Name "Ghidra"
Install-Winget -Id WiresharkFoundation.Wireshark -Name "Wireshark"
Install-Winget -Id OWASP.ZAP -Name "OWASP ZAP"
Install-Winget -Id Postman.Postman -Name "Postman"
Install-Winget -Id Kong.Insomnia -Name "Insomnia"
Install-Winget -Id Microsoft.SysinternalsSuite -Name "Sysinternals"
# Cutter via Chocolatey or manual suggested (winget package may vary)

# Dev & Container
Install-Winget -Id Docker.DockerDesktop -Name "Docker Desktop"
Install-Winget -Id Kubernetes.kubectl -Name "kubectl"
Install-Winget -Id Helm.Helm -Name "Helm"

# Dev Experience (TUI/CLI)
Install-Winget -Id sharkdp.fd -Name "fd"
Install-Winget -Id sharkdp.bat -Name "bat"
Install-Winget -Id BurntSushi.ripgrep.MSVC -Name "ripgrep"
Install-Winget -Id junegunn.fzf -Name "fzf"
Install-Winget -Id jesseduffield.lazygit -Name "lazygit"

Write-Host "Optionals via pip/pipx:"
Write-Host " pipx install bandit trufflehog schemathesis reuse scancode-toolkit"
Write-Host " pipx install floss flare-capa volatility3"
Write-Host " npm i -g @mermaid-js/mermaid-cli netron cyclonedx-bom @cyclonedx/cdxgen"
Write-Host "Done."