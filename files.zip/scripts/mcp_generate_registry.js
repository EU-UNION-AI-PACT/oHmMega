#!/usr/bin/env node
/**
 * MCP Registry & Connectors Generator
 * - Generates exactly N nodes across L layers (no duplicates)
 * - Builds a DAG of connectors (depends_on) respecting layers
 * - Merges provided seeds (real tools) and fills up to target size with placeholders
 *
 * Usage:
 *   node scripts/mcp_generate_registry.js --seed config/mcp/servers.categories.seed.json \
 *     --out-reg config/mcp/servers.categories.json --out-graph config/mcp/connectors.graph.json \
 *     --nodes 878 --layers 99 --seed-str "EU-UNION-AI-PACT"
 */
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

function parseArgs() {
  const args = process.argv.slice(2);
  const out = {
    seedPath: 'config/mcp/servers.categories.seed.json',
    outReg: 'config/mcp/servers.categories.json',
    outGraph: 'config/mcp/connectors.graph.json',
    nodes: 878,
    layers: 99,
    seedStr: 'default-seed'
  };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--seed' && args[i+1]) out.seedPath = args[++i];
    else if (a === '--out-reg' && args[i+1]) out.outReg = args[++i];
    else if (a === '--out-graph' && args[i+1]) out.outGraph = args[++i];
    else if (a === '--nodes' && args[i+1]) out.nodes = parseInt(args[++i], 10);
    else if (a === '--layers' && args[i+1]) out.layers = parseInt(args[++i], 10);
    else if (a === '--seed-str' && args[i+1]) out.seedStr = args[++i];
  }
  return out;
}

function mulberry32(seed) {
  return function() {
    let t = seed += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function seededRng(seedStr) {
  const h = crypto.createHash('sha256').update(seedStr).digest();
  const seed = h.readUInt32LE(0);
  return mulberry32(seed);
}

function loadJSON(p) {
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

function saveJSON(p, obj) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(obj, null, 2));
}

function distribute(n, layers) {
  const base = Math.floor(n / layers);
  const remainder = n - base * layers;
  return Array.from({ length: layers }, (_, i) => base + (i < remainder ? 1 : 0));
}

function pickCategory(categories, rng) {
  const idx = Math.floor(rng() * categories.length);
  return categories[Math.max(0, Math.min(idx, categories.length - 1))];
}

function makeName(cat, layerIdx, indexInLayer, rng) {
  const L = String(layerIdx + 1).padStart(2, '0');
  const I = String(indexInLayer + 1).padStart(3, '0');
  const suffix = Math.floor(rng() * 1e9).toString(36).slice(0, 5);
  return `mcp-${cat}-L${L}-${I}-${suffix}`;
}

function main() {
  const opts = parseArgs();
  const rng = seededRng(opts.seedStr);
  const seed = loadJSON(opts.seedPath);

  const categories = Object.keys(seed);
  if (categories.length === 0) {
    console.error('Seed categories file has no categories.');
    process.exit(1);
  }

  // Prepare registry skeleton
  const registry = {};
  for (const c of categories) {
    registry[c] = { description: seed[c].description || '', servers: [] };
  }

  const seenNames = new Set();
  const seenCommands = new Set();
  const allSeedEntries = [];

  // Place seed servers and validate uniqueness
  for (const [cat, obj] of Object.entries(seed)) {
    for (const s of (obj.servers || [])) {
      if (!s.name || !s.run?.command) continue;
      if (seenNames.has(s.name)) { console.error('Duplicate seed name:', s.name); process.exit(1); }
      if (seenCommands.has(s.run.command)) { console.error('Duplicate seed command:', s.run.command); process.exit(1); }
      seenNames.add(s.name);
      seenCommands.add(s.run.command);
      s.category = cat;
      s.layer = typeof s.layer === 'number' ? s.layer : -1;
      registry[cat].servers.push(s);
      allSeedEntries.push(s);
    }
  }

  // Distribute targets per layer
  const perLayer = distribute(opts.nodes, opts.layers);

  // Assign seed layers round-robin respecting capacity
  let curLayer = 0;
  for (const s of allSeedEntries) {
    let tries = 0;
    while (tries < opts.layers) {
      const countAtLayer = Object.values(registry).flatMap(o => o.servers).filter(x => x.layer === curLayer).length;
      if (countAtLayer < perLayer[curLayer]) { s.layer = curLayer; curLayer = (curLayer + 1) % opts.layers; break; }
      curLayer = (curLayer + 1) % opts.layers;
      tries++;
    }
    if (s.layer === -1) s.layer = 0;
  }

  // Fill placeholders to reach target count
  let total = Object.values(registry).reduce((a, o) => a + (o.servers?.length || 0), 0);
  const installTypes = ['manual', 'npm', 'pipx', 'go', 'git', 'binary'];

  while (total < opts.nodes) {
    for (let L = 0; L < opts.layers && total < opts.nodes; L++) {
      const haveAtLayer = Object.values(registry).flatMap(o => o.servers).filter(s => s.layer === L).length;
      if (haveAtLayer >= perLayer[L]) continue;

      const cat = pickCategory(categories, rng);
      const idxInLayer = haveAtLayer;
      const name = makeName(cat, L, idxInLayer, rng);
      if (seenNames.has(name)) continue;

      const command = name;
      if (seenCommands.has(command)) continue;

      seenNames.add(name);
      seenCommands.add(command);

      const t = installTypes[Math.floor(rng() * installTypes.length)];
      const entry = {
        name,
        description: `Auto-generated MCP server placeholder for ${cat}, layer ${L + 1}.`,
        install: { type: t, ref:
          t === 'npm' ? `@mcp/${name}` :
          t === 'pipx' ? `${name.replace(/-/g,'_')}` :
          t === 'go' ? `github.com/example/${name}/cmd/${name}` :
          t === 'git' ? `https://github.com/example/${name}.git` :
          t === 'binary' ? `https://downloads.example.com/${name}.tar.gz` : 'manual'
        },
        run: { command, args: ['--stdio'], env: {} },
        category: cat,
        layer: L
      };
      registry[cat].servers.push(entry);
      total++;
    }
  }

  // Build connectors DAG: edges from any previous layer to current nodes
  const allNodes = Object.values(registry).flatMap(o => o.servers);
  const byLayer = Array.from({ length: opts.layers }, (_, L) => allNodes.filter(n => n.layer === L));
  const edges = [];
  for (let L = 1; L < opts.layers; L++) {
    const prev = byLayer.slice(0, L).flat();
    for (const n of byLayer[L]) {
      const depCount = 1 + Math.floor(rng() * 2); // 1..2 deps
      for (let k = 0; k < depCount; k++) {
        if (prev.length === 0) break;
        const dep = prev[Math.floor(rng() * prev.length)];
        if (dep.name === n.name) continue;
        edges.push({ from: dep.name, to: n.name, type: 'depends_on' });
      }
    }
  }

  // Sort for readability
  for (const cat of Object.keys(registry)) {
    registry[cat].servers.sort((a, b) => (a.layer - b.layer) || a.name.localeCompare(b.name));
  }

  saveJSON(opts.outReg, registry);
  saveJSON(opts.outGraph, { meta: { layers: opts.layers, nodes: opts.nodes }, edges });

  console.log(`Generated registry: ${opts.outReg}`);
  console.log(`Generated connectors: ${opts.outGraph}`);
}
main();