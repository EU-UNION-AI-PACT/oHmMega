#!/usr/bin/env bash
# Einfache Prüfung, ob registrierte Server-Kommandos im PATH vorhanden sind
set -euo pipefail
CFG="${1:-config/mcp/client.generated.json}"
if [[ ! -f "$CFG" ]]; then echo "Config not found: $CFG" >&2; exit 1; fi
miss=0
cmds=$(jq -r '.servers | to_entries[] | .value.command' "$CFG")
echo "Checking commands from $CFG ..."
while IFS= read -r c; do
  if command -v "$c" >/dev/null 2>&1; then
    echo "OK  - $c"
  else
    echo "MISS- $c"
    miss=$((miss+1))
  fi
done <<< "$cmds"
echo "Missing: $miss"
exit 0