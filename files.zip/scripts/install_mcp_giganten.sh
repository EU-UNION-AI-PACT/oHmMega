#!/usr/bin/env bash
# MCP Giganten-Installer (Linux/macOS)
# - Nutzt optional einen Install-Plan (JSON) für korrektes Ordering
# - Fällt auf Registry-Kategorien zurück, wenn kein Plan angegeben
set -Eeuo pipefail

LOGFILE="${LOGFILE:-$(pwd)/install_mcp_giganten_install.log}"
: > "$LOGFILE"

say()  { echo "[$(date -Iseconds)] $*" | tee -a "$LOGFILE"; }
warn() { echo "[$(date -Iseconds)] WARN: $*" | tee -a "$LOGFILE" >&2; }

PLAN=""
REGISTRY="config/mcp/servers.categories.json"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --plan) shift; PLAN="$1" ;;
    --registry) shift; REGISTRY="$1" ;;
    --log) shift; LOGFILE="$1"; : > "$LOGFILE" ;;
    -h|--help)
      cat <<EOF
Usage: $0 [--plan output/mcp_install_plan.json] [--registry config/mcp/servers.categories.json]
EOF
      exit 0;;
    *) warn "Unknown arg: $1";;
  esac
  shift
done

OS="unknown"; PM=""; SUDO=""
if command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi
case "$OSTYPE" in
  linux-gnu*) OS="linux"
    if command -v apt-get >/dev/null 2>&1; then PM="apt"
    elif command -v dnf >/dev/null 2>&1; then PM="dnf"
    elif command -v pacman >/dev/null 2>&1; then PM="pacman"
    else PM="unknown"; fi ;;
  darwin*) OS="mac"; PM="brew" ;;
  *) warn "Unsupported OS: $OSTYPE";;
esac

need() { command -v "$1" >/dev/null 2>&1; }
dl() { curl -fsSL "$1" -o "$2"; }
mkd() { mkdir -p "$1"; }
sym() { local s="$1" d="$2"; [[ -e "$d" ]] || { ${SUDO:-} ln -sf "$s" "$d" || true; }; }

apt_install() { ${SUDO:-} apt-get update -y >>"$LOGFILE" 2>&1 || true; ${SUDO:-} DEBIAN_FRONTEND=noninteractive apt-get install -y "$@" >>"$LOGFILE" 2>&1 || warn "apt install failed: $*"; }
dnf_install() { ${SUDO:-} dnf install -y "$@" >>"$LOGFILE" 2>&1 || warn "dnf install failed: $*"; }
pacman_install() { ${SUDO:-} pacman -Syu --noconfirm "$@" >>"$LOGFILE" 2>&1 || warn "pacman install failed: $*"; }
brew_install() { brew update >>"$LOGFILE" 2>&1 || true; brew install "$@" >>"$LOGFILE" 2>&1 || warn "brew install failed: $*"; }

ensure_basics() {
  say "Installing runtimes (Node, Python/pipx, Go, Java)..."
  if [[ "$PM" == "apt" ]]; then
    apt_install curl jq git unzip zip tar gpg coreutils ca-certificates python3 python3-pip python3-venv openjdk-17-jre-headless
    if ! need node; then curl -fsSL https://deb.nodesource.com/setup_lts.x | ${SUDO:-} -E bash - >>"$LOGFILE" 2>&1 || true; apt_install nodejs; fi
    apt_install golang || true
  elif [[ "$PM" == "dnf" ]]; then
    dnf_install curl jq git unzip zip tar gnupg2 ca-certificates python3 python3-pip java-17-openjdk-headless
    dnf_install nodejs golang || true
  elif [[ "$PM" == "pacman" ]]; then
    pacman_install curl jq git unzip zip tar gnupg ca-certificates python-pip jre-openjdk
    pacman_install nodejs npm go || true
  elif [[ "$PM" == "brew" ]]; then
    brew_install curl jq git unzip gnu-tar coreutils openjdk@17 python node go
  fi
  if ! need pipx; then python3 -m pip install --user --upgrade pip pipx >>"$LOGFILE" 2>&1 || true; python3 -m pipx ensurepath >>"$LOGFILE" 2>&1 || true; export PATH="$HOME/.local/bin:$PATH"; fi
}

install_npm()   { local ref="$1"; say "npm i -g $ref"; npm i -g "$ref" >>"$LOGFILE" 2>&1 || warn "npm failed: $ref"; }
install_pipx()  { local ref="$1"; say "pipx install $ref"; pipx install "$ref" >>"$LOGFILE" 2>&1 || warn "pipx failed: $ref"; }
install_go()    { local ref="$1"; say "go install $ref@latest"; GOBIN="$HOME/.local/bin" go install "$ref@latest" >>"$LOGFILE" 2>&1 || warn "go failed: $ref"; }
install_binary(){ local url="$1" name="$2"; [[ -z "$name" ]] && name="$(basename "$url" | sed 's/\..*//')"
  local od="/opt/mcp/$name"; ${SUDO:-} mkdir -p "$od"
  local tmp="/tmp/${name}_dl"; say "binary $url -> $od"
  dl "$url" "$tmp" || { warn "download failed: $url"; return; }
  case "$tmp" in
    *.tar.gz|*.tgz) ${SUDO:-} tar -xzf "$tmp" -C "$od" || true ;;
    *.zip) ${SUDO:-} unzip -o "$tmp" -d "$od" >>"$LOGFILE" 2>&1 || true ;;
    *) ${SUDO:-} mv "$tmp" "$od/$name" || true ;;
  esac
  local exe="$(find "$od" -maxdepth 2 -type f -perm -111 | head -n1 || true)"
  if [[ -n "$exe" ]]; then ${SUDO:-} chmod +x "$exe"; sym "$exe" "/usr/local/bin/$name"; fi
}
install_git()   { local repo="$1" name="$2" post="${3:-}"; [[ -z "$name" ]] && name="$(basename "$repo" .git)"
  local od="/opt/mcp/$name"; ${SUDO:-} mkdir -p "/opt/mcp"
  if [[ -d "$od/.git" ]]; then say "git pull $od"; git -C "$od" pull --ff-only >>"$LOGFILE" 2>&1 || true
  else say "git clone $repo -> $od"; git clone --depth 1 "$repo" "$od" >>"$LOGFILE" 2>&1 || warn "clone failed: $repo"; fi
  if [[ -n "$post" ]]; then (cd "$od" && bash -lc "$post" >>"$LOGFILE" 2>&1 || warn "post failed: $post"); fi
}

process_entry() {
  local name="$1" type="$2" ref="$3" bin="$4" post="$5"
  case "$type" in
    npm)     install_npm "$ref" ;;
    pipx)    install_pipx "$ref" ;;
    go)      install_go "$ref" ;;
    binary)  install_binary "$ref" "$name" ;;
    git)     install_git "$ref" "$name" "$post" ;;
    manual)  warn "manual install required for $name ($ref)" ;;
    *)       warn "unknown type: $type for $name" ;;
  esac
}

install_from_plan() {
  local plan="$1"
  say "Installing from plan: $plan"
  if ! need jq; then
    say "jq is required; installing..."
    if [[ "$PM" == "apt" ]]; then apt_install jq
    elif [[ "$PM" == "dnf" ]]; then dnf_install jq
    elif [[ "$PM" == "pacman" ]]; then pacman_install jq
    elif [[ "$PM" == "brew" ]]; then brew_install jq
    fi
  fi
  local len; len=$(jq -r '.count' "$plan")
  for i in $(seq 0 $((len-1))); do
    local name type ref bin post
    name=$(jq -r ".plan[$i].name" "$plan")
    type=$(jq -r ".plan[$i].install.type" "$plan")
    ref=$(jq -r ".plan[$i].install.ref" "$plan")
    bin=$(jq -r ".plan[$i].install.bin // empty" "$plan")
    post=$(jq -r ".plan[$i].install.post // empty" "$plan")
    say " -> [$((i+1))/$len] $name ($type)"
    process_entry "$name" "$type" "$ref" "$bin" "$post"
  done
}

install_from_registry() {
  local reg="$1"
  say "Installing from registry (unordered): $reg"
  if ! need jq; then
    say "jq is required; installing..."
    if [[ "$PM" == "apt" ]]; then apt_install jq
    elif [[ "$PM" == "dnf" ]]; then dnf_install jq
    elif [[ "$PM" == "pacman" ]]; then pacman_install jq
    elif [[ "$PM" == "brew" ]]; then brew_install jq
    fi
  fi
  local cats; cats=$(jq -r 'keys[]' "$reg")
  while read -r cat; do
    say "Category: $cat"
    local count; count=$(jq -r --arg c "$cat" '.[$c].servers | length' "$reg")
    for i in $(seq 0 $((count-1))); do
      local name type ref bin post
      name=$(jq -r --arg c "$cat" --argjson i $i '.[$c].servers[$i].name' "$reg")
      type=$(jq -r --arg c "$cat" --argjson i $i '.[$c].servers[$i].install.type' "$reg")
      ref=$(jq -r --arg c "$cat" --argjson i $i '.[$c].servers[$i].install.ref' "$reg")
      bin=$(jq -r --arg c "$cat" --argjson i $i '.[$c].servers[$i].install.bin // empty' "$reg")
      post=$(jq -r --arg c "$cat" --argjson i $i '.[$c].servers[$i].install.post // empty' "$reg")
      say " -> $name ($type)"
      process_entry "$name" "$type" "$ref" "$bin" "$post"
    done
  done <<< "$cats"
}

main() {
  say "Start (log: $LOGFILE)"
  ensure_basics
  if [[ -n "${PLAN:-}" && -f "$PLAN" ]]; then
    install_from_plan "$PLAN"
  else
    install_from_registry "$REGISTRY"
  fi
  say "Done."
}
main "$@"