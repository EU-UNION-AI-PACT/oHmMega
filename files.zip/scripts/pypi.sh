#!/usr/bin/env bash
#
# Build and (optionally) publish the PyPI wheel for the Python wrapper package.
#
# Usage:
#   scripts/pypi.sh build [--venv-test] [--verbose]
#   scripts/pypi.sh publish [--repository pypi|testpypi] [--skip-build] [--verbose]
#
# Env:
#   NODE_BINARY            Optional path to node (defaults to system node)
#   PYPI_API_TOKEN         Required for `publish` (use a TestPyPI token for testpypi)
#   PYPI_REPOSITORY        pypi (default) or testpypi
#
# Notes:
# - Expects your Node CLI already configured at apps/cli and TS built to apps/cli/dist.
# - Uses scripts/sync-cli.sh to vendor the built CLI into the Python package.
# - Build artifacts end up in ./dist (wheel + sdist).
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

ACTION="${1:-build}"
shift || true

VERBOSE=0
DO_VENV_TEST=0
REPOSITORY="${PYPI_REPOSITORY:-pypi}"
SKIP_BUILD=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --verbose) VERBOSE=1; shift ;;
    --venv-test) DO_VENV_TEST=1; shift ;;
    --repository) REPOSITORY="${2:-pypi}"; shift 2 ;;
    --skip-build) SKIP_BUILD=1; shift ;;
    -h|--help)
      sed -n '1,50p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *)
      echo "Unknown arg: $1" >&2
      exit 2
      ;;
  esac
done

log() { echo "==> $*"; }
dbg() { [[ "$VERBOSE" == 1 ]] && echo "[debug] $*" || true; }

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || { echo "Missing required command: $1" >&2; exit 1; }
}

ensure_python_tools() {
  need_cmd python3
  python3 -c "import sys; sys.exit(0)" >/dev/null 2>&1 || { echo "Python 3 not working" >&2; exit 1; }
  log "Installing/Upgrading build and twine (user site)"
  python3 -m pip install --user --upgrade build twine >/dev/null
}

ensure_node_build() {
  # Build Node CLI and sync into Python package
  if [[ "$SKIP_BUILD" -eq 0 ]]; then
    if [[ -f "$REPO_ROOT/pnpm-lock.yaml" || -f "$REPO_ROOT/package.json" ]]; then
      log "Building Node workspace"
      (cd "$REPO_ROOT" && corepack enable || true)
      if command -v pnpm >/dev/null 2>&1; then
        (cd "$REPO_ROOT" && pnpm i && pnpm -r build)
      else
        (cd "$REPO_ROOT" && npm ci || npm install; npm run build --if-present || true)
      fi
    fi
  else
    log "Skipping Node build per --skip-build"
  fi

  local dist_dir="$REPO_ROOT/apps/cli/dist"
  if [[ ! -d "$dist_dir" ]]; then
    echo "Missing built CLI at $dist_dir. Build first (pnpm -r build)." >&2
    exit 1
  fi

  if [[ ! -x "$REPO_ROOT/scripts/sync-cli.sh" ]]; then
    echo "Missing scripts/sync-cli.sh (vendor copier). Please add it." >&2
    exit 1
  fi

  log "Syncing CLI dist into Python package vendor/"
  bash "$REPO_ROOT/scripts/sync-cli.sh" "$dist_dir"
}

py_version() {
  python3 - <<'PY'
import tomllib,sys,os
p=os.path.join(os.getcwd(),"pyproject.toml")
with open(p,"rb") as f:
  d=tomllib.load(f)
print(d.get("project",{}).get("version","0.0.0"))
PY
}

build_wheel() {
  log "Building wheel and sdist"
  (cd "$REPO_ROOT" && python3 -m build)
  log "Artifacts in ./dist:"
  ls -lh "$REPO_ROOT/dist" || true
  if command -v shasum >/dev/null 2>&1; then
    (cd "$REPO_ROOT/dist" && shasum -a 256 ./*)
  elif command -v sha256sum >/devnull 2>&1; then
    (cd "$REPO_ROOT/dist" && sha256sum ./*)
  fi
}

venv_test_install() {
  log "Testing install in a temporary venv"
  need_cmd python3
  python3 -m venv "$REPO_ROOT/.venv-pypi-test"
  # shellcheck disable=SC1091
  source "$REPO_ROOT/.venv-pypi-test/bin/activate"
  pip install --upgrade pip >/dev/null
  # Install from local dist
  local wheel
  wheel="$(ls -1 "$REPO_ROOT"/dist/*.whl | head -n1)"
  if [[ -z "${wheel:-}" ]]; then
    echo "No wheel found in dist/ for venv test." >&2
    deactivate || true
    return 1
  fi
  pip install "$wheel"
  giants --help || true
  deactivate || true
  rm -rf "$REPO_ROOT/.venv-pypi-test"
  log "Venv test done"
}

publish_wheel() {
  local repo="$REPOSITORY"
  if [[ -z "${PYPI_API_TOKEN:-}" ]]; then
    echo "PYPI_API_TOKEN not set. Export it to publish. (Use a TestPyPI token for testpypi.)" >&2
    exit 1
  fi
  ensure_python_tools
  log "Publishing to $repo"
  if [[ "$repo" == "testpypi" ]]; then
    python3 -m twine upload --repository-url https://test.pypi.org/legacy/ -u __token__ -p "$PYPI_API_TOKEN" "$REPO_ROOT"/dist/*
  else
    python3 -m twine upload -u __token__ -p "$PYPI_API_TOKEN" "$REPO_ROOT"/dist/*
  fi
  log "Publish complete."
}

main() {
  [[ "$VERBOSE" == 1 ]] && set -x || true

  case "$ACTION" in
    build)
      ensure_node_build
      ensure_python_tools
      build_wheel
      [[ "$DO_VENV_TEST" == 1 ]] && venv_test_install || true
      ;;
    publish)
      # Optionally build first unless --skip-build
      if [[ "$SKIP_BUILD" -eq 0 ]]; then
        ensure_node_build
        ensure_python_tools
        build_wheel
      fi
      publish_wheel
      ;;
    *)
      echo "Unknown action: $ACTION" >&2
      exit 2
      ;;
  esase
}

main "$@"