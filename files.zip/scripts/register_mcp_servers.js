#!/usr/bin/env node
/**
 * Registry -> MCP client config generator
 * Usage:
 *   node scripts/register_mcp_servers.js --registry config/mcp/servers.categories.json --out config/mcp/client.generated.json
 */
import fs from 'fs';
import path from 'path';

const args = process.argv.slice(2);
let registryPath = 'config/mcp/servers.categories.json';
let outPath = 'config/mcp/client.generated.json';

for (let i = 0; i < args.length; i++) {
  if (args[i] === '--registry' && args[i+1]) { registryPath = args[++i]; }
  else if (args[i] === '--out' && args[i+1]) { outPath = args[++i]; }
}

if (!fs.existsSync(registryPath)) {
  console.error('Registry not found:', registryPath);
  process.exit(1);
}

const reg = JSON.parse(fs.readFileSync(registryPath, 'utf8'));
const servers = {};

for (const [cat, obj] of Object.entries(reg)) {
  for (const entry of (obj.servers || [])) {
    if (!entry.name || !entry.run?.command) continue;
    servers[entry.name] = {
      command: entry.run.command,
      args: Array.isArray(entry.run.args) ? entry.run.args : [],
      env: entry.run.env || {}
    };
  }
}

const out = { servers };
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(out, null, 2));
console.log('Wrote MCP client config:', outPath);