# Giganten-Installation (Windows). Führt eine breite Palette seltener/mächtiger Tools via winget aus.
# PowerShell als Administrator empfohlen.
$ErrorActionPreference = "Continue"

function Install-Winget {
  param([string]$Id, [string]$Name)
  try {
    Write-Host "Installing $Name ($Id)..."
    winget install --id $Id --silent --accept-package-agreements --accept-source-agreements
  } catch {
    Write-Warning "Failed to install $Name ($Id): $_"
  }
}

Write-Host "== Runtimes & Basics =="
Install-Winget -Id Git.Git -Name "Git"
Install-Winget -Id OpenJS.NodeJS.LTS -Name "Node.js LTS"
Install-Winget -Id Python.Python.3.11 -Name "Python 3.11"
Install-Winget -Id GoLang.Go -Name "Go"
Install-Winget -Id EclipseAdoptium.Temurin.17.JRE -Name "Java 17 JRE"
Install-Winget -Id GnuWin32.Make -Name "Make"  # optional

Write-Host "== Security / Static Analysis =="
Install-Winget -Id ReturnToCorp.Semgrep -Name "Semgrep"
Install-Winget -Id Snyk.Snyk -Name "Snyk CLI"
Install-Winget -Id GitLeaks.GitLeaks -Name "Gitleaks"
Install-Winget -Id Google.OSVScanner -Name "OSV-Scanner"
Install-Winget -Id OpenPolicyAgent.OPA -Name "OPA"

Write-Host "== Container / SBOM =="
Install-Winget -Id Docker.DockerDesktop -Name "Docker Desktop"
Install-Winget -Id Anchore.Syft -Name "Syft"
Install-Winget -Id Anchore.Grype -Name "Grype"
Install-Winget -Id AquaSecurity.Trivy -Name "Trivy"
Install-Winget -Id Kubernetes.kubectl -Name "kubectl"
Install-Winget -Id Helm.Helm -Name "Helm"
# CycloneDX tools via npm (nachträglich): npm i -g @cyclonedx/cdxgen cyclonedx-bom

Write-Host "== Reverse Engineering / Forensics =="
Install-Winget -Id NSA.Ghidra -Name "Ghidra"
Install-Winget -Id WiresharkFoundation.Wireshark -Name "Wireshark"
Install-Winget -Id OWASP.ZAP -Name "OWASP ZAP"
Install-Winget -Id Postman.Postman -Name "Postman"
Install-Winget -Id Kong.Insomnia -Name "Insomnia"
Install-Winget -Id Microsoft.SysinternalsSuite -Name "Sysinternals"

Write-Host "== TUI / DevX =="
Install-Winget -Id sharkdp.fd -Name "fd"
Install-Winget -Id sharkdp.bat -Name "bat"
Install-Winget -Id BurntSushi.ripgrep.MSVC -Name "ripgrep"
Install-Winget -Id junegunn.fzf -Name "fzf"
Install-Winget -Id jesseduffield.lazygit -Name "lazygit"
# Lazydocker, k9s via Go:
$env:GOBIN = "$HOME\AppData\Local\Microsoft\WindowsApps"
go install github.com/jesseduffield/lazydocker@latest
go install github.com/derailed/k9s@latest

Write-Host "== API/Testing (CLI/Python) =="
python -m pip install --user mitmproxy schemathesis bandit trufflehog
npm i -g @mermaid-js/mermaid-cli netron @cyclonedx/cdxgen cyclonedx-bom

Write-Host "Hinweis:"
Write-Host "- Einige Tools benötigen API-Keys/Tokens (z.B. snyk)."
Write-Host "- Cutter (rizinorg) kann manuell via Installer/AppImage bezogen werden, falls benötigt."
Write-Host "Fertig."