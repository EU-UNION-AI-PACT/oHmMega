#!/usr/bin/env bash
set -euo pipefail

echo "[*] Installing common CLI tools (Debian/Ubuntu)..."
sudo apt-get update
sudo apt-get install -y jq curl git unzip python3-pip doxygen graphviz default-jre

echo "[*] Installing Node globals..."
npm i -g pa11y jsdoc eslint prettier

echo "[*] Installing Python tools..."
pip3 install --user bandit schemathesis

echo "[*] Installing Semgrep..."
curl -sSL https://github.com/returntocorp/semgrep/releases/latest/download/semgrep-linux-amd64 -o semgrep && chmod +x semgrep && sudo mv semgrep /usr/local/bin/

echo "[*] Installing Trivy..."
curl -sSfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | sudo sh -s -- -b /usr/local/bin

echo "[*] Installing Gitleaks..."
LATEST=$(curl -s https://api.github.com/repos/gitleaks/gitleaks/releases/latest | jq -r '.assets[] | select(.name|test("linux_x64.tar.gz$")).browser_download_url')
curl -L "$LATEST" -o gitleaks.tgz && tar -xzf gitleaks.tgz && sudo mv gitleaks /usr/local/bin/gitleaks && rm gitleaks.tgz

echo "[*] Optional: Install Ghidra, SonarScanner, Snyk, Syft, CycloneDX, KICS, tfsec, grype, findsecbugs.sh, radare2 manually or via package manager."
echo "[*] Done."