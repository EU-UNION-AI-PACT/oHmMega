#!/usr/bin/env bash
# Giganten-Installation (Linux/macOS). Installiert seltene & mächtige CLI/GUI/TUI-Tools.
# Kategorien via Flags wählbar. Fällt robust auf alternative Installer zurück (curl/binaries/AppImage).
set -Eeuo pipefail

LOGFILE="${LOGFILE:-$(pwd)/install_giganten_tools.log}"
: > "$LOGFILE"

# -------- Logging ----------
log()  { echo "[$(date -Iseconds)] $*" | tee -a "$LOGFILE"; }
warn() { echo "[$(date -Iseconds)] WARN: $*" | tee -a "$LOGFILE" >&2; }
err()  { echo "[$(date -Iseconds)] ERROR: $*" | tee -a "$LOGFILE" >&2; }

# -------- Flags ------------
DO_ALL=false
DO_SECURITY=false
DO_RE=false
DO_CONTAINERS=false
DO_API=false
DO_DOCS=false
DO_TUI=false
NOSUDO=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --all) DO_ALL=true ;;
    --security) DO_SECURITY=true ;;
    --re) DO_RE=true ;;
    --containers) DO_CONTAINERS=true ;;
    --api) DO_API=true ;;
    --docs) DO_DOCS=true ;;
    --tui) DO_TUI=true ;;
    --no-sudo) NOSUDO=true ;;
    --log) shift; LOGFILE="$1"; : > "$LOGFILE" ;;
    -h|--help)
      cat <<EOF
Usage: $0 [--all] [--security] [--re] [--containers] [--api] [--docs] [--tui] [--no-sudo] [--log file]
EOF
      exit 0
      ;;
    *) warn "Unknown arg: $1" ;;
  esac
  shift
done

if ! $DO_SECURITY && ! $DO_RE && ! $DO_CONTAINERS && ! $DO_API && ! $DO_DOCS && ! $DO_TUI; then
  DO_ALL=true
fi

# -------- OS detection -----
OS="unknown"; PM=""; SUDO=""
if command -v sudo >/dev/null 2>&1 && ! $NOSUDO; then SUDO="sudo"; fi

if [[ "$OSTYPE" == "linux-gnu"* ]]; then
  OS="linux"
  if command -v apt-get >/dev/null 2>&1; then PM="apt"
  elif command -v dnf >/dev/null 2>&1; then PM="dnf"
  elif command -v pacman >/dev/null 2>&1; then PM="pacman"
  else PM="unknown"; fi
elif [[ "$OSTYPE" == "darwin"* ]]; then
  OS="mac"; PM="brew"
else
  OS="$OSTYPE"
fi

# -------- Helpers ----------
need_cmd() { command -v "$1" >/dev/null 2>&1; }
dl() { curl -fsSL "$1" -o "$2"; }
mkdirs() { mkdir -p "$1"; }
symlink_if_missing() { local src="$1" dst="$2"; [[ -e "$dst" ]] || { $SUDO ln -sf "$src" "$dst" || true; }; }

apt_install() { $SUDO apt-get update -y >>"$LOGFILE" 2>&1 || true; $SUDO DEBIAN_FRONTEND=noninteractive apt-get install -y "$@" >>"$LOGFILE" 2>&1 || warn "apt install failed: $*"; }
dnf_install() { $SUDO dnf install -y "$@" >>"$LOGFILE" 2>&1 || warn "dnf install failed: $*"; }
pacman_install() { $SUDO pacman -Syu --noconfirm "$@" >>"$LOGFILE" 2>&1 || warn "pacman install failed: $*"; }
brew_install() { brew update >>"$LOGFILE" 2>&1 || true; brew install "$@" >>"$LOGFILE" 2>&1 || warn "brew install failed: $*"; }
brew_cask() { brew update >>"$LOGFILE" 2>&1 || true; brew install --cask "$@" >>"$LOGFILE" 2>&1 || warn "brew cask failed: $*"; }
snap_install() { $SUDO snap install "$@" >>"$LOGFILE" 2>&1 || warn "snap install failed: $*"; }

ensure_paths() {
  mkdirs "$HOME/.local/bin"
  case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) export PATH="$HOME/.local/bin:$PATH";; esac
  if [[ -d "/usr/local/bin" ]] && [[ ":$PATH:" != *":/usr/local/bin:"* ]]; then export PATH="/usr/local/bin:$PATH"; fi
}

ensure_basics() {
  log "Installing base packages..."
  if [[ "$PM" == "apt" ]]; then
    apt_install curl jq git unzip zip tar gpg coreutils ca-certificates python3 python3-pip python3-venv openjdk-17-jre-headless build-essential pkg-config libssl-dev
  elif [[ "$PM" == "dnf" ]]; then
    dnf_install curl jq git unzip zip tar gnupg2 ca-certificates python3 python3-pip java-17-openjdk-headless @development-tools openssl-devel
  elif [[ "$PM" == "pacman" ]]; then
    pacman_install curl jq git unzip zip tar gnupg ca-certificates python-pip jre-openjdk base-devel openssl
  elif [[ "$PM" == "brew" ]]; then
    brew_install curl jq git unzip gnu-tar coreutils openjdk@17 python
  else
    warn "Unknown package manager; ensure prerequisites installed"
  fi
}

ensure_node() {
  if ! need_cmd node; then
    log "Installing Node.js LTS..."
    if [[ "$PM" == "apt" ]]; then curl -fsSL https://deb.nodesource.com/setup_lts.x | $SUDO -E bash - >>"$LOGFILE" 2>&1 || true; apt_install nodejs
    elif [[ "$PM" == "dnf" ]]; then curl -fsSL https://rpm.nodesource.com/setup_lts.x | $SUDO -E bash - >>"$LOGFILE" 2>&1 || true; dnf_install nodejs
    elif [[ "$PM" == "pacman" ]]; then pacman_install nodejs npm
    elif [[ "$PM" == "brew" ]]; then brew_install node
    fi
  fi
}

ensure_go() {
  if ! need_cmd go; then
    log "Installing Go..."
    if [[ "$PM" == "apt" ]]; then apt_install golang-go || apt_install golang
    elif [[ "$PM" == "dnf" ]]; then dnf_install golang
    elif [[ "$PM" == "pacman" ]]; then pacman_install go
    elif [[ "$PM" == "brew" ]]; then brew_install go
    else warn "Install Go manually"; fi
  fi
  mkdirs "$HOME/go/bin"
  export GOPATH="${GOPATH:-$HOME/go}"; export GOBIN="$HOME/.local/bin"; mkdirs "$GOBIN"
  case ":$PATH:" in *":$GOBIN:"*) ;; *) export PATH="$GOBIN:$PATH";; esac
}

ensure_pipx() {
  if ! need_cmd pipx; then
    log "Installing pipx..."
    python3 -m pip install --user --upgrade pip pipx >>"$LOGFILE" 2>&1 || true
    python3 -m pipx ensurepath >>"$LOGFILE" 2>&1 || true
    export PATH="$HOME/.local/bin:$PATH"
  fi
}

ensure_java() {
  if ! need_cmd java; then
    log "Installing Java 17..."
    if [[ "$PM" == "apt" ]]; then apt_install openjdk-17-jre-headless
    elif [[ "$PM" == "dnf" ]]; then dnf_install java-17-openjdk-headless
    elif [[ "$PM" == "pacman" ]]; then pacman_install jre-openjdk
    elif [[ "$PM" == "brew" ]]; then brew_install openjdk@17
    fi
  fi
}

# ---------- Category installers ----------

install_tui_common() {
  log "Installing TUI/DevX..."
  case "$PM" in
    apt)
      apt_install ripgrep fd-find bat btop ncdu git-delta ranger nnn fzf neovim
      symlink_if_missing "$(command -v fdfind || true)" "/usr/local/bin/fd"
      symlink_if_missing "$(command -v batcat || true)" "/usr/local/bin/bat"
      apt_install gdu || apt_install gdu-du-disk-usage-analyzer || true
      apt_install eza || apt_install exa || true
      ;;
    dnf) dnf_install ripgrep fd-find bat btop ncdu delta ranger nnn fzf neovim eza || true ;;
    pacman) pacman_install ripgrep fd bat btop ncdu git-delta ranger nnn fzf neovim eza || true ;;
    brew) brew_install ripgrep fd bat btop ncdu delta ranger nnn fzf neovim eza zoxide glow || true ;;
  esac
  # Fallbacks
  if ! need_cmd gdu; then
    if [[ "$OS" == "linux" ]]; then mkdirs /tmp/gdu && dl "https://github.com/dundee/gdu/releases/latest/download/gdu_linux_amd64.tgz" /tmp/gdu/gdu.tgz && tar -xzf /tmp/gdu/gdu.tgz -C /tmp/gdu && $SUDO mv /tmp/gdu/gdu_linux_amd64 /usr/local/bin/gdu || true
    else brew_install gdu || true; fi
  fi
  if ! need_cmd zoxide; then curl -fsSL https://raw.githubusercontent.com/ajeetdsouza/zoxide/main/install.sh | bash >>"$LOGFILE" 2>&1 || true; fi
  if ! need_cmd glow; then ensure_go; go install github.com/charmbracelet/glow@latest >>"$LOGFILE" 2>&1 || true; fi
  if ! need_cmd micro; then curl -fsSL https://getmic.ro | bash >>"$LOGFILE" 2>&1 && $SUDO mv micro /usr/local/bin/ || true; fi
  ensure_go
  go install github.com/jesseduffield/lazygit@latest >>"$LOGFILE" 2>&1 || true
  go install github.com/jesseduffield/lazydocker@latest >>"$LOGFILE" 2>&1 || true
  go install github.com/derailed/k9s@latest >>"$LOGFILE" 2>&1 || true
}

install_security_static() {
  log "Installing Security/Static Analysis..."
  # semgrep
  if ! need_cmd semgrep; then
    curl -fsSL https://github.com/returntocorp/semgrep/releases/latest/download/semgrep-$(uname -s | tr '[:upper:]' '[:lower:]')-amd64 -o /tmp/semgrep && chmod +x /tmp/semgrep && ${SUDO:-} mv /tmp/semgrep /usr/local/bin/semgrep || warn "semgrep install failed"
  fi
  # Snyk (optional auth required)
  npm install -g snyk >>"$LOGFILE" 2>&1 || true
  # IaC & deps
  python3 -m pip install --user --upgrade pip >>"$LOGFILE" 2>&1 || true
  python3 -m pip install --user checkov safety pip-audit >>"$LOGFILE" 2>&1 || true
  if ! need_cmd tfsec; then curl -fsSL https://raw.githubusercontent.com/aquasecurity/tfsec/master/scripts/install_linux.sh | bash >>"$LOGFILE" 2>&1 || true; fi
  if ! need_cmd kics; then curl -fsSL https://get.kics.io | bash >>"$LOGFILE" 2>&1 || true; fi
  if ! need_cmd terrascan; then curl -fsSL https://raw.githubusercontent.com/tenable/terrascan/master/scripts/install.sh | bash >>"$LOGFILE" 2>&1 || true; fi
  # OPA / Conftest
  if ! need_cmd opa; then curl -fsSL -o /tmp/opa https://openpolicyagent.org/downloads/latest/opa_$(uname -s | tr '[:upper:]' '[:lower:]')_amd64 && chmod +x /tmp/opa && ${SUDO:-} mv /tmp/opa /usr/local/bin/opa || true; fi
  if ! need_cmd conftest; then curl -fsSL https://github.com/open-policy-agent/conftest/releases/latest/download/conftest_$(uname -s)_x86_64.tar.gz -o /tmp/conftest.tgz && tar -xzf /tmp/conftest.tgz -C /tmp && ${SUDO:-} mv /tmp/conftest /usr/local/bin/ || true; fi
  # osv-scanner
  if ! need_cmd osv-scanner; then curl -fsSL https://github.com/google/osv-scanner/releases/latest/download/osv-scanner_$(uname -s | tr '[:upper:]' '[:lower:]')_amd64 -o /tmp/osv-scanner && chmod +x /tmp/osv-scanner && ${SUDO:-} mv /tmp/osv-scanner /usr/local/bin/ || true; fi
  # Secrets & Python sec
  if ! need_cmd gitleaks; then
    url=$(curl -fsSL https://api.github.com/repos/gitleaks/gitleaks/releases/latest | jq -r '.assets[] | select(.name|test("linux_x64\\.tar\\.gz$|darwin_x64\\.tar\\.gz$")).browser_download_url' | head -n1)
    dl "$url" /tmp/gitleaks.tgz && tar -xzf /tmp/gitleaks.tgz -C /tmp && ${SUDO:-} mv /tmp/gitleaks /usr/local/bin/ || true
  fi
  python3 -m pip install --user trufflehog bandit >>"$LOGFILE" 2>&1 || true
  # CodeQL CLI
  if ! need_cmd codeql; then
    mkdirs /opt/codeql
    if [[ "$OS" == "linux" ]]; then dl https://github.com/github/codeql-cli-binaries/releases/latest/download/codeql-linux64.zip /tmp/codeql.zip && unzip -o /tmp/codeql.zip -d /opt/codeql >>"$LOGFILE" 2>&1 || true
    else dl https://github.com/github/codeql-cli-binaries/releases/latest/download/codeql-osx64.zip /tmp/codeql.zip && unzip -o /tmp/codeql.zip -d /opt/codeql >>"$LOGFILE" 2>&1 || true
    fi
    symlink_if_missing /opt/codeql/codeql/codeql /usr/local/bin/codeql
  fi
}

install_container_k8s() {
  log "Installing Container/K8s & SBOM..."
  # trivy
  if ! need_cmd trivy; then curl -fsSL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh | ${SUDO:-} sh -s -- -b /usr/local/bin >>"$LOGFILE" 2>&1 || true; fi
  # syft / grype
  if ! need_cmd syft; then curl -fsSL https://raw.githubusercontent.com/anchore/syft/main/install.sh | ${SUDO:-} sh -s -- -b /usr/local/bin >>"$LOGFILE" 2>&1 || true; fi
  if ! need_cmd grype; then curl -fsSL https://raw.githubusercontent.com/anchore/grype/main/install.sh | ${SUDO:-} sh -s -- -b /usr/local/bin >>"$LOGFILE" 2>&1 || true; fi
  # kubescape / popeye / kube-bench / kube-hunter
  if ! need_cmd kubescape; then curl -fsSL https://raw.githubusercontent.com/kubescape/kubescape/master/install.sh | /bin/bash >>"$LOGFILE" 2>&1 || true; fi
  if ! need_cmd popeye; then curl -fsSL https://github.com/derailed/popeye/releases/latest/download/popeye_$(uname -s)_x86_64.tar.gz -o /tmp/popeye.tgz && tar -xzf /tmp/popeye.tgz -C /tmp && ${SUDO:-} mv /tmp/popeye /usr/local/bin/ || true; fi
  if ! need_cmd kube-bench; then curl -fsSL https://github.com/aquasecurity/kube-bench/releases/latest/download/kube-bench-$(uname -s | tr '[:upper:]' '[:lower:]')-amd64.tar.gz -o /tmp/kb.tgz && tar -xzf /tmp/kb.tgz -C /tmp && ${SUDO:-} mv /tmp/kube-bench /usr/local/bin/ || true; fi
  python3 -m pip install --user kube-hunter >>"$LOGFILE" 2>&1 || true
  # CycloneDX tooling optional
  npm i -g @cyclonedx/cdxgen cyclonedx-bom >>"$LOGFILE" 2>&1 || true
}

install_network_recon_fuzz() {
  log "Installing Network/Recon/Fuzzing..."
  if [[ "$PM" == "apt" ]]; then apt_install nmap masscan zmap || true
  elif [[ "$PM" == "dnf" ]]; then dnf_install nmap masscan zmap || true
  elif [[ "$PM" == "pacman" ]]; then pacman_install nmap masscan zmap || true
  elif [[ "$PM" == "brew" ]]; then brew_install nmap masscan zmap || true
  fi
  ensure_go
  go install github.com/owasp-amass/amass/v4/...@latest >>"$LOGFILE" 2>&1 || true
  go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest >>"$LOGFILE" 2>&1 || true
  go install github.com/tomnomnom/assetfinder@latest >>"$LOGFILE" 2>&1 || true
  go install github.com/projectdiscovery/httpx/cmd/httpx@latest >>"$LOGFILE" 2>&1 || true
  go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest >>"$LOGFILE" 2>&1 || true
  go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest >>"$LOGFILE" 2>&1 || true
  go install github.com/ffuf/ffuf@latest >>"$LOGFILE" 2>&1 || true
  # feroxbuster (Rust)
  if ! need_cmd feroxbuster; then
    if [[ "$OS" == "linux" ]]; then
      url=$(curl -fsSL https://api.github.com/repos/epi052/feroxbuster/releases/latest | jq -r '.assets[] | select(.name|test("x86_64-unknown-linux-gnu.tar.gz$")).browser_download_url' | head -n1)
      dl "$url" /tmp/ferox.tgz && tar -xzf /tmp/ferox.tgz -C /tmp && ${SUDO:-} mv /tmp/feroxbuster /usr/local/bin/ || true
    else brew_install feroxbuster || true; fi
  fi
}

install_re_forensics() {
  log "Installing Reverse Engineering & Forensics..."
  ensure_java
  # Ghidra
  if ! need_cmd analyzeHeadless; then
    mkdirs /opt/ghidra
    api="https://api.github.com/repos/NationalSecurityAgency/ghidra/releases/latest"
    url=$(curl -fsSL "$api" | jq -r '.assets[] | select(.name|test("ghidra_.*_PUBLIC_.*zip$")).browser_download_url' | head -n1)
    dl "$url" /tmp/ghidra.zip && unzip -q -o /tmp/ghidra.zip -d /opt/ghidra >>"$LOGFILE" 2>&1 || true
    ghdir=$(find /opt/ghidra -maxdepth 1 -type d -name 'ghidra_*' | head -n1 || true)
    if [[ -n "$ghdir" ]]; then
      symlink_if_missing "$ghdir/support/analyzeHeadless" /usr/local/bin/analyzeHeadless
      symlink_if_missing "$ghdir/ghidraRun" /usr/local/bin/ghidraRun
    fi
  fi
  # radare2 / rizin
  if [[ "$PM" == "apt" ]]; then apt_install radare2 || true
  elif [[ "$PM" == "dnf" ]]; then dnf_install radare2 || true
  elif [[ "$PM" == "pacman" ]]; then pacman_install radare2 || true
  elif [[ "$PM" == "brew" ]]; then brew_install radare2 rizin || true
  fi
  # Cutter GUI
  if [[ "$OS" == "linux" ]]; then
    if ! need_cmd cutter; then
      mkdirs /opt/cutter
      url=$(curl -fsSL https://api.github.com/repos/rizinorg/cutter/releases/latest | jq -r '.assets[] | select(.name|test("AppImage$")).browser_download_url' | head -n1)
      dl "$url" /opt/cutter/Cutter.appimage && chmod +x /opt/cutter/Cutter.appimage && symlink_if_missing /opt/cutter/Cutter.appimage /usr/local/bin/cutter
    fi
  else brew_cask cutter || true; fi

  # Forensics & Malware
  if [[ "$PM" == "apt" ]]; then apt_install binwalk sleuthkit autopsy yara osquery || true
  elif [[ "$PM" == "dnf" ]]; then dnf_install binwalk sleuthkit autopsy yara osquery || true
  elif [[ "$PM" == "pacman" ]]; then pacman_install binwalk sleuthkit yara || true
  elif [[ "$PM" == "brew" ]]; then brew_install binwalk yara sleuthkit osquery || true
  fi
  ensure_pipx
  pipx install flare-capa >>"$LOGFILE" 2>&1 || true
  pipx install floss >>"$LOGFILE" 2>&1 || true
  pipx install volatility3 >>"$LOGFILE" 2>&1 || true
}

install_api_gui_protocol() {
  log "Installing API/Protocol & GUI..."
  # OWASP ZAP
  if [[ "$OS" == "linux" ]]; then
    if need_cmd snap; then snap_install zaproxy --classic || true
    else mkdirs /opt/zap && dl https://github.com/zaproxy/zaproxy/releases/latest/download/ZAP_2_14_0_unix.sh /opt/zap/zap.sh || true && chmod +x /opt/zap/zap.sh || true
    fi
  else brew_cask owasp-zap || brew_install zaproxy || true; fi

  # Wireshark
  if [[ "$PM" == "apt" ]]; then apt_install wireshark || true
  elif [[ "$PM" == "dnf" ]]; then dnf_install wireshark || true
  elif [[ "$PM" == "pacman" ]]; then pacman_install wireshark-qt || true
  elif [[ "$PM" == "brew" ]]; then brew_cask wireshark || true
  fi

  # Postman & Insomnia
  if [[ "$OS" == "linux" ]]; then
    if need_cmd snap; then snap_install postman || true; snap_install insomnia || true; fi
  else brew_cask postman insomnia || true; fi

  # mitmproxy/mitmweb & grpcurl & schemathesis
  python3 -m pip install --user mitmproxy schemathesis >>"$LOGFILE" 2>&1 || true
  if ! need_cmd grpcurl; then
    curl -fsSL https://github.com/fullstorydev/grpcurl/releases/latest/download/grpcurl_$(uname -s | tr '[:upper:]' '[:lower:]')_x86_64.tar.gz -o /tmp/grpcurl.tgz && tar -xzf /tmp/grpcurl.tgz -C /tmp && ${SUDO:-} mv /tmp/grpcurl /usr/local/bin/ || true
  fi
}

install_docs_diagrams() {
  log "Installing Docs/Diagrams..."
  if [[ "$PM" == "apt" ]]; then apt_install doxygen graphviz || true
  elif [[ "$PM" == "dnf" ]]; then dnf_install doxygen graphviz || true
  elif [[ "$PM" == "pacman" ]]; then pacman_install doxygen graphviz || true
  elif [[ "$PM" == "brew" ]]; then brew_install doxygen graphviz || true
  fi
  ensure_node
  npm install -g jsdoc @mermaid-js/mermaid-cli netron >>"$LOGFILE" 2>&1 || true
  # PlantUML
  if ! need_cmd plantuml; then
    mkdirs /opt/plantuml
    dl https://github.com/plantuml/plantuml/releases/latest/download/plantuml.jar /opt/plantuml/plantuml.jar
    echo -e '#!/usr/bin/env bash\nexec java -jar /opt/plantuml/plantuml.jar "$@"' | ${SUDO:-} tee /usr/local/bin/plantuml >/dev/null
    ${SUDO:-} chmod +x /usr/local/bin/plantuml
  fi
}

# ---------- Main ----------
main() {
  log "Detected OS=$OS PM=$PM (log: $LOGFILE)"
  if [[ "$OS" == "unknown" ]]; then
    err "Unsupported OS ($OSTYPE). For Windows use scripts/install_giganten_win.ps1"
    exit 1
  fi

  ensure_paths
  ensure_basics
  ensure_node
  ensure_go
  ensure_pipx
  ensure_java

  if $DO_ALL || $DO_TUI; then install_tui_common; fi
  if $DO_ALL || $DO_SECURITY; then install_security_static; fi
  if $DO_ALL || $DO_CONTAINERS; then install_container_k8s; fi
  if $DO_ALL; then install_network_recon_fuzz; fi
  if $DO_ALL || $DO_RE; then install_re_forensics; fi
  if $DO_ALL || $DO_API; then install_api_gui_protocol; fi
  if $DO_ALL || $DO_DOCS; then install_docs_diagrams; fi

  log "DONE. Einige Tools benötigen API-Tokens/Logins (z.B. snyk). GUI-Apps sind via Menü/Launcher verfügbar."
}

main "$@"