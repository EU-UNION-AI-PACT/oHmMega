#!/usr/bin/env node
/**
 * Creates an install plan using topological sort on connectors graph.
 *
 * Usage:
 *  node scripts/mcp_plan_install.js --registry config/mcp/servers.categories.json \
 *    --connectors config/mcp/connectors.graph.json \
 *    --categories security,api-protocol \
 *    --out output/mcp_install_plan.json
 */
import fs from 'fs';
import path from 'path';

function parseArgs() {
  const args = process.argv.slice(2);
  const out = {
    registry: 'config/mcp/servers.categories.json',
    connectors: 'config/mcp/connectors.graph.json',
    categories: [],
    out: 'output/mcp_install_plan.json'
  };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--registry' && args[i+1]) out.registry = args[++i];
    else if (a === '--connectors' && args[i+1]) out.connectors = args[++i];
    else if (a === '--categories' && args[i+1]) out.categories = args[++i].split(',').map(s => s.trim()).filter(Boolean);
    else if (a === '--out' && args[i+1]) out.out = args[++i];
  }
  return out;
}

function loadJSON(p) { return JSON.parse(fs.readFileSync(p, 'utf8')); }

function topoSort(nodes, edges) {
  const inDeg = new Map(nodes.map(n => [n, 0]));
  const adj = new Map(nodes.map(n => [n, []]));
  for (const e of edges) {
    if (!nodes.includes(e.from) || !nodes.includes(e.to)) continue;
    adj.get(e.from).push(e.to);
    inDeg.set(e.to, (inDeg.get(e.to) || 0) + 1);
  }
  const q = [];
  for (const [n, d] of inDeg.entries()) if (d === 0) q.push(n);
  const res = [];
  while (q.length) {
    const n = q.shift();
    res.push(n);
    for (const m of adj.get(n) || []) {
      inDeg.set(m, inDeg.get(m) - 1);
      if (inDeg.get(m) === 0) q.push(m);
    }
  }
  if (res.length !== nodes.length) console.warn('Graph may contain cycles; produced a partial order.');
  return res;
}

function main() {
  const opts = parseArgs();
  const reg = loadJSON(opts.registry);
  const graph = loadJSON(opts.connectors);

  const byName = new Map();
  const allEntries = [];

  for (const [cat, obj] of Object.entries(reg)) {
    for (const s of (obj.servers || [])) {
      const category = s.category || cat;
      if (opts.categories.length && !opts.categories.includes(category)) continue;
      s.category = category;
      byName.set(s.name, s);
      allEntries.push(s);
    }
  }

  const names = allEntries.map(s => s.name);
  const edges = (graph.edges || []).filter(e => e.type === 'depends_on' && byName.has(e.from) && byName.has(e.to));
  const order = topoSort(names, edges);

  const plan = order.map(n => {
    const s = byName.get(n);
    return { name: s.name, category: s.category, layer: s.layer, install: s.install, run: s.run };
  });

  fs.mkdirSync(path.dirname(opts.out), { recursive: true });
  fs.writeFileSync(opts.out, JSON.stringify({ count: plan.length, plan }, null, 2));
  console.log('Wrote install plan:', opts.out);
}
main();