Param(
  [string]$Plan = ".\output\mcp_install_plan.json",
  [string]$Registry = ".\config\mcp\servers.categories.json"
)
# MCP Giganten-Installer (Windows, PowerShell/Winget)
$ErrorActionPreference = "Continue"
$Log = Join-Path (Get-Location) "install_mcp_giganten_win_install.log"
Set-Content -Path $Log -Value ""

function Log($msg) { $ts = (Get-Date).ToString("s"); "$ts $msg" | Tee-Object -FilePath $Log -Append }
function Try-Exec { param($cmd) Log "RUN: $cmd"; try { iex $cmd } catch { Write-Warning "FAILED: $cmd $_" } }

function Ensure-Base {
  Log "Ensuring runtimes (Node, Python/pipx, Go, Java) via winget..."
  Try-Exec 'winget install --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements'
  Try-Exec 'winget install --id Python.Python.3.11 --silent --accept-package-agreements --accept-source-agreements'
  Try-Exec 'winget install --id GoLang.Go --silent --accept-package-agreements --accept-source-agreements'
  Try-Exec 'winget install --id EclipseAdoptium.Temurin.17.JRE --silent --accept-package-agreements --accept-source-agreements'
  Try-Exec 'winget install --id Git.Git --silent --accept-package-agreements --accept-source-agreements'
  Try-Exec 'python -m pip install --user --upgrade pip pipx'
  $env:Path += ";$HOME\AppData\Roaming\Python\Python311\Scripts"
}

function Install-Npm($pkg)   { Log "npm i -g $pkg"; Try-Exec "npm i -g `"$pkg`"" }
function Install-Pipx($mod)  { Log "pipx install $mod"; Try-Exec "pipx install `"$mod`"" }
function Install-Go($path)   { Log "go install $path@latest"; Try-Exec "go install `"$path@latest`"" }
function Install-Binary($url,$name) {
  if (-not $name) { $name = [IO.Path]::GetFileNameWithoutExtension($url) }
  $root = Join-Path $env:USERPROFILE "mcp\$name"
  New-Item -Force -ItemType Directory -Path $root | Out-Null
  $tmp = Join-Path $env:TEMP "$name-dl"
  Log "Download $url -> $tmp"
  Try-Exec "(New-Object System.Net.WebClient).DownloadFile('$url','$tmp')"
  if ($tmp.EndsWith(".zip")) {
    Try-Exec "Expand-Archive -Force -Path `"$tmp`" -DestinationPath `"$root`""
  } elseif ($tmp.EndsWith(".tar.gz")) {
    Write-Warning "Extract .tar.gz manually or install 7zip CLI."
  } else {
    $dest = Join-Path $root "$name.exe"
    Copy-Item $tmp $dest -Force
    Log "Installed: $dest"
  }
}

function Install-Git($repo,$name,$post) {
  if (-not $name) { $name = [IO.Path]::GetFileNameWithoutExtension($repo) }
  $root = Join-Path $env:USERPROFILE "mcp\$name"
  if (Test-Path (Join-Path $root ".git")) {
    Log "git pull $root"
    Try-Exec "git -C `"$root`" pull --ff-only"
  } else {
    New-Item -Force -ItemType Directory -Path (Split-Path $root) | Out-Null
    Log "git clone $repo -> $root"
    Try-Exec "git clone --depth 1 `"$repo`" `"$root`""
  }
  if ($post) {
    Log "post-install ($name): $post"
    Push-Location $root
    Try-Exec $post
    Pop-Location
  }
}

function Process-Entry($e) {
  $name = $e.name
  $type = $e.install.type
  $ref  = $e.install.ref
  $bin  = $e.install.bin
  $post = $e.install.post
  Log " -> $name ($type)"
  switch ($type) {
    "npm"    { Install-Npm $ref }
    "pipx"   { Install-Pipx $ref }
    "go"     { Install-Go $ref }
    "binary" { Install-Binary $ref $name }
    "git"    { Install-Git $ref $name $post }
    "manual" { Write-Warning "Manual install required for $name ($ref)" }
    default  { Write-Warning "Unknown type: $type for $name" }
  }
}

function Install-From-Plan($PlanPath) {
  if (-not (Test-Path $PlanPath)) { Write-Warning "Plan not found: $PlanPath"; return $false }
  Log "Installing from plan: $PlanPath"
  $json = Get-Content $PlanPath -Raw | ConvertFrom-Json
  $len = [int]$json.count
  for ($i = 0; $i -lt $len; $i++) { Process-Entry $json.plan[$i] }
  return $true
}

function Install-From-Registry($RegPath) {
  if (-not (Test-Path $RegPath)) { Write-Warning "Registry not found: $RegPath"; return }
  Log "Installing from registry (unordered): $RegPath"
  $json = Get-Content $RegPath -Raw | ConvertFrom-Json
  foreach ($cat in $json.PSObject.Properties.Name) {
    Log "Category: $cat"
    $servers = $json.$cat.servers
    if (-not $servers) { continue }
    foreach ($s in $servers) { Process-Entry $s }
  }
}

Log "Start (log: $Log)"
Ensure-Base
$ok = $false
if ($Plan) { $ok = Install-From-Plan -PlanPath $Plan }
if (-not $ok) { Install-From-Registry -RegPath $Registry }
Log "Done."