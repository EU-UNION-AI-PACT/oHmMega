#!/usr/bin/env node
/**
 * Minimal MCP-like API server (no external deps)
 * Endpoints:
 *  - GET  /api/tools
 *  - POST /api/tasks/start     { topic: string, tools?: string[], runId?: string }
 *  - GET  /api/tasks/stream?run=<id>  (SSE)
 *
 * Requires:
 *  - packages/tools-registry
 *  - packages/orchestrator (exporting orchestrateThink with EventLogger + runId support)
 */
import http from 'node:http';
import url from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import { loadRegistry } from '../../../packages/tools-registry/src/index.js';
import { orchestrateThink } from '../../../packages/orchestrator/src/index.js';

type EventLogger = {
  write: (entry: unknown) => void;
  close?: () => void;
};

const PORT = Number(process.env.PORT || 8787);
const RUNS_DIR = path.resolve('runs');

function json(res: http.ServerResponse, status: number, body: unknown) {
  const data = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) });
  res.end(data);
}

function notFound(res: http.ServerResponse) {
  res.statusCode = 404;
  res.end('Not Found');
}

function parseBody(req: http.IncomingMessage): Promise<any> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      try {
        const raw = Buffer.concat(chunks).toString('utf-8');
        resolve(raw ? JSON.parse(raw) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function ensureRunDir(runId: string) {
  const dir = path.join(RUNS_DIR, runId);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function makeEventLogger(runId: string): EventLogger {
  const dir = ensureRunDir(runId);
  const logPath = path.join(dir, 'events.ndjson');
  const stream = fs.createWriteStream(logPath, { flags: 'a' });
  const write = (obj: unknown) => {
    const line = JSON.stringify(obj) + '\n';
    stream.write(line);
  };
  return {
    write,
    close: () => stream.end()
  };
}

function tailToSSE(res: http.ServerResponse, filePath: string) {
  // Set SSE headers
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Content-Type-Options': 'nosniff'
  });

  // Send existing lines once (optional)
  if (fs.existsSync(filePath)) {
    const initial = fs.readFileSync(filePath, 'utf-8').split('\n').filter(Boolean);
    for (const line of initial) {
      res.write(`data: ${line}\n\n`);
    }
  }

  // Watch for new lines
  let position = fs.existsSync(filePath) ? fs.statSync(filePath).size : 0;
  const fd = fs.openSync(filePath, 'a+');

  const interval = setInterval(() => {
    try {
      const stats = fs.fstatSync(fd);
      if (stats.size > position) {
        const size = stats.size - position;
        const buffer = Buffer.alloc(size);
        fs.readSync(fd, buffer, 0, size, position);
        position = stats.size;
        const chunk = buffer.toString('utf-8');
        const lines = chunk.split('\n').filter(Boolean);
        for (const line of lines) {
          res.write(`data: ${line}\n\n`);
        }
      }
    } catch {
      // ignore transient errors
    }
  }, 300);

  // Cleanup
  const cleanup = () => {
    clearInterval(interval);
    try { fs.closeSync(fd); } catch {}
    try { res.end(); } catch {}
  };
  res.on('close', cleanup);
  res.on('error', cleanup);
}

const server = http.createServer(async (req, res) => {
  if (!req.url) return notFound(res);
  const parsed = url.parse(req.url, true);
  const { pathname, query } = parsed;

  // CORS (optional)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  if (req.method === 'GET' && pathname === '/api/tools') {
    try {
      const reg = loadRegistry();
      return json(res, 200, reg);
    } catch (e: any) {
      return json(res, 500, { error: e?.message || 'failed to load registry' });
    }
  }

  if (req.method === 'POST' && pathname === '/api/tasks/start') {
    try {
      const body = await parseBody(req);
      const topic = String(body.topic || '');
      const runId = String(body.runId || `run_${Date.now()}`);
      const tools = Array.isArray(body.tools) ? body.tools as string[] : [];
      if (!topic) return json(res, 400, { error: 'topic required' });

      const logger = makeEventLogger(runId);
      // Fire-and-forget orchestration
      (async () => {
        try {
          await orchestrateThink({
            topic,
            tools,
            runId,
            eventLogger: logger
          });
        } catch (err: any) {
          logger.write({ ts: new Date().toISOString(), level: 'error', phase: 'orchestrate', message: err?.message || String(err) });
        } finally {
          logger.close?.();
        }
      })();

      return json(res, 202, { runId, status: 'started' });
    } catch (e: any) {
      return json(res, 500, { error: e?.message || 'failed to start task' });
    }
  }

  if (req.method === 'GET' && pathname === '/api/tasks/stream') {
    const runId = String(query.run || '');
    if (!runId) return json(res, 400, { error: 'run query param required' });
    const filePath = path.join(RUNS_DIR, runId, 'events.ndjson');
    ensureRunDir(runId);
    return tailToSSE(res, filePath);
  }

  return notFound(res);
});

if (import.meta.url === `file://${process.argv[1]}`) {
  server.listen(PORT, () => {
    console.log(`API listening on http://localhost:${PORT}`);
  });
}

export default server;