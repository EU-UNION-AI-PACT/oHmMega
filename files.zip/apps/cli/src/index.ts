#!/usr/bin/env node
import { handleAuthCommand } from './commands/auth.js';
import { leaderboardRun } from './commands/leaderboard.js';
import { buildBinary, bundleAirgap } from './commands/airgap.js';
// TUI/Orchestrator wurden bereits von dir integriert.

const args = process.argv.slice(2);
const cmd = args[0];

async function main() {
  switch (cmd) {
    case 'auth': {
      await handleAuthCommand(args.slice(1));
      break;
    }
    case 'leaderboard': {
      const sub = args[1];
      if (sub === 'run') await leaderboardRun(args.slice(2));
      else console.log('Usage: giants leaderboard run --config config/leaderboard.json [--out reports]');
      break;
    }
    case 'dist:bin': {
      await buildBinary(args.slice(1));
      break;
    }
    case 'bundle:airgap': {
      await bundleAirgap(args.slice(1));
      break;
    }
    default: {
      console.log(`giants commands:
  auth <github|gitlab|npm> [--ssh|--https] [--offline] [--host <hostname>] [--scope @scope] [--registry <url>]
  leaderboard run --config config/leaderboard.json [--out reports]
  orchestrate:think --topic "..."
  tui:think --run
  dist:bin [--targets node20-linux-x64,node20-macos-x64,node20-macos-arm64,node20-win-x64]
  bundle:airgap [--name giants-airgap] [--docker] [--oci] [--tag giants:airgap]
`);
    }
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});