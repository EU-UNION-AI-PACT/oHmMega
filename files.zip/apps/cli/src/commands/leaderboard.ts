import fs from 'node:fs';
import path from 'node:path';
import { runLeaderboard, saveReports, type Config } from '../../../packages/leaderboard/src/index.js';

export async function leaderboardRun(argv: string[]) {
  const cfgPath = argv.includes('--config') ? argv[argv.indexOf('--config') + 1] : 'config/leaderboard.json';
  const outDir = argv.includes('--out') ? argv[argv.indexOf('--out') + 1] : 'reports';
  if (!cfgPath || !fs.existsSync(cfgPath)) {
    console.error(`Config not found: ${cfgPath}`);
    process.exitCode = 1; return;
  }
  const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf-8')) as Config;
  const data = await runLeaderboard(cfg);
  saveReports(outDir, data);
  console.log(`Leaderboard written to: ${path.resolve(outDir)}`);
}