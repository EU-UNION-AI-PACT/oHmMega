import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

function which(cmd: string) {
  const r = spawnSync(process.platform === 'win32' ? 'where' : 'which', [cmd], { stdio: 'ignore' });
  return r.status === 0;
}
function run(cmd: string, args: string[], opts: { cwd?: string } = {}) {
  return new Promise<number>((resolve, reject) => {
    const p = spawn(cmd, args, { stdio: 'inherit', cwd: opts.cwd, shell: false });
    p.on('close', (c) => resolve(c ?? 0));
    p.on('error', reject);
  });
}

export async function buildBinary(argv: string[]) {
  // Baut ein selbstständiges Binary (Node eingebettet) via pkg
  const entry = path.resolve('apps/cli/dist/index.js');
  if (!fs.existsSync(entry)) {
    console.error('CLI nicht gebaut. Bitte vorher: pnpm -r build');
    process.exitCode = 1; return;
  }
  const targets = (argv.includes('--targets') ? argv[argv.indexOf('--targets') + 1] : 'node20-linux-x64,node20-macos-x64,node20-macos-arm64,node20-win-x64');
  const outDir = path.resolve('airgap/bin');
  fs.mkdirSync(outDir, { recursive: true });

  // Bevorzugt lokales node_modules/.bin/pkg, sonst npx, sonst global pkg
  const pkgLocal = path.resolve('node_modules/.bin/pkg');
  let cmd = '';
  if (fs.existsSync(pkgLocal)) cmd = pkgLocal;
  else if (which('pkg')) cmd = 'pkg';
  else cmd = 'npx';

  const args = cmd === 'npx' ? ['-y', 'pkg', entry, '--targets', targets, '--out-path', outDir] : [entry, '--targets', targets, '--out-path', outDir];
  const code = await run(cmd, args);
  if (code !== 0) { process.exitCode = code; return; }
  console.log('Binaries erstellt in:', outDir);
}

export async function bundleAirgap(argv: string[]) {
  // Erstellt ein Air-Gap Bundle: Binaries (falls vorhanden), Konfig, Docs, plus optional OCI-Tar.
  const outDir = path.resolve('airgap/out');
  const binDir = path.resolve('airgap/bin');
  const includeDocker = argv.includes('--docker');
  const includeOCI = argv.includes('--oci');
  const tarName = argv.includes('--name') ? argv[argv.indexOf('--name') + 1] : 'giants-airgap';
  fs.rmSync(outDir, { recursive: true, force: true });
  fs.mkdirSync(outDir, { recursive: true });

  // Kopiere Binaries oder fallback auf JS dist
  if (fs.existsSync(binDir) && fs.readdirSync(binDir).length) {
    fs.cpSync(binDir, path.join(outDir, 'bin'), { recursive: true });
  } else {
    // Fallback: JS dist + runner script
    const jsDist = path.resolve('apps/cli/dist');
    if (!fs.existsSync(jsDist)) {
      console.error('Keine Binaries und keine dist vorhanden. Bitte pnpm -r build oder giants dist:bin ausführen.');
      process.exitCode = 1; return;
    }
    fs.mkdirSync(path.join(outDir, 'cli'), { recursive: true });
    fs.cpSync(jsDist, path.join(outDir, 'cli'), { recursive: true });
    const runner = `#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NODE_BIN="${NODE_BINARY:-$(command -v node || true)}"
if [[ -z "$NODE_BIN" ]]; then
  echo "Node.js nicht gefunden. Bitte NODE_BINARY setzen oder Node installieren." >&2
  exit 1
fi
exec "$NODE_BIN" "$DIR/cli/index.js" "$@"
`;
    fs.writeFileSync(path.join(outDir, 'giants'), runner, 'utf-8');
    fs.chmodSync(path.join(outDir, 'giants'), 0o755);
  }

  // Konfig/Docs optional bündeln
  const cfgDir = path.resolve('config');
  if (fs.existsSync(cfgDir)) fs.cpSync(cfgDir, path.join(outDir, 'config'), { recursive: true });
  const docsDir = path.resolve('docs');
  if (fs.existsSync(docsDir)) fs.cpSync(docsDir, path.join(outDir, 'docs'), { recursive: true });

  // Tarball erzeugen
  const tarPath = path.resolve('airgap', `${tarName}.tar.gz`);
  const tarCmd = process.platform === 'win32' ? '' : 'tar';
  if (tarCmd) {
    await run('tar', ['-C', path.dirname(outDir), '-czf', tarPath, path.basename(outDir)]);
    console.log('Air-Gap Tarball:', tarPath);
  } else {
    console.log('Tar nicht verfügbar. Packe manuell mit 7zip/PowerShell.');
  }

  // Docker/OCI optional
  if (includeDocker) {
    const dockerfile = path.resolve('infra/docker/Dockerfile.airgap');
    if (!fs.existsSync(dockerfile)) {
      console.warn('Dockerfile.airgap fehlt. Erstelle es zuerst.');
    } else {
      const tag = argv.includes('--tag') ? argv[argv.indexOf('--tag') + 1] : 'giants:airgap';
      await run('docker', ['build', '-f', dockerfile, '-t', tag, '.']);
      console.log('Docker Image gebaut:', tag);
      if (includeOCI) {
        const ociTar = path.resolve('airgap', `${tarName}-oci.tar`);
        await run('docker', ['save', '-o', ociTar, tag]);
        console.log('OCI Tar exportiert:', ociTar);
      }
    }
  }
}