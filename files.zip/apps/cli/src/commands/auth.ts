import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

type Flags = {
  ssh?: boolean;
  https?: boolean;
  host?: string;       // Enterprise/Self-hosted Host
  offline?: boolean;   // Kein gh/glab Login; nur SSH/HTTPS lokal konfigurieren
  scope?: string;      // npm scope @org
  registry?: string;   // npm Registry-URL (z. B. https://npm.internal.local)
};

function cmdExists(cmd: string): boolean {
  const r = spawnSync(process.platform === 'win32' ? 'where' : 'which', [cmd], { stdio: 'ignore' });
  return r.status === 0;
}
function run(cmd: string, args: string[], opts: { stdio?: any; env?: any } = {}) {
  return new Promise<number>((resolve, reject) => {
    const p = spawn(cmd, args, { stdio: opts.stdio ?? 'inherit', env: { ...process.env, ...(opts.env ?? {}) }, shell: false });
    p.on('close', (code) => resolve(code ?? 0));
    p.on('error', reject);
  });
}
function runOut(cmd: string, args: string[]): { code: number; stdout: string; stderr: string } {
  const r = spawnSync(cmd, args, { encoding: 'utf-8' });
  return { code: r.status ?? 0, stdout: r.stdout ?? '', stderr: r.stderr ?? '' };
}

async function ensureGitIdentity() {
  const name = runOut('git', ['config', '--global', 'user.name']).stdout.trim();
  const email = runOut('git', ['config', '--global', 'user.email']).stdout.trim();
  if (!name || !email) {
    console.log('Hinweis: Git-Identität ist nicht gesetzt. Beispiel:');
    console.log('  git config --global user.name "Dein Name"');
    console.log('  git config --global user.email "you@example.com"');
  }
}

async function configureHttpsCredentialHelper() {
  if (process.platform === 'darwin') {
    await run('git', ['config', '--global', 'credential.helper', 'osxkeychain']);
  } else if (process.platform === 'win32') {
    await run('git', ['config', '--global', 'credential.helper', 'manager']);
  } else {
    if (cmdExists('git-credential-manager')) {
      await run('git', ['config', '--global', 'credential.helper', 'manager-core']);
    } else if (cmdExists('secret-tool')) {
      await run('git', ['config', '--global', 'credential.helper', 'libsecret']);
    } else {
      await run('git', ['config', '--global', 'credential.helper', 'cache']);
    }
  }
}

function sshKeyPaths() {
  const home = os.homedir();
  return {
    priv: path.join(home, '.ssh', 'id_ed25519'),
    pub: path.join(home, '.ssh', 'id_ed25519.pub'),
    config: path.join(home, '.ssh', 'config'),
  };
}

async function ensureSSHKey() {
  const { priv, pub } = sshKeyPaths();
  if (!fs.existsSync(priv) || !fs.existsSync(pub)) {
    fs.mkdirSync(path.dirname(priv), { recursive: true });
    const code = await run('ssh-keygen', ['-t', 'ed25519', '-N', '', '-f', priv], { stdio: 'inherit' });
    if (code !== 0) throw new Error('ssh-keygen fehlgeschlagen');
    console.log('Neuer SSH-Key erzeugt:', pub);
  }
}

function ensureSshConfigHost(host: string) {
  const { config } = sshKeyPaths();
  const priv = sshKeyPaths().priv;
  fs.mkdirSync(path.dirname(config), { recursive: true });
  let content = fs.existsSync(config) ? fs.readFileSync(config, 'utf-8') : '';
  const block = [
    `Host ${host}`,
    `  HostName ${host}`,
    `  User git`,
    `  IdentityFile ${priv}`,
    `  IdentitiesOnly yes`,
  ].join('\n');
  const has = new RegExp(`^Host\\s+${host}$`, 'm').test(content);
  if (!has) {
    content += (content.endsWith('\n') ? '' : '\n') + block + '\n';
    fs.writeFileSync(config, content, 'utf-8');
    console.log('~/.ssh/config aktualisiert für Host:', host);
  }
}

async function testSsh(host: string) {
  console.log(`Teste SSH zu ${host} ...`);
  // Akzeptiere neuen Host-Key automatisch beim ersten Connect (autarkes Netz)
  const code = await run('ssh', ['-o', 'StrictHostKeyChecking=accept-new', '-T', `git@${host}`], { stdio: 'inherit' });
  // GitHub/GitLab geben i. d. R. Exit 1 nach erfolgreichem Handshake zurück – kein Fehler.
  if (code === 255) console.warn('SSH Test fehlgeschlagen (255). Prüfe Netz/Firewall/Host-Key.');
}

function setGitRemote(remote: string, url: string) {
  const out = runOut('git', ['remote', 'get-url', remote]);
  if (out.code === 0) {
    runOut('git', ['remote', 'set-url', remote, url]);
    console.log(`Git Remote aktualisiert: ${remote} -> ${url}`);
  } else {
    runOut('git', ['remote', 'add', remote, url]);
    console.log(`Git Remote hinzugefügt: ${remote} -> ${url}`);
  }
}

function ensureNpmrcToken(flags: Flags) {
  const npmrc = path.join(os.homedir(), '.npmrc');
  const lines: string[] = [];
  if (flags.scope && flags.registry) lines.push(`${flags.scope}:registry=${flags.registry}`);
  if (flags.registry) lines.push(`registry=${flags.registry}`);
  if (process.env.NPM_TOKEN && (flags.registry?.includes('npmjs.org') || !flags.registry)) {
    lines.push(`//registry.npmjs.org/:_authToken=\${NPM_TOKEN}`);
  }
  if (!lines.length) return false;
  const content = fs.existsSync(npmrc) ? fs.readFileSync(npmrc, 'utf-8') : '';
  const merged = content.split('\n').filter(Boolean);
  for (const l of lines) if (!merged.some((x) => x.trim() === l.trim())) merged.push(l);
  fs.writeFileSync(npmrc, merged.join('\n') + '\n', 'utf-8');
  console.log(`.npmrc aktualisiert: ${npmrc}`);
  return true;
}

export async function authGithub(flags: Flags = {}) {
  const useSsh = flags.ssh || !flags.https;
  const host = flags.host || 'github.com';
  await ensureGitIdentity();

  if (flags.offline) {
    if (!useSsh) {
      console.log('Offline-Modus: HTTPS-Login wird übersprungen. Richte nur Credential Helper ein.');
      await configureHttpsCredentialHelper();
      return;
    }
    await ensureSSHKey();
    ensureSshConfigHost(host);
    console.log(`Offline-Modus: Bitte füge den SSH Public Key deinem Host (${host}) hinzu:`);
    console.log(`  cat ${sshKeyPaths().pub}`);
    console.log('Setze dann dein Remote z. B.: git remote set-url origin git@' + host + ':OWNER/REPO.git');
    return;
  }

  if (!cmdExists('gh')) {
    console.error('GitHub CLI (gh) nicht gefunden. Installation: https://cli.github.com/');
    process.exitCode = 1; return;
  }
  console.log('Prüfe GitHub Auth-Status ...');
  const st = runOut('gh', ['auth', 'status', '--hostname', host]);
  if (st.code !== 0) {
    const proto = useSsh ? 'ssh' : 'https';
    const scopes = ['repo', 'workflow', 'write:packages'];
    console.log(`Starte gh auth login (Host: ${host}, Protokoll: ${proto}) ...`);
    const code = await run('gh', ['auth', 'login', '--hostname', host, '--web', '--git-protocol', proto, '--scopes', scopes.join(',')]);
    if (code !== 0) { process.exitCode = code; return; }
  } else {
    console.log('Bereits bei GitHub authentifiziert.');
  }
  await run('gh', ['auth', 'setup-git']);
  if (useSsh) { await ensureSSHKey(); ensureSshConfigHost(host); await testSsh(host); }
  else { await configureHttpsCredentialHelper(); }
  console.log('GitHub Auth Bootstrap abgeschlossen.');
}

export async function authGitlab(flags: Flags = {}) {
  const useSsh = flags.ssh || !flags.https;
  const host = flags.host || 'gitlab.com';
  await ensureGitIdentity();

  if (flags.offline) {
    if (!useSsh) {
      console.log('Offline-Modus: HTTPS-Login wird übersprungen. Richte nur Credential Helper ein.');
      await configureHttpsCredentialHelper();
      return;
    }
    await ensureSSHKey();
    ensureSshConfigHost(host);
    console.log(`Offline-Modus: Bitte füge den SSH Public Key deinem Host (${host}) hinzu:`);
    console.log(`  cat ${sshKeyPaths().pub}`);
    console.log('Setze dann dein Remote z. B.: git remote set-url origin git@' + host + ':GROUP/REPO.git');
    return;
  }

  if (!cmdExists('glab')) {
    console.error('GitLab CLI (glab) nicht gefunden. Installation: https://gitlab.com/gitlab-org/cli');
    process.exitCode = 1; return;
  }
  console.log('Prüfe GitLab Auth-Status ...');
  const st = runOut('glab', ['auth', 'status', '--hostname', host]);
  if (st.code !== 0) {
    console.log(`Starte glab auth login (Host: ${host}) ...`);
    const code = await run('glab', ['auth', 'login', '--hostname', host]);
    if (code !== 0) { process.exitCode = code; return; }
  } else {
    console.log('Bereits bei GitLab authentifiziert.');
  }
  if (useSsh) { await ensureSSHKey(); ensureSshConfigHost(host); await testSsh(host); }
  else { await configureHttpsCredentialHelper(); }
  console.log('GitLab Auth Bootstrap abgeschlossen.');
}

export async function authNpm(flags: Flags = {}) {
  const ok = ensureNpmrcToken(flags);
  if (!ok && !flags.offline) {
    const code = await run('npm', ['login'], { stdio: 'inherit' });
    if (code !== 0) { process.exitCode = code; return; }
  } else if (!ok && flags.offline) {
    console.log('Offline-Modus: Bitte Registry und ggf. Auth manuell in ~/.npmrc setzen.');
  }
  console.log('Setze npm provenance (empfohlen für CI): export NPM_CONFIG_PROVENANCE=true');
  console.log('npm Auth Bootstrap abgeschlossen.');
}

export async function handleAuthCommand(argv: string[]) {
  const sub = argv[0];
  const getFlagVal = (name: string) => {
    const i = argv.indexOf(name);
    return i >= 0 ? argv[i + 1] : undefined;
  };
  const flags: Flags = {
    ssh: argv.includes('--ssh'),
    https: argv.includes('--https'),
    offline: argv.includes('--offline'),
    host: getFlagVal('--host'),
    scope: getFlagVal('--scope'),
    registry: getFlagVal('--registry'),
  };

  if (sub === 'github') return authGithub(flags);
  if (sub === 'gitlab') return authGitlab(flags);
  if (sub === 'npm') return authNpm(flags);

  console.log(`Usage: giants auth <github|gitlab|npm> [--ssh|--https] [--offline] [--host <hostname>] [--scope @scope] [--registry <url>]
Beispiele:
  giants auth github --ssh --host ghe.internal.local
  giants auth gitlab --https --host gitlab.internal.local
  giants auth npm --scope @eu-union-ai-pact --registry https://npm.internal.local
  giants auth github --ssh --offline --host ghe.internal.local
`);
}