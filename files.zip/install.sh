#!/usr/bin/env bash
set -euo pipefail

PKG="ReLoadedSince1337"

have() { command -v "$1" >/dev/null 2>&1; }

if have pipx; then
  echo "pipx erkannt -> pipx install $PKG"
  pipx install "$PKG"
  echo "Fertig. Befehl: giants"
  exit 0
fi

if have python3; then
  if python3 -m pip --version >/dev/null 2>&1; then
    echo "Installiere mit pip --user (ohne sudo) -> python3 -m pip install --user $PKG"
    python3 -m pip install --user "$PKG"
    echo "Hinweis: ggf. ~/.local/bin zu PATH hinzufügen, um 'giants' auszuführen."
    exit 0
  fi
fi

if have pip; then
  echo "Installiere systemweit mit sudo pip (Achtung: System-Python) -> sudo pip install $PKG"
  sudo pip install "$PKG"
  exit 0
fi

echo "Kein pip/pipx gefunden. Bitte Python 3 + pip/pipx installieren."
exit 1