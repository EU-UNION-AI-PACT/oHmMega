# feat(cli): Auth --offline für GitHub/GitLab/npm (autark/air-gap)

Kurzfassung
- Neue Option `--offline` für `giants auth <github|gitlab|npm>`:
  - Überspringt gh/glab-Logins (kein Internet erforderlich)
  - Erzeugt SSH-Key (falls fehlend) und pflegt `~/.ssh/config` (via `--host`)
  - Optionaler HTTPS Credential Helper (ohne Online-Auth)
  - npm-Registry/Scope konfigurierbar via `--registry` / `--scope` (z. B. interne Registry)
- Beispiele:
  - `giants auth github --ssh --offline --host ghe.internal.local`
  - `giants auth gitlab --ssh --offline --host gitlab.internal.local`
  - `giants auth npm --scope @org --registry https://npm.internal.local --offline`

Was wurde geändert
- CLI: `auth.ts` — Flags `--offline`, `--host`, `--registry` ergänzt; robuste SSH/HTTPS-Initialisierung
- Doku: Hinweise zu Offline/Enterprise/NPM-Registry sowie `.npmrc`-Anpassungen

Checkliste (bitte abhaken)
- [ ] Secrets/Variablen
  - [ ] `NPM_TOKEN` (für npm-Release-Workflow)
  - [ ] Optional: `NPM_OFFLINE_REGISTRY` (z. B. `https://npm.internal.local`)
- [ ] GitHub Actions
  - [ ] Actions sind erlaubt (Repo Settings → Actions)
  - [ ] Falls Monorepo: Publish-Working-Directory korrekt (z. B. `apps/cli`)
- [ ] Enterprise/Offline
  - [ ] SSH-Public-Key der Build-/Dev-Runner bei GH Enterprise/GitLab hinterlegt
  - [ ] Interne npm-Registry erreichbar; `.npmrc` mit `registry` und ggf. `@scope:registry`
- [ ] Post-Merge
  - [ ] Tag erstellt (z. B. `v0.1.0`) und Pipelines beobachtet
  - [ ] Offline-Smoketest:
    - `giants auth github --ssh --offline --host <ghe-host>`
    - `giants auth gitlab --ssh --offline --host <gitlab-host>`
    - `giants auth npm --scope @org --registry <internal-registry> --offline`

Risiko / Kompatibilität
- Keine Breaking Changes für Online-Flows; `--offline` ist opt-in.
- SSH/HTTPS-Setup bleibt kompatibel, zusätzlich robuster für Air-Gap.

Labels (Vorschlag)
- `enhancement`, `area:cli`, `area:auth`, `scope:offline`, `ci`, `release`