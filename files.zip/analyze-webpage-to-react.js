const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

/**
 * Konfiguration
 */
const TARGET_URL = 'https://example.com'; // Ziel-Webseite
const OUTPUT_DIR = './output'; // Speicherort für Ergebnisse

/**
 * Hilfsfunktion zum Speichern von Assets
 */
async function saveImage(page, imgUrl, outputDir) {
  try {
    const assetName = path.basename(imgUrl.split('?')[0]);
    const view = await page.goto(imgUrl);
    fs.writeFileSync(path.join(outputDir, assetName), await view.buffer());
    return assetName;
  } catch (err) {
    console.warn(`Fehler beim Laden von Asset: ${imgUrl}`);
    return null;
  }
}

/**
 * Hauptfunktion
 */
async function scrapeAndTransform() {
  // Ordnerstruktur anlegen
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });

  // Browser starten
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto(TARGET_URL, { waitUntil: 'networkidle2' });

  // HTML extrahieren
  const html = await page.content();
  fs.writeFileSync(path.join(OUTPUT_DIR, 'raw.html'), html);

  // Bilder extrahieren
  const assets = await page.evaluate(() => Array.from(document.images).map(img => img.src));
  const savedAssets = [];
  for (const assetUrl of assets) {
    const saved = await saveImage(page, assetUrl, OUTPUT_DIR);
    if (saved) savedAssets.push(saved);
  }

  // HTML zu React-Komponente transformieren (grob)
  const transformedHtml = html
    .replace(/class=/g, 'className=')         // Klassen für React anpassen
    .replace(/<script[\s\S]*?<\/script>/gi, '') // Skripte entfernen
    .replace(/<!--[\s\S]*?-->/g, '')            // Kommentare entfernen

  // Komponente erzeugen mit Quellhinweis
  const componentCode = `
/*
  Inspiriert von: ${TARGET_URL}
  Analysiert und erweitert durch: EU-UNION-AI-PACT
  Erweiterungen: Eigene Features, angepasste Architektur
  Hinweis: Keine direkte Kopie, sondern wissenschaftliche Analyse & Modifikation!
*/
import React from "react";
export default function InspiredComponent() {
  return (
    <>
      {/* Automatisch generiert. Manuelle Anpassung empfohlen! */}
      <div>
        ${transformedHtml}
      </div>
    </>
  );
}
`;

  fs.writeFileSync(path.join(OUTPUT_DIR, 'InspiredComponent.jsx'), componentCode);

  // Zusammenfassung speichern
  const summary = `
Analyse-Report für ${TARGET_URL}

Extrahierte Assets:
${savedAssets.map(a => '- ' + a).join('\n')}

Quellhinweis:
Dieses Modul wurde inspiriert durch die Analyse von ${TARGET_URL}.
Es wurde durch eigene Features und Architektur ergänzt und dient nur zu Forschungszwecken.
  `;
  fs.writeFileSync(path.join(OUTPUT_DIR, 'README.md'), summary);

  await browser.close();
  console.log('Extraktion & Transformation abgeschlossen!');
}

scrapeAndTransform();