# Gigantische & seltene Tools – Installation

Schnellstart (Linux/macOS):
```bash
chmod +x scripts/install_gigantic_tools.sh
./scripts/install_gigantic_tools.sh
```

Windows (PowerShell als Admin):
```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force
.\scripts\install_gigantic_tools_win.ps1
```

Hinweise:
- Das Skript installiert sehr viele Tools. Plane Zeit & Speicherplatz ein.
- Einige Tools werden über AppImage/Binaries in /opt abgelegt (Cutter, Ghidra, CodeQL).
- Für Go/Python-Tools werden `go install` und `pipx` genutzt (isoliert, ohne dein System-Python zu “verschmutzen”).
- GUI-Apps (Wireshark, ZAP, Postman, Insomnia, Cutter, Ghidra) erscheinen im Menü bzw. via `/usr/local/bin`.

Ethik & Recht:
- Nutze Sicherheits-, RE- und Forensik-Tools nur auf Systemen/Software, für die du berechtigt bist.
- Beachte Lizenzen, Export- und Compliance-Vorgaben (z.B. Black Duck/FOSSA/REUSE/ScanCode für Lizenzanalyse).

Anpassung:
- Du kannst Kategorien in `scripts/install_gigantic_tools.sh` modular erweitern/auskommentieren.
- Für Distributionen ohne apt/brew nutze die Download-Zweige (curl), oder ergänze PM-Zweige (dnf/pacman/yum).