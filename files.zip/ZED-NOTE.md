# Zed Hinweis (LSP/Extensions)

- Zed unterstützt LSP für viele Sprachen; für eigene Server:
  - Erstelle eine Zed‑Extension, die `mycli lsp` als Language Server registriert (Zed Extension API, JS/TS).
  - Alternativ: Abwarten bis Zed eigene LSP‑Registrierung per Settings für Custom Server stabiler dokumentiert ist.
- Bis dahin: VS Code‑Extension Pfad bevorzugen, oder universell über LSP in anderen Editoren arbeiten.