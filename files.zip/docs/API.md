# MCP-like API

Endpoints
- GET /api/tools
  - Returns the JSON tools registry from config/tools.registry.json

- POST /api/tasks/start
  - Body: { "topic": "string", "tools": ["..."], "runId": "optional" }
  - Action: launches orchestrateThink({ topic, tools, runId, eventLogger })

- GET /api/tasks/stream?run=<runId> (SSE)
  - Streams lines from runs/<runId>/events.ndjson as Server-Sent Events
  - Each NDJSON line is sent as `data: <line>\\n\\n`

Run locally
```bash
node apps/api/src/server.ts  # or compiled JS
curl -s localhost:8787/api/tools | jq
curl -s -X POST localhost:8787/api/tasks/start -H "Content-Type: application/json" -d '{"topic":"Kubernetes Hardening"}'
curl -N localhost:8787/api/tasks/stream?run=run_...   # live stream
```