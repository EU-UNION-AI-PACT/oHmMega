# Autark/Air-Gap Nutzung

Ziele
- Ein einziges Binary (oder Tarball) ohne Internet nutzbar.
- Optional: OCI-Image als `docker load` im isolierten Netz.
- Unterstützung für interne Git-Hosts und private Registries (npm, Docker, PyPI).

Schnellstart (lokal bauen)
```bash
# Build CLI (TS -> JS)
pnpm -r build

# Optional: Selbstständige Binaries bauen (Node eingebettet)
giants dist:bin
# Targets steuern:
giants dist:bin --targets node20-linux-x64,node20-macos-arm64

# Air-Gap Bundle erzeugen (tar.gz + optional Docker/OCI)
giants bundle:airgap --name giants-airgap --docker --oci --tag giants:airgap
```

Installation im Air-Gap
- Tarball übertragen und entpacken:
```bash
tar -xzf giants-airgap.tar.gz
sudo cp -r airgap/out /opt/giants
sudo ln -sf /opt/giants/bin/giants-linux-x64 /usr/local/bin/giants  # je nach Plattform
# Fallback (JS Runner):
sudo ln -sf /opt/giants/giants /usr/local/bin/giants
```

- Docker Image importieren:
```bash
docker load -i giants-airgap-oci.tar
docker run --rm giants:airgap giants --help
```

Systemdienst (API)
- Beispiel systemd Unit siehe `infra/systemd/giants.service`.
- Start:
```bash
sudo cp infra/systemd/giants.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now giants.service
```

Interne Registries
- npm:
  - `giants auth npm --scope @org --registry https://npm.internal.local --offline`
  - `.npmrc` wird gesetzt; Tokens können entfallen, wenn Registry anonymes Read zulässt.
- GitHub Enterprise/GitLab self-hosted:
  - `giants auth github --ssh --host ghe.internal.local --offline`
  - `giants auth gitlab --ssh --host gitlab.internal.local --offline`
  - Schlüssel wird erzeugt, SSH-Config erstellt; Public Key in der Plattform hinterlegen.