# Kate/KDevelop LSP (MyCLI)

1) Kate: Einstellungen → Plugins → "LSP Client" aktivieren
2) Einstellungen → LSP Client → Server:
   - Name: mycli
   - Serverprogramm: mycli
   - Argumente: lsp
   - Wurzelmuster: .git
3) Dateitypen-Zuordnung: *.my → "mylang"

Formatter optional:
- Externes Tool "mycli fmt --stdin --lang mylang" konfigurieren und auf Speichern triggern.