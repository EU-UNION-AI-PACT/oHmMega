Analyse durchgeführt mit: Semgrep
Quelle/Projekt: ./project-src
Erweiterungen: Automatisierte Mustererkennung & Security-Analyse
Hinweis: Wissenschaftliche Analyse & Weiterentwicklung, keine 1:1-Kopie!

Analyse durchgeführt mit: Ghidra
Quelle/Projekt: ./bin/project.exe
Erweiterungen: Reverse Engineering, Funktionsextraktion
Hinweis: Wissenschaftliche Analyse & Weiterentwicklung, keine 1:1-Kopie!

Analyse durchgeführt mit: Snyk
Quelle/Projekt: ./project-src
Erweiterungen: Dependency & Vulnerability Analyse
Hinweis: Wissenschaftliche Analyse & Weiterentwicklung, keine 1:1-Kopie!

Analyse durchgeführt mit: OpenAPI-Parser
Quelle/Projekt: ./api/openapi.yml
Erweiterungen: API-Endpunkt-Dokumentation
Hinweis: Wissenschaftliche Analyse & Weiterentwicklung, keine 1:1-Kopie!