# MCP „Giganten-Installation“ (plattformübergreifend, 878 Knoten, 99 Ebenen, Connectoren)

Dieses Setup liefert:
- Generator: erstellt Registry mit exakt 878 Knoten über 99 Ebenen, keine Duplikate
- Connectoren (DAG): definiert Abhängigkeiten zwischen Knoten
- Planer: erzeugt einen Install-Plan (topologische Sortierung)
- Installer: Linux/macOS (Bash) und Windows (PowerShell/Winget), führen den Plan aus
- Kategorien: scm-devops, cloud-infra, data-db, api-protocol, security, web-automation, ai-ml, observability, messaging, filesystem, misc

Wichtig
- Einige Nodes sind Platzhalter (install.type=manual). Trage echte Paketquellen (npm/pipx/go/git/binary) und Env-Keys ein.
- Keine Duplikate: Der Generator erzwingt eindeutige `name` und `run.command`.
- Connectoren sichern die Install-Reihenfolge (DAG).

Schnellstart (Linux/macOS)
```bash
# 1) Registry (878/99) + Connectoren generieren
node scripts/mcp_generate_registry.js \
  --seed config/mcp/servers.categories.seed.json \
  --out-reg config/mcp/servers.categories.json \
  --out-graph config/mcp/connectors.graph.json \
  --nodes 878 --layers 99 --seed-str "EU-UNION-AI-PACT"

# 2) Install-Plan erzeugen (topologisch sortiert)
node scripts/mcp_plan_install.js \
  --registry config/mcp/servers.categories.json \
  --connectors config/mcp/connectors.graph.json \
  --out output/mcp_install_plan.json

# 3) Installer (Linux/macOS)
chmod +x scripts/install_mcp_giganten.sh
./scripts/install_mcp_giganten.sh --plan output/mcp_install_plan.json
```

Windows (PowerShell als Admin)
```powershell
# 1) Registry & Graph generieren
node .\scripts\mcp_generate_registry.js `
  --seed .\config\mcp\servers.categories.seed.json `
  --out-reg .\config\mcp\servers.categories.json `
  --out-graph .\config\mcp\connectors.graph.json `
  --nodes 878 --layers 99 --seed-str "EU-UNION-AI-PACT"

# 2) Plan erzeugen
node .\scripts\mcp_plan_install.js `
  --registry .\config\mcp\servers.categories.json `
  --connectors .\config\mcp\connectors.graph.json `
  --out .\output\mcp_install_plan.json

# 3) Installer (Windows)
Set-ExecutionPolicy Bypass -Scope Process -Force
.\scripts\install_mcp_giganten_win.ps1 -Plan ".\output\mcp_install_plan.json"
```

Optionen & Utilities
- Kategorien beim Planer filtern: `--categories security,api-protocol`
- Client-Config generieren:
  ```bash
  node scripts/register_mcp_servers.js \
    --registry config/mcp/servers.categories.json \
    --out config/mcp/client.generated.json
  ```
- Env-Variablen: siehe [config/mcp/.env.example.json](config/mcp/.env.example.json)

Ordnerstruktur
- scripts/: Generator, Planer, Installer (Linux+Windows), Client-Registrierung
- config/mcp/: Seed, generierte Registry, Graph, Beispiel-Env
- output/: erzeugter Install-Plan

Sicherheit & Compliance
- Prüfe Lizenzen/Policies deiner Tools. Nutze Secrets über Umgebungsvariablen.
- Installationen sind “best effort”; fehlgeschlagene Einträge stoppen den Gesamtprozess nicht.