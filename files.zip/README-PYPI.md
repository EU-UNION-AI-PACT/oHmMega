# ReLoadedSince1337

Python/PyPI-Installer für die Giants CLI (Node-basiert). Nach der Installation stehen die Befehle `giants`, `ReLoadedSince1337` und `reloadedsince1337` bereit.

## Installation

Empfohlen (isolierte CLI-Umgebung):
```bash
pipx install ReLoadedSince1337
```

Alternativ:
```bash
pip install ReLoadedSince1337
# oder systemweit (nicht empfohlen):
sudo pip install ReLoadedSince1337
```

Oder via Installer-Skript:
```bash
curl -fsSL https://raw.githubusercontent.com/<owner>/<repo>/main/install.sh | bash
```

Voraussetzungen:
- Node.js >= 18 muss im PATH sein (oder `NODE_BINARY` auf einen Node-Pfad setzen).

## Verwendung

```bash
giants --help
giants auth github --ssh
giants orchestrate:think --topic "Kubernetes Hardening"
giants tui:think --run
```

## Hinweise

- Dieses Paket enthält die vorgebaute Node-CLI als Ressource und startet sie über Node.
- Wenn `giants` nicht gefunden wird, prüfen Sie, ob `~/.local/bin` (Linux/macOS) oder `%USERPROFILE%\\AppData\\Roaming\\Python\\PythonXX\\Scripts` (Windows) im PATH ist.