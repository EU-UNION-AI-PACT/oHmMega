const { execSync } = require('child_process');
const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

// === Konfiguration ===
const OUTPUT_DIR = './output';
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const config = {
  TARGET_URL: 'https://example.com',                 // Webseite zur Analyse
  SOURCE_REFERENCE: 'Vapi.ai',                       // Inspirationsquelle
  OWN_EXTENSIONS: [
    'Responsive Grid hinzugefügt',
    'Dark Mode Unterstützung',
    'Eigene API-Integration für Live-Daten'
  ],
  paths: {
    sourceCode: './project-src',                     // Source-Code für Semgrep/Snyk
    binaryFile: './bin/project.exe',                 // Binärdatei für Ghidra
    openApiSpec: './api/openapi.yml'                 // OpenAPI-Spec für openapi-parser
  }
};

/**
 * Schritt 1: Webseiten-Analyse mit Puppeteer
 */
async function analyzeWebpage() {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto(config.TARGET_URL, { waitUntil: 'networkidle2' });

  // HTML extrahieren
  const html = await page.content();
  fs.writeFileSync(path.join(OUTPUT_DIR, 'raw.html'), html);

  // CSS extrahieren
  const cssLinks = await page.evaluate(() =>
    Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(link => link.href)
  );
  for (const cssUrl of cssLinks) {
    try {
      const res = await page.goto(cssUrl);
      fs.writeFileSync(path.join(OUTPUT_DIR, path.basename(cssUrl)), await res.buffer());
    } catch (e) {}
  }

  // Assets extrahieren (Bilder)
  const assets = await page.evaluate(() => Array.from(document.images).map(img => img.src));
  for (const assetUrl of assets) {
    try {
      const assetName = path.basename(assetUrl.split('?')[0]);
      const view = await page.goto(assetUrl);
      fs.writeFileSync(path.join(OUTPUT_DIR, assetName), await view.buffer());
    } catch (e) {}
  }

  await browser.close();
}

/**
 * Schritt 2: Static Analysis mit Semgrep
 */
function runSemgrep(targetPath) {
  try {
    const outFile = path.join(OUTPUT_DIR, 'semgrep.json');
    execSync(`semgrep --config=auto ${targetPath} --json > ${outFile}`);
    return outFile;
  } catch (e) {
    console.error('Semgrep Fehler:', e.message);
    return null;
  }
}

/**
 * Schritt 3: Reverse Engineering mit Ghidra (Headless/CLI)
 */
function runGhidra(binFile) {
  const outDir = path.join(OUTPUT_DIR, 'ghidra');
  fs.mkdirSync(outDir, { recursive: true });
  try {
    execSync(`analyzeHeadless ${outDir} project1 -import ${binFile} -postScript ExtractFunctions.java`);
    return outDir;
  } catch (e) {
    console.error('Ghidra Fehler:', e.message);
    return null;
  }
}

/**
 * Schritt 4: Dependency Analyse mit Snyk
 */
function runSnyk(targetPath) {
  try {
    const outFile = path.join(OUTPUT_DIR, 'snyk.json');
    execSync(`snyk test --json > ${outFile}`, { cwd: targetPath });
    return outFile;
  } catch (e) {
    console.error('Snyk Fehler:', e.message);
    return null;
  }
}

/**
 * Schritt 5: API Analyse mit openapi-parser
 */
function runOpenApiParser(openApiPath) {
  try {
    const openapi = require('openapi-parser');
    openapi.validate(openApiPath)
      .then(api => {
        fs.writeFileSync(path.join(OUTPUT_DIR, 'openapi-analysis.json'), JSON.stringify(api, null, 2));
      })
      .catch(err => console.error('OpenAPI Fehler:', err));
  } catch (e) {
    console.error('OpenAPI-Parser Fehler:', e.message);
  }
}

/**
 * Schritt 6: Transformation – HTML zu React-Komponente (+ Erweiterungen)
 */
function transformHtmlToReactComponent(html, extensions, inspiration, sourceUrl) {
  let transformedHtml = html
    .replace(/class=/g, 'className=')             // React-kompatibel
    .replace(/<script[\s\S]*?<\/script>/gi, '')   // Skripte entfernen
    .replace(/<!--[\s\S]*?-->/g, '');             // Kommentare entfernen

  // Responsive Grid Beispiel
  transformedHtml = transformedHtml.replace(
    /<div([^>]*)>/g,
    '<div$1 style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>'
  );

  // Dark Mode Toggle Beispiel
  const darkModeToggle = `
    <button onClick={() => document.body.classList.toggle('dark-mode')}>
      Dark Mode wechseln
    </button>
  `;

  // Quellhinweis generieren
  const featuresList = extensions.map(f => `- ${f}`).join('\n');
  const sourceComment = `
/*
  Inspiriert von: ${inspiration}
  Quelle: ${sourceUrl}
  Erweiterungen:
${featuresList}
  Hinweis: Analysiert, transformiert & erweitert für Forschungszwecke.
  Keine 1:1-Kopie, sondern eigenständige Weiterentwicklung!
*/
`;

  // React-Komponente als String
  return `
${sourceComment}
import React from "react";
export default function ExtendedComponent() {
  return (
    <div>
      {/* Erweiterung: Dark Mode Toggle */}
      ${darkModeToggle}
      {/* Hauptinhalt aus Analyse, mit Responsive Grid */}
      ${transformedHtml}
    </div>
  );
}
`;
}

/**
 * Schritt 7: Quellhinweis Dokumentation im README
 */
function writeReadme(extensions, inspiration, sourceUrl) {
  const readmeBlock = `
Dieses Modul basiert auf einer Analyse und Inspiration durch ${inspiration} (${sourceUrl}).
Erweiterungen:
${extensions.map(f => `- ${f}`).join('\n')}

Alle Komponenten wurden refaktoriert und erweitert, keine 1:1-Kopie!
Dieses Projekt dient Forschungs- und Entwicklungszwecken.
`;
  fs.writeFileSync(path.join(OUTPUT_DIR, 'README.md'), readmeBlock);
}

/**
 * Workflow-Start
 */
async function main() {
  await analyzeWebpage();
  runSemgrep(config.paths.sourceCode);
  runGhidra(config.paths.binaryFile);
  runSnyk(config.paths.sourceCode);
  runOpenApiParser(config.paths.openApiSpec);

  // Transformation zu React-Komponente
  const html = fs.readFileSync(path.join(OUTPUT_DIR, 'raw.html'), 'utf8');
  const reactComponentCode = transformHtmlToReactComponent(
    html,
    config.OWN_EXTENSIONS,
    config.SOURCE_REFERENCE,
    config.TARGET_URL
  );
  fs.writeFileSync(path.join(OUTPUT_DIR, 'ExtendedComponent.jsx'), reactComponentCode);

  // Quellhinweise im README
  writeReadme(config.OWN_EXTENSIONS, config.SOURCE_REFERENCE, config.TARGET_URL);

  console.log('Analyse, Transformation & Dokumentation erfolgreich abgeschlossen!');
}

main();