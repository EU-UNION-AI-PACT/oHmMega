# Giganten-Installation: CLI/GUI/TUI-Tools (plattfomübergreifend)

Installiert eine kuratierte, große Suite an seltenen und mächtigen Tools für:
- Security & Static Analysis (semgrep, snyk, checkov, tfsec, kics, terrascan, opa, conftest, osv-scanner, gitleaks, trufflehog, bandit, safety, codeql)
- Reverse Engineering & Forensik (ghidra, radare2/rizin, Cutter GUI, binwalk, sleuthkit, autopsy, yara, flare-capa, floss, volatility3, osquery)
- Container/K8s (trivy, syft, grype, kubescape, popeye, kube-bench, kube-hunter, k9s TUI, lazydocker TUI)
- Netzwerk/Recon/Fuzzing (nmap, masscan, zmap, zgrab, amass, subfinder, assetfinder, httpx, naabu, nuclei, ffuf, feroxbuster)
- API/Protokoll & GUI (OWASP ZAP GUI, Wireshark GUI, Postman GUI, Insomnia GUI, mitmproxy/mitmweb, grpcurl, schemathesis)
- Docs/Diagramme (doxygen, graphviz, jsdoc, PlantUML, Mermaid CLI, Netron GUI)
- TUI/DevX (ripgrep, fd, bat, fzf, btop, ncdu/gdu, delta, ranger, nnn, micro, neovim, eza/exa, zoxide, glow, lazygit)

Schnellstart (Linux/macOS)
```bash
chmod +x scripts/install_giganten.sh
./scripts/install_giganten.sh --all
```

Windows (PowerShell als Admin)
```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force
.\scripts\install_giganten_win.ps1
```

Optionen (Linux/macOS)
- Standard: `--all`
- Kategorien:
  - `--security` (Static Analysis, Secrets, IaC)
  - `--re` (Reverse Engineering & Forensik)
  - `--containers` (Container/K8s & SBOM)
  - `--api` (API/Protokoll & GUIs)
  - `--docs` (Dokumentation/Diagramme)
  - `--tui` (TUI/DevX)
- Sonstiges:
  - `--no-sudo` Falls keine sudo-Rechte vorhanden
  - `--log <pfad>` Pfad zur Log-Datei (default: ./install_giganten_tools.log)

Hinweise
- Einige GUI-Apps erscheinen im Desktop-Menü bzw. sind via `/usr/local/bin` verlinkt (z.B. `ghidraRun`, `cutter`, `wireshark`, `zap`).
- Für manche Tools sind Tokens/Lizenzen nötig (z.B. Snyk, Black Duck Detect – nicht automatisch enthalten).
- Das Skript ist “best effort”: fehlende Pakete/Repos führen nicht zum Abbruch des gesamten Laufs.