import * as vscode from 'vscode';
import { spawn } from 'node:child_process';

export function activate(ctx: vscode.ExtensionContext) {
  const diag = vscode.languages.createDiagnosticCollection('mycli');
  ctx.subscriptions.push(diag);

  const lspProc = spawn('mycli', ['lsp'], { stdio: 'pipe' });
  // Tipp: Hier normalerweise vscode-languageclient nutzen – für das Skeleton verzichten wir auf Deps.
  // In der Realität bitte languageclient verwenden, um echte LSP-Pakete zu sprechen.

  const run = vscode.commands.registerCommand('mycli.runAction', async () => {
    const action = await vscode.window.showInputBox({ placeHolder: 'Action (e.g., gen:repo-docs)' });
    if (!action) return;
    const proc = spawn('mycli', ['run', action], { cwd: vscode.workspace.rootPath, shell: true });
    proc.stdout.on('data', d => vscode.window.showInformationMessage(d.toString()));
    proc.stderr.on('data', d => vscode.window.showErrorMessage(d.toString()));
  });

  ctx.subscriptions.push(run);

  vscode.workspace.onDidSaveTextDocument(doc => {
    if (doc.languageId === 'mylang') {
      const fmt = spawn('mycli', ['fmt', '--stdin', '--lang', 'mylang'], { stdio: ['pipe','pipe','pipe'] });
      fmt.stdin.write(doc.getText());
      fmt.stdin.end();
      // Ergebnis könnte in den Editor zurückgeschrieben werden – hier nur Demo.
    }
  });
}

export function deactivate() {}