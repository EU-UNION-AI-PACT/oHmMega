local M = {}

local function spawn(cmd)
  return vim.fn.jobstart(cmd, {
    stdout_buffered = true,
    on_stdout = function(_, data)
      if data then print(table.concat(data, "\n")) end
    end,
    on_stderr = function(_, data) if data then vim.notify(table.concat(data, "\n"), vim.log.levels.ERROR) end end
  })
end

function M.lint()
  spawn({ "mycli", "lint", "--json" })
end

function M.run(action)
  spawn({ "mycli", "run", action })
end

-- LSP via nvim-lspconfig (Beispiel):
-- require('lspconfig').mycli_lsp.setup({ cmd = { "mycli", "lsp" } })

vim.api.nvim_create_user_command("MyCliRun", function(opts) M.run(opts.args) end, { nargs = 1 })
vim.api.nvim_create_user_command("MyCliLint", function() M.lint() end, {})

return M