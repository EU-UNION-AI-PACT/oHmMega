const { execSync } = require('child_process');
const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

// === Konfiguration ===
const OUTPUT_DIR = './output';
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const config = {
  TARGET_URL: 'https://example.com',                 // Webseite zur Analyse
  SOURCE_REFERENCE: 'Vapi.ai',                       // Inspirationsquelle
  OWN_EXTENSIONS: [
    'Responsive Grid hinzugefügt',
    'Dark Mode Unterstützung',
    'Eigene API-Integration für Live-Daten',
    'Static Security Checks',
    'API-Endpunkt-Analyse',
    'Reverse Engineering-Features'
  ],
  paths: {
    sourceCode: './project-src',                     // Source-Code für Semgrep/Snyk/SonarQube
    binaryFile: './bin/project.exe',                 // Binärdatei für Ghidra
    openApiSpec: './api/openapi.yml'                 // OpenAPI-Spec für openapi-parser
  }
};

// ========== Frontend/Web Analyse ========== //
async function analyzeWebpage() {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto(config.TARGET_URL, { waitUntil: 'networkidle2' });

  // HTML extrahieren
  const html = await page.content();
  fs.writeFileSync(path.join(OUTPUT_DIR, 'raw.html'), html);

  // CSS extrahieren
  const cssLinks = await page.evaluate(() =>
    Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(link => link.href)
  );
  for (const cssUrl of cssLinks) {
    try {
      const res = await page.goto(cssUrl);
      fs.writeFileSync(path.join(OUTPUT_DIR, path.basename(cssUrl)), await res.buffer());
    } catch (e) {}
  }

  // Assets extrahieren (Bilder)
  const assets = await page.evaluate(() => Array.from(document.images).map(img => img.src));
  for (const assetUrl of assets) {
    try {
      const assetName = path.basename(assetUrl.split('?')[0]);
      const view = await page.goto(assetUrl);
      fs.writeFileSync(path.join(OUTPUT_DIR, assetName), await view.buffer());
    } catch (e) {}
  }

  await browser.close();
}

// ========== Lighthouse Meta-Analyse (Frontend) ========== //
function runLighthouse(url) {
  try {
    const chromeLauncher = require('chrome-launcher');
    const lighthouse = require('lighthouse');
    (async () => {
      const chrome = await chromeLauncher.launch({ chromeFlags: ['--headless'] });
      const opts = { logLevel: 'info', output: 'html', onlyCategories: ['performance','accessibility','best-practices','seo'], port: chrome.port };
      const runnerResult = await lighthouse(url, opts);
      fs.writeFileSync(path.join(OUTPUT_DIR, 'lighthouse-report.html'), runnerResult.report);
      await chrome.kill();
    })();
  } catch (e) {
    console.error('Lighthouse Fehler:', e.message);
  }
}

// ========== Static Analysis ========== //
function runSemgrep(targetPath) {
  try {
    const outFile = path.join(OUTPUT_DIR, 'semgrep.json');
    execSync(`semgrep --config=auto ${targetPath} --json > ${outFile}`);
    return outFile;
  } catch (e) {
    console.error('Semgrep Fehler:', e.message);
    return null;
  }
}
function runSonarQube(targetPath) {
  // Platzhalter für SonarQube-CLI-Aufruf
  try {
    execSync(`sonar-scanner -Dsonar.projectBaseDir=${targetPath}`);
    fs.writeFileSync(path.join(OUTPUT_DIR, 'sonarqube.txt'), 'SonarQube Scan durchgeführt.');
  } catch (e) {
    console.error('SonarQube Fehler:', e.message);
  }
}

// ========== Reverse Engineering ========== //
function runGhidra(binFile) {
  const outDir = path.join(OUTPUT_DIR, 'ghidra');
  fs.mkdirSync(outDir, { recursive: true });
  try {
    execSync(`analyzeHeadless ${outDir} project1 -import ${binFile} -postScript ExtractFunctions.java`);
    return outDir;
  } catch (e) {
    console.error('Ghidra Fehler:', e.message);
    return null;
  }
}
function runDecompiler(binFile) {
  // Platzhalter: z.B. mit JD-GUI, .NET Reflector
  fs.writeFileSync(path.join(OUTPUT_DIR, 'decompiler.txt'), `Decompiler-Analyse für ${binFile} (manuell oder CLI ausführen)`);
}

// ========== Dependency Analyse ========== //
function runSnyk(targetPath) {
  try {
    const outFile = path.join(OUTPUT_DIR, 'snyk.json');
    execSync(`snyk test --json > ${outFile}`, { cwd: targetPath });
    return outFile;
  } catch (e) {
    console.error('Snyk Fehler:', e.message);
    return null;
  }
}
function runBlackDuck(targetPath) {
  // Platzhalter: Black Duck CLI/API
  fs.writeFileSync(path.join(OUTPUT_DIR, 'blackduck.txt'), `Black Duck Analyse für ${targetPath} (manuell oder CLI/API ausführen)`);
}

// ========== API Analyse ========== //
function runOpenApiParser(openApiPath) {
  try {
    const openapi = require('openapi-parser');
    openapi.validate(openApiPath)
      .then(api => {
        fs.writeFileSync(path.join(OUTPUT_DIR, 'openapi-analysis.json'), JSON.stringify(api, null, 2));
      })
      .catch(err => console.error('OpenAPI Fehler:', err));
  } catch (e) {
    console.error('OpenAPI-Parser Fehler:', e.message);
  }
}
function runPostmanInsomnia(openApiPath) {
  // Platzhalter: Postman/Insomnia Export als JSON/YAML analysieren
  fs.writeFileSync(path.join(OUTPUT_DIR, 'postman-insomnia.txt'), `Postman/Insomnia Export Analyse für ${openApiPath} (manuell oder mit Parser ausführen)`);
}

// ========== Transformation: HTML zu React-Komponente + Erweiterungen ========== //
function transformHtmlToReactComponent(html, extensions, inspiration, sourceUrl) {
  let transformedHtml = html
    .replace(/class=/g, 'className=')             // React-kompatibel
    .replace(/<script[\s\S]*?<\/script>/gi, '')   // Skripte entfernen
    .replace(/<!--[\s\S]*?-->/g, '');             // Kommentare entfernen

  // Beispiel-Erweiterung: Responsive Grid
  transformedHtml = transformedHtml.replace(
    /<div([^>]*)>/g,
    '<div$1 style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>'
  );

  // Beispiel-Erweiterung: Dark Mode Toggle
  const darkModeToggle = `
    <button onClick={() => document.body.classList.toggle('dark-mode')}>
      Dark Mode wechseln
    </button>
  `;

  // Quellhinweis generieren
  const featuresList = extensions.map(f => `- ${f}`).join('\n');
  const sourceComment = `
/*
  Universal Allrounder Analyse-Skript
  Inspiriert von: ${inspiration}
  Quelle: ${sourceUrl}
  Erweiterungen:
${featuresList}
  Hinweis: Analysiert, transformiert & erweitert für Forschungszwecke.
  Keine 1:1-Kopie, sondern eigenständige Weiterentwicklung!
*/
`;

  // React-Komponente als String
  return `
${sourceComment}
import React from "react";
export default function ExtendedComponent() {
  return (
    <div>
      {/* Erweiterung: Dark Mode Toggle */}
      ${darkModeToggle}
      {/* Hauptinhalt aus Analyse, mit Responsive Grid */}
      ${transformedHtml}
    </div>
  );
}
`;
}

// ========== Automatische Quellhinweise im README ========== //
function writeReadme(extensions, inspiration, sourceUrl) {
  const readmeBlock = `
Universal Allrounder Analyse-Skript

Dieses Modul basiert auf einer Analyse und Inspiration durch ${inspiration} (${sourceUrl}).
Erweiterungen:
${extensions.map(f => `- ${f}`).join('\n')}

Alle Komponenten wurden refaktoriert und erweitert, keine 1:1-Kopie!
Dieses Projekt dient Forschungs- und Entwicklungszwecken.
`;
  fs.writeFileSync(path.join(OUTPUT_DIR, 'README.md'), readmeBlock);
}

// ========== Workflow-Start ========== //
async function main() {
  // Frontend/Web
  await analyzeWebpage();
  runLighthouse(config.TARGET_URL);

  // Static Analysis
  runSemgrep(config.paths.sourceCode);
  runSonarQube(config.paths.sourceCode);

  // Reverse Engineering
  runGhidra(config.paths.binaryFile);
  runDecompiler(config.paths.binaryFile);

  // Dependency Analyse
  runSnyk(config.paths.sourceCode);
  runBlackDuck(config.paths.sourceCode);

  // API Analyse
  runOpenApiParser(config.paths.openApiSpec);
  runPostmanInsomnia(config.paths.openApiSpec);

  // Transformation zu React-Komponente
  const html = fs.readFileSync(path.join(OUTPUT_DIR, 'raw.html'), 'utf8');
  const reactComponentCode = transformHtmlToReactComponent(
    html,
    config.OWN_EXTENSIONS,
    config.SOURCE_REFERENCE,
    config.TARGET_URL
  );
  fs.writeFileSync(path.join(OUTPUT_DIR, 'ExtendedComponent.jsx'), reactComponentCode);

  // Quellhinweise im README
  writeReadme(config.OWN_EXTENSIONS, config.SOURCE_REFERENCE, config.TARGET_URL);

  console.log('Universal Allrounder Analyse, Transformation & Dokumentation erfolgreich abgeschlossen!');
}

main();