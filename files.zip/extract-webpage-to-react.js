const puppeteer = require('puppeteer');
const HtmlToReactParser = require('html-to-react').Parser;
const fs = require('fs');
const path = require('path');

const TARGET_URL = 'https://example.com'; // Webseite, die du analysieren willst
const OUTPUT_DIR = './output'; // Zielordner für generierte Komponenten und Assets

async function scrapeAndTransform() {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.goto(TARGET_URL, { waitUntil: 'networkidle2' });

  // Extrahiere HTML und relevante Assets
  const html = await page.content();
  const assets = await page.evaluate(() => {
    return Array.from(document.images).map(img => img.src);
  });

  // Speichere HTML als Rohdatei
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  fs.writeFileSync(path.join(OUTPUT_DIR, 'raw.html'), html);

  // Extrahiere und speichere alle Bilder
  for (const assetUrl of assets) {
    const assetName = path.basename(assetUrl.split('?')[0]);
    const view = await page.goto(assetUrl);
    fs.writeFileSync(path.join(OUTPUT_DIR, assetName), await view.buffer());
  }

  // Wandle HTML zu React-Komponente (grobe Transformation)
  const htmlToReactParser = new HtmlToReactParser();
  const reactElement = htmlToReactParser.parse(html);
  const reactComponentCode = `
import React from "react";
export default function ExtractedComponent() {
  return (
    <>
      {/* Automatisch generiert. Manuell nachbearbeiten! */}
      ${html
        .replace(/class=/g, 'className=') // CSS-Klassen umbenennen
        .replace(/<script[\s\S]*?<\/script>/gi, '') // Skripte entfernen
        .replace(/<!--[\s\S]*?-->/g, '') // Kommentare entfernen
      }
    </>
  );
}
  `;
  fs.writeFileSync(path.join(OUTPUT_DIR, 'ExtractedComponent.jsx'), reactComponentCode);

  await browser.close();
  console.log('Extraktion & Transformation abgeschlossen!');
}

scrapeAndTransform();