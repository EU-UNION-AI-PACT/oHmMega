package mycli.actions

import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.actionSystem.AnActionEvent
import com.intellij.execution.process.ProcessHandlerFactory
import com.intellij.openapi.project.Project
import com.intellij.openapi.wm.ToolWindowManager
import com.intellij.execution.ui.ConsoleViewContentType
import com.intellij.execution.impl.ConsoleViewImpl

class MyCliRunAction: AnAction("Run MyCLI Action") {
    override fun actionPerformed(e: AnActionEvent) {
        val project: Project = e.project ?: return
        val console = ConsoleViewImpl(project, false)
        val toolWindow = ToolWindowManager.getInstance(project).getToolWindow("Run") ?: return
        val content = toolWindow.contentManager.factory.createContent(console.component, "MyCLI", false)
        toolWindow.contentManager.addContent(content)
        val handler = ProcessHandlerFactory.getInstance().createProcessHandler("mycli run quick-scan")
        handler.addProcessListener(object: com.intellij.execution.process.ProcessAdapter() {
            override fun onTextAvailable(event: com.intellij.execution.process.ProcessEvent, outputType: com.intellij.execution.process.Key<*>) {
                console.print(event.text, ConsoleViewContentType.NORMAL_OUTPUT)
            }
        })
        handler.startNotify()
    }
}