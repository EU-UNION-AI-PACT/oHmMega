const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Konfiguration
const OUTPUT_DIR = './analysis_output';
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

/**
 * 1. Static Analysis mit Semgrep
 * (SonarQube läuft als Server, daher hier Semgrep als Beispiel)
 */
function runSemgrep(targetPath) {
  try {
    const outFile = path.join(OUTPUT_DIR, 'semgrep.json');
    execSync(`semgrep --config=auto ${targetPath} --json > ${outFile}`);
    return outFile;
  } catch (e) {
    console.error('Semgrep Fehler:', e.message);
    return null;
  }
}

/**
 * 2. Reverse Engineering mit Ghidra oder Decompiler
 * (Ghidra läuft als GUI/Batch/Headless, hier ein CLI-Beispiel)
 */
function runGhidra(binFile) {
  // Annahme: ghidra-analyzeHeadless installiert und PATH gesetzt
  const outDir = path.join(OUTPUT_DIR, 'ghidra');
  fs.mkdirSync(outDir, { recursive: true });
  try {
    execSync(`analyzeHeadless ${outDir} project1 -import ${binFile} -postScript ExtractFunctions.java`);
    return outDir;
  } catch (e) {
    console.error('Ghidra Fehler:', e.message);
    return null;
  }
}

/**
 * 3. Dependency Analyse mit Snyk
 */
function runSnyk(targetPath) {
  try {
    const outFile = path.join(OUTPUT_DIR, 'snyk.json');
    execSync(`snyk test --json > ${outFile}`, { cwd: targetPath });
    return outFile;
  } catch (e) {
    console.error('Snyk Fehler:', e.message);
    return null;
  }
}

/**
 * 4. OpenAPI Analyse mit openapi-parser
 * (Alternativ: Postman/Insomnia Export als JSON/YAML analysieren)
 */
function parseOpenAPI(openApiPath) {
  try {
    const openapi = require('openapi-parser');
    openapi.validate(openApiPath)
      .then(api => {
        fs.writeFileSync(path.join(OUTPUT_DIR, 'openapi-analysis.json'), JSON.stringify(api, null, 2));
      })
      .catch(err => console.error('OpenAPI Fehler:', err));
  } catch (e) {
    console.error('OpenAPI-Parser Fehler:', e.message);
  }
}

/**
 * Quellhinweis automatisch generieren
 */
function writeSourceHint(tool, source, extension) {
  const block = `
Analyse durchgeführt mit: ${tool}
Quelle/Projekt: ${source}
Erweiterungen: ${extension}
Hinweis: Wissenschaftliche Analyse & Weiterentwicklung, keine 1:1-Kopie!
  `;
  fs.appendFileSync(path.join(OUTPUT_DIR, 'README.md'), block + '\n');
}

/**
 * Ablauf: Beispiel für ein Projekt
 */
function main() {
  // Beispielpfade!
  const sourceCodePath = './projektcode';
  const binaryPath = './bin/project.exe';
  const openApiFile = './api/openapi.yml';

  // 1. Semgrep
  const semgrepResult = runSemgrep(sourceCodePath);
  writeSourceHint('Semgrep', sourceCodePath, 'Automatisierte Code-Muster-Erkennung');

  // 2. Ghidra/Decompiler
  const ghidraResult = runGhidra(binaryPath);
  writeSourceHint('Ghidra', binaryPath, 'Extraktion von Funktionen aus Binärdatei');

  // 3. Snyk
  const snykResult = runSnyk(sourceCodePath);
  writeSourceHint('Snyk', sourceCodePath, 'Dependency-Schwachstellen-Analyse');

  // 4. OpenAPI
  parseOpenAPI(openApiFile);
  writeSourceHint('OpenAPI-Parser', openApiFile, 'API-Endpunkt-Analyse');

  console.log('Automatisierte Analyse abgeschlossen. Siehe analysis_output Ordner.');
}

main();