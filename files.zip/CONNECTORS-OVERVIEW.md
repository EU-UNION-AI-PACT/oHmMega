# IDE/Editor Connector Übersicht

Protokolle:
- LSP: stdio – empfohlen für Sprache/Diagnostics/Code Actions/Formatting
- DAP: stdio – optional für Debugging
- Tasks/External Tools: für "on demand"-Aktionen

Seltene/Geniale Targets:
- Helix (LSP), Kakoune (kak-lsp), Lapce (LSP), Nova (Extensions), Kate/KDevelop (LSP), Zed (LSP/Extensions)

Hinweis:
- Stelle sicher, dass `mycli lsp` dauerhaft im Vordergrund läuft (stdio), keine TTY-Interaktivität erwartet und LSP Capabilities korrekt meldet.
- Formatter: Implementiere LSP TextDocument/formatting, alternativ CLI `mycli fmt`.