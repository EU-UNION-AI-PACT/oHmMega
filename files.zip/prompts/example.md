---
expected: exact:914
---
Rechne: 128 * 7 + 42 / 6 = ? Antworte nur mit der Zahl.